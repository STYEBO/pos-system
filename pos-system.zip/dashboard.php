<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

require_once 'db.php';

// Check user role (for demo, we'll use session variable)
// In real application, get role from database
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Grocery Store - Easy Pos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        :root {
            --header-bg: #f8f9fa;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
       body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #f5f5f5;
    height: 100vh;
}
        
       /* Remove the extra } after height: 100vh; */
.pos-container {
    display: flex;
    height: 100vh;
    background: white;
}
        
        /* Left Sidebar - Categories */
        .categories-sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            border-right: 1px solid var(--border-color);
            overflow-y: auto;
            padding: 15px;
        }
        
        .section-title {
            color: #333;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 15px;
            padding: 8px 12px;
            background: #f0f0f0;
            border-radius: 4px;
        }
        
        .category-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .category-item {
            padding: 10px 12px;
            margin: 4px 0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        
        .category-item:hover {
            background: #e9ecef;
        }
        
        .category-item.active {
            background: #007bff;
            color: white;
        }
        
        .category-item .item-count {
            margin-left: auto;
            background: #6c757d;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        
       .category-item.active .item-count {
    background: white;
    color: #007bff;
}
        
        /* Main Content Area */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        /* Top Header */
        .pos-header {
            padding: 15px 20px;
            background: #ffffff;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .store-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .search-box {
            flex: 1;
            max-width: 500px;
            margin: 0 20px;
        }
        
        .search-box input {
            border-radius: 20px;
            padding-left: 40px;
            border: 1px solid #ccc;
        }
        
        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .time-display {
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }
        
        /* Products Grid */
        .products-grid {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .product-card {
    background: white;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 15px;
    cursor: pointer;
    transition: all 0.3s;
    position: relative;
    display: flex;
    flex-direction: column;
    min-height: 200px; /* Optional: minimum height */
    height:40vh; /* Allow expansion */
}
        
        .product-card:hover {
            border-color: #007bff;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        
        .product-price {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        
        .product-stock {
            font-size: 12px;
            color: #28a745;
            background: #e8f5e9;
            padding: 2px 8px;
            border-radius: 10px;
            display: inline-block;
            margin-bottom: 8px;
        }
        
        .product-name {
            font-size: 14px;
            color: #333;
            margin-bottom: 5px;
            font-weight: 600;
            flex-grow: 1;
        }
        
        .product-desc {
            font-size: 12px;
            color: #666;
            line-height: 1.4;
            margin-bottom: 10px;
        }
        
        .product-image {
            width: 100%;
            height: 120px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        
        /* Cart Sidebar */
    .cart-sidebar {
    width: 450px;
    background: var(--sidebar-bg);
    border-left: 1px solid var(--border-color);
    display: flex;
    flex-direction: column;
}
        .cart-items {
    flex: 1;
    overflow-y: auto;   /* already hai, good */
}
        
        .cart-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-color);
            background: #f8f9fa;
        }
        
        .cart-title {
            font-size: 18px;
            font-weight: 200;
            color: #333;
        }
        
        .cart-items {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        
        .cart-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .cart-table th {
            text-align: left;
            padding: 10px;
            border-bottom: 2px solid #dee2e6;
            font-size: 14px;
            color: #495057;
            font-weight: 600;
            background: #f8f9fa;
        }
        
        .cart-table td {
            padding: 12px 10px;
            border-bottom: 1px solid #dee2e6;
            vertical-align: middle;
        }
        
        .cart-table tr:hover {
            background: #f8f9fa;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .qty-btn {
            width: 24px;
            height: 24px;
            border: 1px solid #dee2e6;
            background: white;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 12px;
        }
        
        .qty-input {
            width: 40px;
            text-align: center;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 4px;
            font-size: 14px;
        }
        
        .delete-item {
            color: #dc3545;
            cursor: pointer;
            font-size: 14px;
        }
        
        /* Cart Footer */
        .cart-footer {
            padding: 20px;
            border-top: 1px solid var(--border-color);
            background: #f8f9fa;
        }
        
        .total-section {
            margin-bottom: 20px;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 16px;
        }
        
        .grand-total {
            font-size: 24px;
            font-weight: 700;
            color: #28a745;
            margin-top: 10px;
            padding-top: 10px;
            border-top: 2px solid #dee2e6;
        }
        
        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .action-btn {
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .fast-cash-btn {
            background: #17a2b8;
            color: white;
        }
        
        .fast-cash-btn:hover {
            background: #138496;
        }
        
        .checkout-btn {
            background: #28a745;
            color: white;
        }
        
        .checkout-btn:hover {
            background: #218838;
        }
        
        .clear-cart-btn {
            width: 100%;
            background: #dc3545;
            color: white;
            margin-top: 10px;
        }
        
        .clear-cart-btn:hover {
            background: #c82333;
        }
        
        .manage-btn {
            background: #6c757d;
            color: white;
        }
        
        .manage-btn:hover {
            background: #545b62;
        }
        
        /* Product Badges */
        .product-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #ffc107;
            color: #212529;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .low-stock {
            background: #dc3545;
            color: white;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        
        /* Windows Activation Bar */
        .windows-bar {
            background: #0078d4;
            color: white;
            padding: 5px 15px;
            font-size: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .windows-bar a {
            color: white;
            text-decoration: none;
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .pos-container {
                flex-direction: column;
            }
            
            .categories-sidebar {
                width: 100%;
                height: 200px;
                border-right: none;
                border-bottom: 1px solid var(--border-color);
            }
            
            .cart-sidebar {
                width: 100%;
                height: 400px;
                border-left: none;
                border-top: 1px solid var(--border-color);
            }
        }
        
        /* Loading Spinner */
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #007bff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Notification */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 9999;
            animation: slideIn 0.3s ease;
        }
        
        .notification.success {
            background: #28a745;
            color: white;
        }
        
        .notification.warning {
            background: #ffc107;
            color: #212529;
        }
        
        .notification.error {
            background: #dc3545;
            color: white;
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        /* Role Badge */
        .role-badge {
            background: <?php echo $user_role == 'admin' ? '#28a745' : '#007bff'; ?>;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
            margin-left: 8px;
        }
        
        .hide-scrollbar {
    scrollbar-width: none;        /* Firefox */
    -ms-overflow-style: none;     /* IE & Edge */
}

.hide-scrollbar::-webkit-scrollbar {
    display: none;                /* Chrome, Safari */
}
    </style>
</head>
<body>
    <div class="app-header">
    <?php include("header.php"); ?>
</div>
    </br>
    <div class="pos-container">
        <!-- Left Categories Sidebar -->
        <div class="categories-sidebar">
            
            <ul class="category-list" id="categoryList">
                <div class="spinner" id="categoriesSpinner"></div>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <div class="pos-header">
                <div class="store-title">
                    <i class="fas fa-shopping-cart"></i>
                    Easy Pos System
                </div>
                
                <div class="search-box position-relative">
                    <i class="fas fa-search"></i>
                    <input type="text" class="form-control" id="searchProduct" placeholder="Search Product Here...">
                </div>
                
                <div class="user-info">
                </div>
            </div>
            
            <!-- Products Grid -->
            <div class="products-grid hide-scrollbar" id="productsGrid">

                <div class="spinner" id="productsSpinner"></div>
            </div>
        </div>
        
        <!-- Right Cart Sidebar -->
        <div class="cart-sidebar">
            <div class="cart-header">
                <h4 class="cart-title mb-0">Shopping Cart</h4>
            </div>
            
            <div class="cart-items hide-scrollbar">
                <table class="cart-table" id="cartTable">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>U/Price</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="cartItems">
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <div class="empty-state">
                                    <i class="fas fa-shopping-cart"></i>
                                    <p>Your cart is empty</p>
                                    <small>Add products from the left</small>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="cart-footer">
                <div class="total-section">
                    <div class="total-row">
                        <span>Subtotal:</span>
                        <span id="subtotal">0.00</span>
                    </div>
                    <div class="total-row">
                        <span>Tax (8.5%):</span>
                        <span id="taxAmount">0.00</span>
                    </div>
                    <div class="total-row grand-total">
                        <span>Total:</span>
                        <span id="totalAmount">0.00</span>
                    </div>
                </div>
                
                <div class="action-buttons">
                    <button class="action-btn fast-cash-btn" onclick="openFastCash()">
                        <i class="fas fa-bolt"></i> Fast Cash
                    </button>
                    <button class="action-btn checkout-btn" onclick="checkout()">
                        <i class="fas fa-credit-card"></i> Check Out
                    </button>
                </div>
                
                <button class="action-btn clear-cart-btn" onclick="clearCart()">
                    <i class="fas fa-trash"></i> Clear Cart
                </button>
            </div>
        </div>
    </div>
    
    <!-- Windows Activation Bar -->
    <div class="windows-bar">
        <div>Grocery Store POS System</div>
        <div>
            <i class="fas fa-windows me-1"></i>
            <a href="#" onclick="activateWindows()">Activate Windows</a>
        </div>
    </div>
    
    <!-- Fast Cash Modal -->
    <div class="modal fade" id="fastCashModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Fast Cash Payment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <h3>Total Amount</h3>
                        <h1 class="text-success" id="modalTotal">0.00</h1>
                    </div>
                    
                    <div class="row g-2 mb-4">
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(10)">10</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(20)">20</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(50)">50</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(100)">100</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(500)">500</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(1000)">1000</button>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Custom Amount</label>
                        <input type="number" class="form-control" id="customAmount" placeholder="Enter amount" step="0.01" oninput="applyCustomCash()">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Cash Received</label>
                        <input type="number" class="form-control" id="cashReceived" placeholder="0.00" step="0.01" value="0.00" oninput="calculateChange()">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Change Due</label>
                        <input type="text" class="form-control bg-light" id="changeDue" readonly value="$0.00">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="processCashPayment()">Complete Payment</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Checkout Modal -->
    <div class="modal fade" id="checkoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Complete Checkout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <h3>Total Amount</h3>
                        <h1 class="text-success" id="checkoutTotal">$0.00</h1>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Payment Method</label>
                        <select class="form-select" id="paymentMethod">
                            <option value="cash">Cash</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="debit_card">Debit Card</option>
                            <option value="mobile">Mobile Payment</option>
                            <option value="online">Online Payment</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Customer Name (Optional)</label>
                        <input type="text" class="form-control" id="customerName" placeholder="Enter customer name">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Customer Phone (Optional)</label>
                        <input type="text" class="form-control" id="customerPhone" placeholder="Enter customer phone">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Notes (Optional)</label>
                        <textarea class="form-control" id="customerNotes" rows="2" placeholder="Any special instructions..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="completeCheckout()">
                        <i class="fas fa-check me-1"></i> Complete Sale
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let cart = JSON.parse(localStorage.getItem('grocery_pos_cart')) || [];
        let selectedCategory = 'all';
        let categories = [];
        let products = [];
        let cashReceived = 0;
        let storeSettings = {};

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            loadCategories();
            loadProducts();
            updateCartDisplay();
            updateTime();
            loadStoreSettings();
            
            // Search functionality
            document.getElementById('searchProduct').addEventListener('input', filterProducts);
            
            // Set interval to update time every minute
            setInterval(updateTime, 60000);
        });
        
        function loadStoreSettings() {
    fetch('get_store_settings.php')
        .then(response => response.json())
        .then(data => {
            storeSettings = data;
            console.log('✅ Store settings loaded successfully:');
            console.log('Store Name:', storeSettings.store_name);
            console.log('Store Address:', storeSettings.store_address);
            console.log('Store Phone:', storeSettings.store_phone);
            console.log('Store Email:', storeSettings.store_email);
            console.log('Tax Rate:', storeSettings.tax_rate);
            console.log('Full Settings:', storeSettings);
            
            // ٹیسٹ کے لیے:
            if (!storeSettings.store_name) {
                console.warn('⚠️ Store name is empty! Using default...');
                storeSettings.store_name = 'Grocery Store POS';
            }
        })
        .catch(error => {
            console.error('❌ Error loading store settings:', error);
            // ڈیفالٹ سیٹنگز
            storeSettings = {
                store_name: 'Grocery Store POS',
                store_address: '123 Main Street',
                store_phone: '+1 (555) 123-4567',
                store_email: 'info@store.com',
                tax_rate: '8.5',
                currency: 'USD',
                receipt_footer: 'Thank you for shopping with us!',
                auto_print: '1'
            };
            console.log('Using default settings:', storeSettings);
        });
}

        function loadCategories() {
            fetch('get_categories.php')
                .then(response => response.json())
                .then(data => {
                    categories = data;
                    const categoryList = document.getElementById('categoryList');
                    categoryList.innerHTML = '';
                    
                    // Add "All Items" first
                    const allItems = document.createElement('li');
                    allItems.className = `category-item ${selectedCategory === 'all' ? 'active' : ''}`;
                    allItems.innerHTML = `
                        All Items
                        <span class="item-count" id="allItemsCount">0</span>
                    `;
                    allItems.onclick = () => selectCategory('all');
                    categoryList.appendChild(allItems);
                    
                    // Add database categories
                    data.forEach(category => {
                        const item = document.createElement('li');
                        item.className = `category-item ${selectedCategory === category.id.toString() ? 'active' : ''}`;
                        item.innerHTML = `
                            ${category.name}
                            <span class="item-count" id="count-${category.id}">0</span>
                        `;
                        item.onclick = () => selectCategory(category.id);
                        categoryList.appendChild(item);
                    });
                    
                    // Update counts after loading products
                    updateCategoryCounts();
                })
                .catch(error => {
                    console.error('Error loading categories:', error);
                    showNotification('Failed to load categories', 'error');
                });
        }

        function loadProducts() {
            fetch('get_products.php')
                .then(response => response.json())
                .then(data => {
                    products = data;
                    displayProducts();
                    updateCategoryCounts();
                    document.getElementById('productsSpinner').style.display = 'none';
                })
                .catch(error => {
                    console.error('Error loading products:', error);
                    
                    document.getElementById('productsSpinner').style.display = 'none';
                });
        }

        function displayProducts() {
            const productsGrid = document.getElementById('productsGrid');
            productsGrid.innerHTML = '';
            
            let filteredProducts = selectedCategory === 'all' 
                ? products 
                : products.filter(p => p.category_id == selectedCategory);
            
            if (filteredProducts.length === 0) {
                productsGrid.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-box-open"></i>
                        <p>No products found in this category</p>
                    </div>
                `;
                return;
            }
            
            filteredProducts.forEach(product => {
                const card = document.createElement('div');
                card.className = 'product-card';
                card.onclick = () => addToCart(product.id);
                card.innerHTML = `
                    ${product.image ? `<img src="${product.image}" class="product-image" alt="${product.name}">` : 
                      `<div class="product-image bg-light d-flex align-items-center justify-content-center">
                         <i class="fas fa-box fa-2x text-muted"></i>
                       </div>`}
                    <div class="product-price">${parseFloat(product.price).toFixed(2)}</div>
                    <div class="product-stock ${product.quantity <= product.min_stock ? 'low-stock' : ''}">
                        ${product.quantity} in stock
                        ${product.quantity <= product.min_stock ? ' (Low Stock)' : ''}
                    </div>
                    <div class="product-name">${product.name}</div>
                    ${product.barcode ? `<div class="product-desc">Barcode: ${product.barcode}</div>` : ''}
                    <div class="product-badge ${product.quantity <= product.min_stock ? 'low-stock' : ''}">
                        ${product.quantity}Num
                    </div>
                `;
                productsGrid.appendChild(card);
            });
        }

        function updateCategoryCounts() {
            // Update "All Items" count
            document.getElementById('allItemsCount').textContent = products.length;
            
            // Update individual category counts
            categories.forEach(category => {
                const count = products.filter(p => p.category_id == category.id).length;
                const countElement = document.getElementById(`count-${category.id}`);
                if (countElement) {
                    countElement.textContent = count;
                }
            });
        }

        function selectCategory(categoryId) {
            selectedCategory = categoryId;
            
            // Update active state
            document.querySelectorAll('.category-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Activate selected category
            document.querySelectorAll('.category-item').forEach(item => {
                if (categoryId === 'all' && item.textContent.includes('All Items')) {
                    item.classList.add('active');
                } else if (item.textContent.includes(categories.find(c => c.id == categoryId)?.name || '')) {
                    item.classList.add('active');
                }
            });
            
            displayProducts();
        }

        function filterProducts() {
            const searchTerm = document.getElementById('searchProduct').value.toLowerCase();
            const productCards = document.querySelectorAll('.product-card');
            
            productCards.forEach(card => {
                const productName = card.querySelector('.product-name').textContent.toLowerCase();
                const productDesc = card.querySelector('.product-desc')?.textContent.toLowerCase() || '';
                
                if (productName.includes(searchTerm) || productDesc.includes(searchTerm)) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        function addToCart(productId) {
            const product = products.find(p => p.id == productId);
            if (!product) return;
            
            if (product.quantity <= 0) {
                showNotification('Product is out of stock!', 'error');
                return;
            }
            
            const existingItem = cart.find(item => item.id == productId);
            
            if (existingItem) {
                if (existingItem.quantity < product.quantity) {
                    existingItem.quantity++;
                } else {
                    showNotification(`Only ${product.quantity} items available in stock!`, 'error');
                    return;
                }
            } else {
                cart.push({
                    id: product.id,
                    name: product.name,
                    price: parseFloat(product.price),
                    quantity: 1,
                    stock: product.quantity
                });
            }
            
            updateCart();
            showNotification(`${product.name} added to cart`, 'success');
        }

        function updateCart() {
            localStorage.setItem('grocery_pos_cart', JSON.stringify(cart));
            updateCartDisplay();
        }

        function updateCartDisplay() {
            const cartItems = document.getElementById('cartItems');
            
            if (cart.length === 0) {
                cartItems.innerHTML = `
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="empty-state">
                                <i class="fas fa-shopping-cart"></i>
                                <p>Your cart is empty</p>
                                <small>Add products from the left</small>
                            </div>
                        </td>
                    </tr>
                `;
                updateTotals();
                return;
            }
            
            let html = '';
            cart.forEach((item, index) => {
                const total = item.price * item.quantity;
                html += `
                    <tr>
                        <td>${item.name}</td>
                        <td>${item.price.toFixed(2)}</td>
                        <td>
                            <div class="quantity-control">
                                <button class="qty-btn" onclick="updateQuantity(${item.id}, -1)">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <input type="number" class="qty-input" value="${item.quantity}" 
                                       min="1" max="${item.stock}" onchange="changeQuantity(${item.id}, this.value)">
                                <button class="qty-btn" onclick="updateQuantity(${item.id}, 1)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </td>
                        <td>${total.toFixed(2)}</td>
                        <td>
                            <span class="delete-item" onclick="removeFromCart(${item.id})">
                                <i class="fas fa-trash"></i>
                            </span>
                        </td>
                    </tr>
                `;
            });
            
            cartItems.innerHTML = html;
            updateTotals();
        }

        function updateQuantity(productId, change) {
            const item = cart.find(item => item.id == productId);
            if (!item) return;
            
            const newQuantity = item.quantity + change;
            
            if (newQuantity < 1) {
                removeFromCart(productId);
                return;
            }
            
            if (newQuantity > item.stock) {
                showNotification(`Only ${item.stock} items available in stock!`, 'error');
                return;
            }
            
            item.quantity = newQuantity;
            updateCart();
        }

        function changeQuantity(productId, newQuantity) {
            const item = cart.find(item => item.id == productId);
            if (!item) return;
            
            newQuantity = parseInt(newQuantity);
            
            if (isNaN(newQuantity) || newQuantity < 1) {
                item.quantity = 1;
            } else if (newQuantity > item.stock) {
                showNotification(`Only ${item.stock} items available in stock!`, 'error');
                item.quantity = item.stock;
            } else {
                item.quantity = newQuantity;
            }
            
            updateCart();
        }

        function removeFromCart(productId) {
            Swal.fire({
                title: 'Remove Item',
                text: 'Are you sure you want to remove this item from cart?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, remove it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    cart = cart.filter(item => item.id != productId);
                    updateCart();
                    showNotification('Item removed from cart', 'warning');
                }
            });
        }

        function clearCart() {
            if (cart.length === 0) return;
            
            Swal.fire({
                title: 'Clear Cart',
                text: 'Are you sure you want to clear the entire cart?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, clear cart!'
            }).then((result) => {
                if (result.isConfirmed) {
                    cart = [];
                    updateCart();
                    showNotification('Cart cleared', 'info');
                }
            });
        }

     function updateTotals() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // سٹنگز سے tax rate لیں
    const taxRate = parseFloat(storeSettings.tax_rate || 0.0) / 100;
    const taxAmount = subtotal * taxRate;
    const total = subtotal + taxAmount;
    
    document.getElementById('subtotal').textContent = `${subtotal.toFixed(2)}`;
    document.getElementById('taxAmount').textContent = `${taxAmount.toFixed(2)}`;
    document.getElementById('totalAmount').textContent = `${total.toFixed(2)}`;
}

// 2. Make sure saleData contains all required fields
function completeSale(paymentMethod, change = 0, customerName = '', customerPhone = '', notes = '') {
    const saleData = {
        items: cart,
        subtotal: parseFloat(document.getElementById('subtotal').textContent),
        tax: parseFloat(document.getElementById('taxAmount').textContent),
        total: parseFloat(document.getElementById('totalAmount').textContent),
        payment_method: paymentMethod,
        change: change,
        customer_name: customerName,
        customer_phone: customerPhone,
        notes: notes,
        cashier: '<?php echo $_SESSION["username"]; ?>',
        timestamp: new Date().toISOString()
    };
    
    // Rest of the code...
}
        function openFastCash() {
            if (cart.length === 0) {
                showNotification('Cart is empty! Add some products first.', 'error');
                return;
            }
            
            updateTotals();
            const total = parseFloat(document.getElementById('totalAmount').textContent.replace('$', ''));
            document.getElementById('modalTotal').textContent = `${total.toFixed(2)}`;
            
            // Reset fields
            document.getElementById('cashReceived').value = '0.00';
            document.getElementById('changeDue').value = '0.00';
            document.getElementById('customAmount').value = '';
            cashReceived = 0;
            
            const modal = new bootstrap.Modal(document.getElementById('fastCashModal'));
            modal.show();
        }

        function applyCash(amount) {
            cashReceived += amount;
            document.getElementById('cashReceived').value = cashReceived.toFixed(2);
            calculateChange();
        }

        function applyCustomCash() {
            const customAmount = parseFloat(document.getElementById('customAmount').value) || 0;
            if (customAmount > 0) {
                cashReceived = customAmount;
                document.getElementById('cashReceived').value = cashReceived.toFixed(2);
                calculateChange();
            }
        }

        function calculateChange() {
            const total = parseFloat(document.getElementById('modalTotal').textContent.replace('$', ''));
            cashReceived = parseFloat(document.getElementById('cashReceived').value) || 0;
            const change = cashReceived - total;
            
            if (change >= 0) {
                document.getElementById('changeDue').value = `${change.toFixed(2)}`;
                document.getElementById('changeDue').classList.remove('text-danger');
                document.getElementById('changeDue').classList.add('text-success');
            } else {
                document.getElementById('changeDue').value = `-${Math.abs(change).toFixed(2)}`;
                document.getElementById('changeDue').classList.remove('text-success');
                document.getElementById('changeDue').classList.add('text-danger');
            }
        }

        function processCashPayment() {
            const total = parseFloat(document.getElementById('modalTotal').textContent.replace('$', ''));
            cashReceived = parseFloat(document.getElementById('cashReceived').value) || 0;
            
            if (cashReceived < total) {
                showNotification('Insufficient cash received!', 'error');
                return;
            }
            
            const change = cashReceived - total;
            
            Swal.fire({
                title: 'Confirm Cash Payment',
                html: `
                    <div class="text-start">
                        <p><strong>Total:</strong> ${total.toFixed(2)}</p>
                        <p><strong>Cash Received:</strong> ${cashReceived.toFixed(2)}</p>
                        <p><strong>Change Due:</strong> ${change.toFixed(2)}</p>
                    </div>
                `,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Complete Payment',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    completeSale('cash', change);
                }
            });
        }

        function checkout() {
            if (cart.length === 0) {
                showNotification('Cart is empty! Add some products first.', 'error');
                return;
            }
            
            updateTotals();
            const total = parseFloat(document.getElementById('totalAmount').textContent.replace('$', ''));
            document.getElementById('checkoutTotal').textContent = `${total.toFixed(2)}`;
            
            const modal = new bootstrap.Modal(document.getElementById('checkoutModal'));
            modal.show();
        }

        function completeCheckout() {
            const paymentMethod = document.getElementById('paymentMethod').value;
            const customerName = document.getElementById('customerName').value;
            const customerPhone = document.getElementById('customerPhone').value;
            const customerNotes = document.getElementById('customerNotes').value;
            
            Swal.fire({
                title: 'Confirm Checkout',
                html: `
                    <div class="text-start">
                        <p><strong>Payment Method:</strong> ${paymentMethod.replace('_', ' ').toUpperCase()}</p>
                        ${customerName ? `<p><strong>Customer:</strong> ${customerName}</p>` : ''}
                        ${customerPhone ? `<p><strong>Phone:</strong> ${customerPhone}</p>` : ''}
                    </div>
                `,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Complete Sale',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    completeSale(paymentMethod, 0, customerName, customerPhone, customerNotes);
                }
            });
        }

        function completeSale(paymentMethod, change = 0, customerName = '', customerPhone = '', notes = '') {
            const saleData = {
                items: cart,
                subtotal: parseFloat(document.getElementById('subtotal').textContent.replace('$', '')),
                tax: parseFloat(document.getElementById('taxAmount').textContent.replace('$', '')),
                total: parseFloat(document.getElementById('totalAmount').textContent.replace('$', '')),
                payment_method: paymentMethod,
                change: change,
                customer_name: customerName,
                customer_phone: customerPhone,
                notes: notes,
                cashier: '<?php echo $_SESSION["username"]; ?>',
                timestamp: new Date().toISOString()
            };
            
            // Save to database
            fetch('save_sale.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(saleData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Print receipt
                    printReceipt(saleData, data.sale_id);
                    
                    // Clear cart
                    cart = [];
                    updateCart();
                    
                    // Close modals
                    const fastCashModal = bootstrap.Modal.getInstance(document.getElementById('fastCashModal'));
                    const checkoutModal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
                    
                    if (fastCashModal) fastCashModal.hide();
                    if (checkoutModal) checkoutModal.hide();
                    
                    // Show success message
                    Swal.fire({
                        title: 'Sale Completed!',
                        text: 'Transaction completed successfully',
                        icon: 'success',
                        timer: 2000
                    }).then(() => {
                        // Reload products to update stock
                        loadProducts();
                    });
                } else {
                    showNotification('Error: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Network error. Please check your connection.', 'error');
            });
        }

function printReceipt(saleData, receiptNumber, settings = {}) {
    const storeSettingsToUse = Object.keys(settings).length > 0 ? settings : storeSettings;
    
    const storeName = storeSettingsToUse.store_name || 'Grocery Store POS';
    const storeAddress = storeSettingsToUse.store_address || '';
    const storePhone = storeSettingsToUse.store_phone || '';
    const receiptFooter = storeSettingsToUse.receipt_footer || 'Thank you for shopping with us!';
    const taxRate = parseFloat(storeSettingsToUse.tax_rate || 0.0);
    
    const receiptWindow = window.open('', '_blank', 'width=600,height=700');
    
    receiptWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Receipt</title>
            <style>
                @media print {
                    @page { margin: 0; }
                    body { margin: 0.5cm; }
                }
                body { 
                    font-family: 'Courier New', monospace; 
                    max-width: 80mm; 
                    margin: 0 auto; 
                    padding: 10px;
                    font-size: 13px;
                    color: #000;
                }
                .header { text-align: center; margin-bottom: 15px; }
                .header h2 { margin: 0; font-size: 18px; font-weight: bold; }
                .store-info { font-size: 12px; margin: 2px 0; }
                .details { margin: 15px 0; font-size: 12px; }
                .details div { margin-bottom: 2px; }
                table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 10px; }
                th, td { padding: 5px; text-align: left; }
                th { border-bottom: 2px solid #000; }
                td { border-bottom: 1px dashed #000; }
                .text-right { text-align: right; }
                .total, .subtotal, .tax { font-weight: bold; font-size: 14px; }
                .totals { margin-top: 10px; }
                .footer { text-align: center; margin-top: 20px; font-size: 11px; border-top: 1px dashed #000; padding-top: 5px; }
                .line { border-bottom: 1px dashed #000; margin: 5px 0; }
            </style>
        </head>
        <body>
            <div class="header">
                <h2>${storeName}</h2>
                ${storeAddress ? `<div class="store-info">${storeAddress}</div>` : ''}
                ${storePhone ? `<div class="store-info">📞 ${storePhone}</div>` : ''}
            </div>
            
            <div class="details">
                <div><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>
                <div><strong>Time:</strong> ${new Date().toLocaleTimeString()}</div>
                <div><strong>Cashier:</strong> ${saleData.cashier}</div>
                <div><strong>Receipt #:</strong> ${receiptNumber}</div>
            </div>
            
            <table>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th class="text-right">Price</th>
                    <th class="text-right">Total</th>
                </tr>
                ${saleData.items.map(item => `
                    <tr>
                        <td>${item.name}</td>
                        <td>${item.quantity}</td>
                        <td class="text-right">$${item.price.toFixed(2)}</td>
                        <td class="text-right">$${(item.price * item.quantity).toFixed(2)}</td>
                    </tr>
                `).join('')}
            </table>

            <div class="totals">
                <div class="subtotal">Subtotal: $${saleData.subtotal.toFixed(2)}</div>
                <div class="tax">Tax (${taxRate}%): $${saleData.tax.toFixed(2)}</div>
                <div class="total">TOTAL: $${saleData.total.toFixed(2)}</div>
                <div>Payment: ${saleData.payment_method.toUpperCase()}</div>
                ${saleData.change > 0 ? `<div>Change: $${saleData.change.toFixed(2)}</div>` : ''}
            </div>
            
            <div class="footer">
                ${receiptFooter}
            </div>
        </body>
        </html>
    `);
    
    receiptWindow.document.close();
}


        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            const dateString = now.toLocaleDateString([], {weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'});
            document.getElementById('currentTime').textContent = `${dateString} ${timeString}`;
        }

        function logout() {
            Swal.fire({
                title: 'Logout',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, logout!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        }

        function activateWindows() {
            Swal.fire({
                title: 'Activate Windows',
                text: 'This feature is for demonstration purposes only.',
                icon: 'info',
                confirmButtonText: 'OK'
            });
        }

        function showNotification(message, type = 'info') {
            // Remove existing notifications
            document.querySelectorAll('.notification').forEach(n => n.remove());
            
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : type === 'error' ? 'times-circle' : 'info-circle'} me-2"></i>
                ${message}
            `;
            
            document.body.appendChild(notification);
            
            // Remove after 3 seconds
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }, 3000);
        }
    </script>
</body>
</html>