<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Sale</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">POS System</a>
            <div class="d-flex">
                <span class="navbar-text text-white me-3">
                    Cashier: <?php echo htmlspecialchars($_SESSION['username']); ?>
                </span>
                <a href="dashboard.php" class="btn btn-outline-light btn-sm me-2">Dashboard</a>
                <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3><i class="fas fa-cash-register"></i> New Sale</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card mb-3">
                            <div class="card-header">Add Items</div>
                            <div class="card-body">
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" placeholder="Scan barcode or enter product name">
                                    <button class="btn btn-primary">Add Item</button>
                                </div>
                                
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Price</th>
                                                <th>Qty</th>
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="cartItems">
                                            <tr>
                                                <td colspan="5" class="text-center text-muted">
                                                    No items added yet
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">Payment</div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="form-label">Subtotal</label>
                                    <div class="h4">$0.00</div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Tax (8.5%)</label>
                                    <div class="h5">$0.00</div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Total</label>
                                    <div class="h3 text-success">$0.00</div>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button class="btn btn-success btn-lg">Cash Payment</button>
                                    <button class="btn btn-primary btn-lg">Card Payment</button>
                                    <button class="btn btn-warning">Cancel Sale</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>