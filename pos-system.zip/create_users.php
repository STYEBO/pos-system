<?php
include "db.php";

// Admin account
$admin_username = "admin";
$admin_password = password_hash("admin123", PASSWORD_DEFAULT);
$admin_role     = "admin";

// Cashier account
$cashier_username = "cashier";
$cashier_password = password_hash("cashier123", PASSWORD_DEFAULT);
$cashier_role     = "cashier";

// Test account
$test_username = "test";
$test_password = password_hash("test123", PASSWORD_DEFAULT);
$test_role     = "cashier";

echo "<div style='padding: 20px; font-family: Arial;'>";
echo "<h2>Creating Default Users</h2>";
echo "<hr>";

// Function to create user if not exists
function createUser($conn, $username, $password, $role) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<div style='margin: 10px 0; padding: 10px; background: #fff3cd; border-left: 4px solid #ffc107;'>";
        echo "$username already exists.";
        echo "</div>";
        return false;
    } else {
        $insert = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        $insert->bind_param("sss", $username, $password, $role);
        if ($insert->execute()) {
            echo "<div style='margin: 10px 0; padding: 10px; background: #d4edda; border-left: 4px solid #28a745;'>";
            echo "$username created successfully.";
            echo "</div>";
            return true;
        } else {
            echo "<div style='margin: 10px 0; padding: 10px; background: #f8d7da; border-left: 4px solid #dc3545;'>";
            echo "Error creating $username: " . $conn->error;
            echo "</div>";
            return false;
        }
    }
}

createUser($conn, $admin_username, $admin_password, $admin_role);
createUser($conn, $cashier_username, $cashier_password, $cashier_role);
createUser($conn, $test_username, $test_password, $test_role);

echo "<hr>";
echo "<h3>Default Login Credentials:</h3>";
echo "<ul>";
echo "<li><strong>Admin:</strong> admin / admin123</li>";
echo "<li><strong>Cashier:</strong> cashier / cashier123</li>";
echo "<li><strong>Test:</strong> test / test123</li>";
echo "</ul>";
echo "<p><strong>Important:</strong> Change these passwords after first login!</p>";
echo "</div>";

$conn->close();
?>