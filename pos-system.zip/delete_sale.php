<?php
// delete_sale.php
session_start();

// Check if user is admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

require_once 'db.php';

$sale_id = $_GET['id'] ?? 0;

if ($sale_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid sale ID']);
    exit;
}

try {
    $conn->begin_transaction();
    
    // First delete sale items
    $delete_items = "DELETE FROM sale_items WHERE sale_id = ?";
    $stmt1 = $conn->prepare($delete_items);
    $stmt1->bind_param("i", $sale_id);
    $stmt1->execute();
    
    // Then delete the sale
    $delete_sale = "DELETE FROM sales WHERE id = ?";
    $stmt2 = $conn->prepare($delete_sale);
    $stmt2->bind_param("i", $sale_id);
    $stmt2->execute();
    
    $conn->commit();
    
    echo json_encode(['success' => true, 'message' => 'Sale deleted successfully']);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

$conn->close();
?>