<?php
session_start();
require_once 'db.php';

/* ================= AUTH ================= */
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

if (($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: pos.php");
    exit;
}

/* ================= DELETE (MUST BE BEFORE HTML) ================= */
if (isset($_GET['delete'])) {

    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $_SESSION['message'] = "Product deleted successfully";
    } else {
        $_SESSION['error'] = "Error deleting product";
    }

    $stmt->close();

    // ✅ NOW REDIRECT WORKS
    header("Location: manage_products.php");
    exit;
}

/* ================= FETCH PRODUCTS ================= */
$products = $conn->query("
    SELECT p.*, c.name AS category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    ORDER BY p.id DESC
");

/* ================= HTML HEADER ================= */
include "header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Products</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>

<body>
<div class="container-fluid mt-3">

<h3><i class="fas fa-boxes"></i> Manage Products</h3>

<!-- ALERTS -->
<?php if (!empty($_SESSION['message'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?= $_SESSION['message']; unset($_SESSION['message']); ?>
    <button class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (!empty($_SESSION['error'])): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <?= $_SESSION['error']; unset($_SESSION['error']); ?>
    <button class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<table class="table table-hover">
<thead class="table-dark">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Category</th>
    <th>Price</th>
    <th>Stock</th>
    <th>Action</th>
</tr>
</thead>

<tbody>
<?php while ($p = $products->fetch_assoc()): ?>
<tr>
    <td><?= $p['id'] ?></td>
    <td><?= htmlspecialchars($p['name']) ?></td>
    <td><?= htmlspecialchars($p['category_name'] ?? 'N/A') ?></td>
    <td>$<?= number_format($p['price'],2) ?></td>
    <td><?= $p['quantity'] ?></td>
    <td>
        <a href="edit_product.php?id=<?= $p['id'] ?>" class="btn btn-warning btn-sm">
            <i class="fas fa-edit"></i>
        </a>

        <a href="manage_products.php?delete=<?= $p['id'] ?>"
           class="btn btn-danger btn-sm"
           onclick="return confirm('Delete this product?')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
