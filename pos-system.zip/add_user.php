<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    echo "Unauthorized";
    exit;
}

include "db.php";

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? 'cashier';

if (empty($username) || empty($password)) {
    echo "Username and password are required";
    exit;
}

if (strlen($password) < 4) {
    echo "Password must be at least 4 characters";
    exit;
}

if (!in_array($role, ['admin', 'cashier'])) {
    echo "Invalid role";
    exit;
}

// Check if username exists
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "Username already exists";
    exit;
}

// Hash password and insert
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $hashedPassword, $role);

if ($stmt->execute()) {
    echo "User created successfully";
} else {
    echo "Error creating user";
}

$stmt->close();
$conn->close();
?>