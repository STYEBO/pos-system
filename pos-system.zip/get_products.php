<?php
// get_products.php
require_once 'db.php';

header('Content-Type: application/json');

try {
    $sql = "SELECT * FROM products WHERE quantity > 0 ORDER BY name";
    $result = $conn->query($sql);
    
    $products = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
    }
    
    echo json_encode($products);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

$conn->close();
?>