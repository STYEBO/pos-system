<?php
// update_product_debug.php - DEBUG VERSION
session_start();
require_once 'db.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html><html><head><title>Debug Update</title></head><body>";
echo "<h2>Update Product Debug Page</h2>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<h3>Received POST Data:</h3>";
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
    
    $product_id = intval($_POST['product_id']);
    echo "<p>Product ID: $product_id</p>";
    
    // Simple test query
    $test_name = $conn->real_escape_string($_POST['name']);
    $sql = "UPDATE products SET name = '$test_name' WHERE id = $product_id";
    
    echo "<h3>SQL Query:</h3>";
    echo "<p>$sql</p>";
    
    if ($conn->query($sql) === TRUE) {
        echo "<h3 style='color:green;'>SUCCESS: Product updated!</h3>";
        $_SESSION['message'] = "Product updated successfully";
        
        // Redirect
        echo "<script>
            setTimeout(function(){
                window.location.href = 'manage_products.php';
            }, 3000);
        </script>";
        echo "<p>Redirecting in 3 seconds...</p>";
    } else {
        echo "<h3 style='color:red;'>ERROR: " . $conn->error . "</h3>";
    }
} else {
    echo "<p>No POST data received.</p>";
}

echo "</body></html>";
?>