<?php
session_start();
require_once 'db.php';

$sale_id = $_GET['id'] ?? 0;

/* ================= FETCH SETTINGS ================= */
$settings = [];
$res = $conn->query("SELECT setting_key, setting_value FROM system_settings");
while ($row = $res->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$store_name   = $settings['store_name'] ?? 'My Store';
$store_phone  = $settings['store_phone'] ?? '';
$store_addr   = $settings['store_address'] ?? '';
$footer_text  = $settings['receipt_footer'] ?? 'Thank you for shopping with us';

/* ================= FETCH SALE ================= */
$stmt = $conn->prepare("SELECT * FROM sales WHERE id=?");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();

if (!$sale) {
    die("Sale not found");
}

/* ================= FETCH ITEMS ================= */
$stmt = $conn->prepare("
    SELECT si.*, p.name 
    FROM sale_items si 
    JOIN products p ON p.id = si.product_id 
    WHERE si.sale_id=?
");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$tax_rate = $sale['subtotal'] > 0 ? ($sale['tax'] / $sale['subtotal']) * 100 : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Receipt #<?= $sale_id ?></title>

<style>
/* ================= COMMON ================= */
body{
    font-family: "Courier New", monospace;
    width: 80mm;
    margin: 0 auto;              /* ✅ CENTER */
    padding: 12px;
    background: #fff;
    font-size: 13px;
    line-height: 1.3;
}

/* ================= PRINT ================= */
@media print{
    @page{ margin:0; }
    body{
        margin: 0 auto !important; /* ✅ CENTER PRINT */
        padding: 8px;
        font-size: 12px;
    }
    .no-print{ display:none !important; }
}

/* ================= HEADER ================= */
.header{
    text-align:center;
    border-bottom:1px dashed #000;
    padding-bottom:6px;
    margin-bottom:6px;
}
.header h2{
    margin:4px 0;
    font-size:18px;
}

/* ================= META ================= */
.meta{
    font-size:11px;
    border-bottom:1px dashed #000;
    margin-bottom:6px;
    padding-bottom:6px;
}
.meta div{
    display:flex;
    justify-content:space-between;
}

/* ================= TABLE ================= */
table{
    width:100%;
    border-collapse:collapse;
    font-size:11px;
}
th{
    text-align:left;
    border-bottom:1px solid #000;
}
td{ padding:2px 0; }
.right{ text-align:right; }

/* ================= TOTALS ================= */
.totals{
    font-size:11px;
    margin-top:6px;
}
.totals div{
    display:flex;
    justify-content:space-between;
}
.grand{
    border-top:2px solid #000;
    font-weight:bold;
    margin-top:4px;
    padding-top:4px;
}

/* ================= FOOTER ================= */
.footer{
    text-align:center;
    border-top:1px dashed #000;
    margin-top:10px;
    padding-top:6px;
    font-size:10px;
}

/* ================= BUTTONS ================= */
.no-print{
    position:fixed;
    top:20px;
    right:20px;
}
button{
    padding:8px 14px;
    margin:4px;
    font-weight:bold;
    cursor:pointer;
}
</style>
</head>

<body>

<!-- ===== CONTROLS ===== -->
<div class="no-print">
    <button onclick="window.print()">🖨 Print</button>
    <button onclick="window.close()">✖ Close</button>
</div>

<!-- ===== RECEIPT ===== -->
<div class="header">
    <h2><?= htmlspecialchars($store_name) ?></h2>
    <?php if($store_addr): ?><div><?= htmlspecialchars($store_addr) ?></div><?php endif; ?>
    <?php if($store_phone): ?><div>📞 <?= htmlspecialchars($store_phone) ?></div><?php endif; ?>
</div>

<div class="meta">
    <div><span>Date</span><span><?= date('Y-m-d', strtotime($sale['created_at'])) ?></span></div>
    <div><span>Time</span><span><?= date('H:i:s', strtotime($sale['created_at'])) ?></span></div>
    <div><span>Cashier</span><span><?= htmlspecialchars($sale['cashier']) ?></span></div>
    <div><span>Receipt #</span><span><?= $sale['id'] ?></span></div>
</div>

<table>
<thead>
<tr>
    <th>Item</th>
    <th class="right">Qty</th>
    <th class="right">Price</th>
    <th class="right">Total</th>
</tr>
</thead>
<tbody>
<?php foreach($items as $i): ?>
<tr>
    <td><?= htmlspecialchars($i['name']) ?></td>
    <td class="right"><?= $i['quantity'] ?></td>
    <td class="right">$<?= number_format($i['unit_price'],2) ?></td>
    <td class="right">$<?= number_format($i['total_price'],2) ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<div class="totals">
    <div><span>Subtotal</span><span>$<?= number_format($sale['subtotal'],2) ?></span></div>
    <div><span>Tax (<?= number_format($tax_rate,1) ?>%)</span><span>$<?= number_format($sale['tax'],2) ?></span></div>
    <div class="grand"><span>TOTAL</span><span>$<?= number_format($sale['total'],2) ?></span></div>
</div>

<div class="footer">
    <?= htmlspecialchars($footer_text) ?><br>
    Please keep this receipt
</div>

<script>
// Auto print
window.onload = function(){
    setTimeout(function(){
        window.print();
    }, 400);
};
</script>

</body>
</html>
<?php $conn->close(); ?>
