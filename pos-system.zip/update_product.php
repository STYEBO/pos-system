<?php
// update_product.php - CORRECTED FOR YOUR TABLE STRUCTURE
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
if ($user_role != 'admin') {
    header("Location: pos.php");
    exit;
}

require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = intval($_POST['product_id']);
    $name = $conn->real_escape_string(trim($_POST['name']));
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $min_stock = intval($_POST['min_stock']);
    $barcode = isset($_POST['barcode']) ? $conn->real_escape_string(trim($_POST['barcode'])) : '';
    
    // Handle image upload
    $image_update = false;
    $image_path = '';
    
    // Check if remove image is checked
    if (isset($_POST['remove_image']) && $_POST['remove_image'] == '1') {
        $image_update = true;
        $image_path = ''; // Empty string to remove image
    } 
    // Handle new image upload
    elseif (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = $_FILES['image']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            $upload_dir = 'uploads/products/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = 'product_' . $product_id . '_' . time() . '.' . $file_extension;
            $destination = $upload_dir . $filename;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                $image_update = true;
                $image_path = $destination;
            }
        }
    }
    
    // Prepare SQL based on whether we have image to update or not
    if ($image_update) {
        $stmt = $conn->prepare("UPDATE products SET 
            name = ?, 
            price = ?, 
            quantity = ?, 
            min_stock = ?, 
            barcode = ?, 
            image = ? 
            WHERE id = ?");
        $stmt->bind_param("sdiissi", $name, $price, $quantity, $min_stock, $barcode, $image_path, $product_id);
    } else {
        $stmt = $conn->prepare("UPDATE products SET 
            name = ?, 
            price = ?, 
            quantity = ?, 
            min_stock = ?, 
            barcode = ? 
            WHERE id = ?");
        $stmt->bind_param("sdiisi", $name, $price, $quantity, $min_stock, $barcode, $product_id);
    }
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Product updated successfully";
    } else {
        $_SESSION['error'] = "Error updating product: " . $stmt->error;
    }
    
    $stmt->close();
    header("Location: manage_products.php");
    exit;
} else {
    header("Location: manage_products.php");
    exit;
}
?>