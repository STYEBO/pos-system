<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo "Invalid request";
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    echo "Username and password are required";
    exit;
}

// Fetch user
$stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "Invalid username or password";
    exit;
}

$stmt->bind_result($user_id, $hashedPassword, $role);
$stmt->fetch();

// Verify password
if (password_verify($password, $hashedPassword)) {
    // Regenerate session ID to prevent fixation
    session_regenerate_id(true);
    
    $_SESSION['user_id'] = $user_id;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
    $_SESSION['login_time'] = time();

    echo trim($role);
} else {
    echo "Invalid username or password";
}

$stmt->close();
$conn->close();
?>