<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

include ("header.php");

// Admin check
$user_role = $_SESSION['role'] ?? 'cashier';
if ($user_role !== 'admin') {
    header("Location: dashboard.php");
    exit;
}

require_once 'db.php';

/* =========================
   DELETE CATEGORY (AJAX)
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_category'])) {

    header('Content-Type: application/json');

    $category_id = (int)$_POST['category_id'];
    $response = ['success' => false, 'message' => ''];

    $checkStmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
    $checkStmt->bind_param("i", $category_id);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        $category = $result->fetch_assoc();

        if ($category['name'] === 'All Items') {
            $response['message'] = 'System category cannot be deleted';
        } else {
            $deleteStmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
            $deleteStmt->bind_param("i", $category_id);

            if ($deleteStmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Category deleted successfully';
            } else {
                $response['message'] = 'Delete failed';
            }
            $deleteStmt->close();
        }
    } else {
        $response['message'] = 'Category not found';
    }

    $checkStmt->close();
    echo json_encode($response);
    exit;
}

/* =========================
   FETCH CATEGORIES
========================= */
$categories = $conn->query("SELECT * FROM categories ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Categories</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: #f5f5f5;
    font-family: 'Segoe UI', Arial, sans-serif;
}
.card {
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}
.table thead th {
    background: #001f3f;
    color: #fff;
}
</style>
</head>

<body>

<br><br>

<div class="container-fluid">
    <div class="d-flex justify-content-between mb-4">
        <h3>Manage Categories</h3>
        <a href="add_category.php" class="btn btn-primary">Add Category</a>
    </div>

    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($cat = $categories->fetch_assoc()): ?>
                        <tr>
                            <td><?= $cat['id']; ?></td>
                            <td><?= htmlspecialchars($cat['name']); ?></td>
                            <td><?= date('M d, Y H:i', strtotime($cat['created_at'])); ?></td>
                            <td>
                                <?php if ($cat['name'] !== 'All Items'): ?>
                                    <a href="edit_category.php?id=<?= $cat['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <button class="btn btn-sm btn-danger"
                                            onclick="deleteCategory(<?= $cat['id']; ?>, '<?= addslashes($cat['name']); ?>')">
                                        Delete
                                    </button>
                                <?php else: ?>
                                    <span class="text-muted fst-italic">System Category</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
function deleteCategory(id, name) {
    if (!confirm(`Are you sure you want to delete "${name}"?`)) return;

    $.ajax({
        url: 'manage_categories.php',
        type: 'POST',
        dataType: 'json',
        data: {
            delete_category: true,
            category_id: id
        },
        success: function(response) {
            if (response.success) {
                alert(response.message);

                // 🔥 FORCE RELOAD (NO CACHE)
                window.location.href =
                    window.location.pathname + '?refresh=' + new Date().getTime();

            } else {
                alert(response.message);
            }
        },
        error: function() {
            alert('Server error. Try again.');
        }
    });
}
</script>

</body>
</html>
