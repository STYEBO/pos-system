<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    echo "Unauthorized";
    exit;
}

include "db.php";

$id = intval($_POST['id'] ?? 0);
$role = $_POST['role'] ?? '';

if ($id <= 0 || !in_array($role, ['admin', 'cashier'])) {
    echo "Invalid data";
    exit;
}

$stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
$stmt->bind_param("si", $role, $id);

if ($stmt->execute()) {
    echo "User role updated successfully";
} else {
    echo "Error updating user";
}

$stmt->close();
$conn->close();
?>