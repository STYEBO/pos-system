<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Session expired. Please login again.']);
    exit;
}

// Check if user is admin
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
if ($user_role != 'admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Access denied. Admin only.']);
    exit;
}

require_once 'db.php';

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => ''];
    
    // Get data from POST
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $category_name = isset($_POST['category_name']) ? trim($_POST['category_name']) : '';
    
    // Validate inputs
    if ($category_id <= 0) {
        $response['message'] = 'Invalid category ID';
    } elseif (empty($category_name)) {
        $response['message'] = 'Category name cannot be empty';
    } else {
        // Check if category exists
        $checkStmt = $conn->prepare("SELECT id, name FROM categories WHERE id = ?");
        if ($checkStmt) {
            $checkStmt->bind_param("i", $category_id);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            
            if ($checkResult->num_rows === 0) {
                $response['message'] = 'Category not found';
            } else {
                $category = $checkResult->fetch_assoc();
                
                // Don't allow editing of 'All Items' category name
                if ($category['name'] == 'All Items' && $category_name != 'All Items') {
                    $response['message'] = 'Cannot rename system category "All Items"';
                } else {
                    // Check if new name already exists (excluding current category)
                    $nameCheckStmt = $conn->prepare("SELECT id FROM categories WHERE name = ? AND id != ?");
                    if ($nameCheckStmt) {
                        $nameCheckStmt->bind_param("si", $category_name, $category_id);
                        $nameCheckStmt->execute();
                        $nameResult = $nameCheckStmt->get_result();
                        
                        if ($nameResult->num_rows > 0) {
                            $response['message'] = 'Category name already exists';
                        } else {
                            // Update the category
                            $updateStmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
                            if ($updateStmt) {
                                $updateStmt->bind_param("si", $category_name, $category_id);
                                
                                if ($updateStmt->execute()) {
                                    $response['success'] = true;
                                    $response['message'] = 'Category updated successfully';
                                    $response['new_name'] = $category_name;
                                } else {
                                    $response['message'] = 'Failed to update category';
                                }
                                $updateStmt->close();
                            } else {
                                $response['message'] = 'Database error';
                            }
                        }
                        $nameCheckStmt->close();
                    } else {
                        $response['message'] = 'Database error';
                    }
                }
            }
            $checkStmt->close();
        } else {
            $response['message'] = 'Database error';
        }
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// If not POST request, return error
header('Content-Type: application/json');
echo json_encode(['success' => false, 'message' => 'Invalid request method']);
exit;
?>