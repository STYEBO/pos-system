DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `categories` VALUES ('1','ARROZ');
INSERT INTO `categories` VALUES ('2','LEGUMES SECOS');
INSERT INTO `categories` VALUES ('3','MASSA');
INSERT INTO `categories` VALUES ('4','AZEITE OIL');
INSERT INTO `categories` VALUES ('5','OIL ALIMENTAR');
INSERT INTO `categories` VALUES ('6','POLPA TOMATO');
INSERT INTO `categories` VALUES ('7','MOLHO');
INSERT INTO `categories` VALUES ('8','SAL');
INSERT INTO `categories` VALUES ('9','CALDO');
INSERT INTO `categories` VALUES ('10','PASTE');
INSERT INTO `categories` VALUES ('11','FLOCOS');
INSERT INTO `categories` VALUES ('12','FARINHA');
INSERT INTO `categories` VALUES ('13','PRONTO A COMER');
INSERT INTO `categories` VALUES ('14','fruit');

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `barcode` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) DEFAULT 0,
  `unit` varchar(20) DEFAULT 'pcs',
  `min_stock` int(11) DEFAULT 5,
  `image` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `barcode` (`barcode`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `products` VALUES ('1','UP ARROZ AGULHA 1KG','5606262025079','1.45','100','pcs','100','0','1');
INSERT INTO `products` VALUES ('2','UP ARROZ CAROLINO 1KG','5606262025086','1.45','100','pcs','100','0','1');
INSERT INTO `products` VALUES ('3','CIGALA THAI JASMIM 1KG','5601260018108','2.10','100','pcs','100','0','1');
INSERT INTO `products` VALUES ('4','CIGALA BASMATI 1KG','5601260038106','2.89','100','pcs','100','0','1');
INSERT INTO `products` VALUES ('5','CIGALA AGULHA VAPORIZADO 1KG','5601260127107','1.85','100','pcs','100','0','1');
INSERT INTO `products` VALUES ('6','CIGALA AGULHA AZUL 1KG','5601260037109','1.99','100','pcs','100','0','1');
INSERT INTO `products` VALUES ('7','CIGALA CAROLINO 1KG','5601260036102','2.15','100','pcs','100','0','1');
INSERT INTO `products` VALUES ('8','ORIENTE AGULHA LONG GRAIN 1KG','5601228228013','1.80','100','pcs','100','0','1');
INSERT INTO `products` VALUES ('9','UP LEGUMES SECOS FEIJAO PRETO 500G','5606262010465','1.35','100','pcs','100','0','2');
INSERT INTO `products` VALUES ('10','UP LEGUMES SECOS GRAO DE BICO 500G','5606262010471','1.20','100','pcs','100','0','2');
INSERT INTO `products` VALUES ('11','UP LEGUMES SECOS FEIJAO BRANCO 500G','5606262010419','0.01','100','pcs','100','0','2');
INSERT INTO `products` VALUES ('12','UP LEGUMES SECOS FEIJAO CATARINO 500G','5606262010426','1.45','100','pcs','100','0','2');
INSERT INTO `products` VALUES ('13','UP LEGUMES SECOS FEIJAO FRADE 500G','5606262010440','1.35','100','pcs','100','0','2');
INSERT INTO `products` VALUES ('14','NACIONAL MACARRONETE 500G 8-10MIN','5601066300742','1.25','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('15','NACIONAL COTOVELOS GRANDES 500G 7-9MIN','5601066300285','1.25','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('16','NACIONAL FIOS DE ALETRIA 500G','5601066300803','1.25','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('17','NACIONAL BUZIOS 500GR 9-11MIN','5601066301053','1.50','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('18','NACIONAL MACARRAO GR 500G 10-12MIN','5601066301978','1.25','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('19','NACIONAL PONTINHA 250G 11-13','5601066300544','0.80','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('20','NACIONAL PEVIDE 250G 9-11MIN','5601066300483','0.80','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('21','NACIONAL ESTRELINHA 250G 9-11MIN','5601066300384','0.80','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('22','NACIONAL PEROLAS 250G 9-11MIN','5601066300315','0.80','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('23','NACIONAL ESPARGUETE 500G 7-9MIN','5601066302449','1.15','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('24','MILANEZA SPAGHETTI 500G 7-9MIN','5601286201782','1.25','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('25','MILANEZA TALHARIM 500G 10-12MIN','5601286205780','2.49','0','pcs','5','0','3');
INSERT INTO `products` VALUES ('26','NACIONAL MEADA 500G 8-10MIN','5601066301213','0.01','100','pcs','100','0','3');
INSERT INTO `products` VALUES ('27','ALTEZA LASANA 350G 30-35MIN','8480024761378','1.25','99','pcs','100','0','3');
INSERT INTO `products` VALUES ('28','GALLO CLASSICO AZEITE VIRGEM EXTRA 750ML','5601252106653','8.85','100','pcs','100','0','4');
INSERT INTO `products` VALUES ('29','OLIVEIRA DA SERRA AZEITE VERMELHO 750ML','5601024134136','5.10','100','pcs','100','0','4');
INSERT INTO `products` VALUES ('30','GALLO AZEITE SUBTIL 500ML','5601252106554','4.25','100','pcs','100','0','4');
INSERT INTO `products` VALUES ('31','GALLO DELICADO AZEITE VIRGEM 750ML','5601252106639','6.99','100','pcs','100','0','4');
INSERT INTO `products` VALUES ('32','GALLO SUBTIL 750ML','5601252106615','7.99','100','pcs','100','0','4');
INSERT INTO `products` VALUES ('33','FULA ORIGINAL 1LT','5601024105020','2.59','100','pcs','100','0','5');
INSERT INTO `products` VALUES ('34','MASTER CHEF OILEO DE GIRASSOL 1LT','5601227021868','2.59','100','pcs','100','0','5');
INSERT INTO `products` VALUES ('35','GULOSO POLPA DE TOMATE 80 ANOS 1000G','5601019012418','2.99','100','pcs','100','0','6');
INSERT INTO `products` VALUES ('36','UP POLPA DE TOMATE 500G','5606262011102','1.25','100','pcs','100','0','6');
INSERT INTO `products` VALUES ('37','UP POLPA DE TOMATE COM ALHO E CEBOLA 500G','5606262011126','1.70','100','pcs','100','0','6');
INSERT INTO `products` VALUES ('38','GULOSO POLPA DE TOMATE 80 ANOS 210G','5601019012135','0.85','100','pcs','100','0','6');
INSERT INTO `products` VALUES ('39','DOM DUARTE MOLHO ORIGINAL 435G','5608771702052','2.90','100','pcs','100','0','7');
INSERT INTO `products` VALUES ('40','DOM DUARTE MOLHO COGUMELOS 435G','5608771702014','2.90','100','pcs','100','0','7');
INSERT INTO `products` VALUES ('41','DOM DUARTE MOLHO NAPOLITANO 440G','5608771702045','2.90','100','pcs','100','0','7');
INSERT INTO `products` VALUES ('42','DOM DUARTE MOLHO PIZZA E MASSA 500G','5608771013141','2.55','100','pcs','100','0','7');
INSERT INTO `products` VALUES ('43','SALDOMAR 250G','5601118000040','0.55','100','pcs','100','0','8');
INSERT INTO `products` VALUES ('44','VATEL SAL MARINHO 1KG','5601170163356','0.70','100','pcs','100','0','8');
INSERT INTO `products` VALUES ('45','UP SAL MARINHO 1KG','5606262032039','0.60','100','pcs','100','0','8');
INSERT INTO `products` VALUES ('46','KNOOR CALDO DE CARNE 8 CUBOS 80G','8721201956614','1.49','100','pcs','100','0','9');
INSERT INTO `products` VALUES ('47','KNOOR CALDO DE GALINHA 8 CUBOS 80G','5601038300077','1.60','100','pcs','100','0','9');
INSERT INTO `products` VALUES ('48','KNOOR CALDO DE PEIXE COM AZEITE VIREGEM EXTRA 8 CUBOS 80G','8720182626004','1.69','100','pcs','100','0','9');
INSERT INTO `products` VALUES ('49','KNOOR CALDO PARA BIFES 8 CUBOS 80G','8722700160809','1.49','100','pcs','100','0','9');
INSERT INTO `products` VALUES ('50','KNOOR CALDO DE MARISCO 8 CUBOS  80G','5601038009031','1.75','100','pcs','100','0','9');
INSERT INTO `products` VALUES ('51','KNOOR CALDO PARA ARROZ 8 CUBOS 80G','8722700086703','1.49','100','pcs','100','0','9');
INSERT INTO `products` VALUES ('52','KNOOR SOPA DE ESPARGOS 4 PORCOES 65G','8720182975874','1.70','100','pcs','100','0','9');
INSERT INTO `products` VALUES ('53','KNOOR CANJA DE GALINHA 4 PORCOES 68G','8712566173860','1.70','100','pcs','100','0','9');
INSERT INTO `products` VALUES ('54','DOM DUARTE MASSA DE ALHO 200G FRS','5608771084110','1.55','100','pcs','100','0','10');
INSERT INTO `products` VALUES ('55','DOM DUARTE TEMPREO PARA FRANGO 200G FRS','5608771080112','1.55','100','pcs','100','0','10');
INSERT INTO `products` VALUES ('56','DOM DUARTE TEMPERA COMPLETO 200G FRS','5608771083014','1.55','100','pcs','100','0','10');
INSERT INTO `products` VALUES ('57','DOM DUARTE VINHA\'D ALHO 200G FRS','5608771083113','1.55','100','pcs','100','0','10');
INSERT INTO `products` VALUES ('58','DOM DUARTE MOHLO PESTO 185G FRS','5608771703011','2.99','100','pcs','100','0','10');
INSERT INTO `products` VALUES ('59','DOM DUARTE FECULA DE BATATA 250G','5608771303136','1.50','100','pcs','100','0','11');
INSERT INTO `products` VALUES ('60','FERBAR KIMILHO FLOCAO 400G','5601319063998','1.99','100','pcs','100','0','11');
INSERT INTO `products` VALUES ('61','MATIAS FARINHA DE MILHO BRANCA 500G','5608447120227','0.89','100','pcs','100','0','11');
INSERT INTO `products` VALUES ('62','ARMEL PAO RALADO 250G','5603223000113','0.70','100','pcs','100','0','11');
INSERT INTO `products` VALUES ('63','CIMARROM FLOCOS DE BATATA PARA PURE 200G','5601254015052','1.80','100','pcs','100','0','11');
INSERT INTO `products` VALUES ('64','MATIAS FARINHA DE MANDIOCA','5608447010672','1.99','100','pcs','100','0','11');
INSERT INTO `products` VALUES ('65','WE NATURAL PURE DE BATATA 230G','8435119500028','1.50','100','pcs','100','0','12');
INSERT INTO `products` VALUES ('66','KNOOR GRAN PURE BATATA 225G','8001080030743','2.75','100','pcs','100','0','12');
INSERT INTO `products` VALUES ('67','MOUSLINE PURE DE BATATA EM FLOCOS','3760381261915','2.99','100','pcs','100','0','12');
INSERT INTO `products` VALUES ('68','MAIZENA HARINA FINA DE MAIZ AMIDO DE MILHO 400G','8711100080060','2.15','100','pcs','100','0','12');
INSERT INTO `products` VALUES ('69','BRANCA DE NEVE FINA SEM FERMENTO 1KG','5601043111019','1.65','100','pcs','100','0','12');
INSERT INTO `products` VALUES ('70','ESPIGA FARINHA DE TRIGO TIPO 65 SEM FERMENTO 1KG','5601043111149','1.35','100','pcs','100','0','12');
INSERT INTO `products` VALUES ('71','NACIONAL EXTRA FINA SEM FERMENTO T55 1KG','5601066200073','1.50','100','pcs','100','0','12');
INSERT INTO `products` VALUES ('72','CIGALA ARROZ AGULHA','5601260337025','1.80','100','pcs','100','0','13');
INSERT INTO `products` VALUES ('73','UP MAO DE VACA COM GRAO 420G','5606262050125','0.01','100','pcs','100','0','13');
INSERT INTO `products` VALUES ('74','UP CHISPALHADA 420G','5606262050118','0.01','100','pcs','100','0','13');
INSERT INTO `products` VALUES ('75','UP FEIJAOADA A TRANSMONTANA 420G','5606262050101','0.01','100','pcs','100','0','13');
INSERT INTO `products` VALUES ('76','UP DOPRADA A PORTUGESA 420G','5606262050095','0.01','0','pcs','10','uploads/products/0039613461_69769adf4eee9_1769380575.jpg','13');
INSERT INTO `products` VALUES ('79','Banana','PRD1769376690188','1.59','1','kg','5','0','14');

DROP TABLE IF EXISTS `sale_items`;
CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sale_items` VALUES ('3','2','76','UP DOPRADA A PORTUGESA 420G','1','0.01','0.01','2026-01-25 14:42:34');
INSERT INTO `sale_items` VALUES ('4','3','76','UP DOPRADA A PORTUGESA 420G','1','0.01','0.01','2026-01-25 14:42:51');
INSERT INTO `sale_items` VALUES ('5','4','76','UP DOPRADA A PORTUGESA 420G','1','0.01','0.01','2026-01-25 15:57:38');
INSERT INTO `sale_items` VALUES ('6','5','76','UP DOPRADA A PORTUGESA 420G','1','0.01','0.01','2026-01-25 15:59:25');

DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_date` timestamp NULL DEFAULT current_timestamp(),
  `cashier` varchar(100) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) NOT NULL DEFAULT 'cash',
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `change_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `store_name` varchar(255) DEFAULT 'Grocery Store POS',
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `currency` varchar(10) DEFAULT 'USD',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sales` VALUES ('2','2026-01-25 14:42:34','admin','0.01','0.00','0.00','cash','','','','9.99','2026-01-25 14:42:34','Grocery Store POS','0.00','USD');
INSERT INTO `sales` VALUES ('3','2026-01-25 14:42:51','admin','0.01','0.00','0.00','cash','','','','9.99','2026-01-25 14:42:51','Grocery Store POS','0.00','USD');
INSERT INTO `sales` VALUES ('4','2026-01-25 15:57:38','admin','0.01','0.00','0.00','cash','','','','9.99','2026-01-25 15:57:38','Easy Pos System','0.00','EUR');
INSERT INTO `sales` VALUES ('5','2026-01-25 15:59:25','admin','0.01','0.00','0.00','cash','','','','9.99','2026-01-25 15:59:25','Easy Pos System','0.00','EUR');

DROP TABLE IF EXISTS `stock_movements`;
CREATE TABLE `stock_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `type` enum('IN','OUT','ADJUST') NOT NULL,
  `quantity` int(11) NOT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(50) DEFAULT 'string',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `system_settings` VALUES ('1','store_name','Easy Pos System','string',NULL,'2026-01-25 15:22:16','2026-01-25 15:22:16');
INSERT INTO `system_settings` VALUES ('2','tax_rate','0.0','string',NULL,'2026-01-25 15:22:16','2026-01-25 15:22:16');
INSERT INTO `system_settings` VALUES ('3','currency','EUR','string',NULL,'2026-01-25 15:22:16','2026-01-25 15:22:16');
INSERT INTO `system_settings` VALUES ('4','receipt_footer','Thank you for shopping with us!','string',NULL,'2026-01-25 15:22:16','2026-01-25 15:22:16');
INSERT INTO `system_settings` VALUES ('5','auto_print','1','string',NULL,'2026-01-25 15:22:16','2026-01-25 15:22:16');
INSERT INTO `system_settings` VALUES ('6','store_address','Rua Julio Cancaio 2A','string',NULL,'2026-01-25 15:22:16','2026-01-25 15:22:16');
INSERT INTO `system_settings` VALUES ('7','store_phone','0900-78601','string',NULL,'2026-01-25 15:22:16','2026-01-25 15:22:16');
INSERT INTO `system_settings` VALUES ('8','store_email','testabc@live.com','string',NULL,'2026-01-25 15:22:16','2026-01-25 15:44:43');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','cashier') DEFAULT 'cashier',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `users` VALUES ('1','admin','$2y$10$FWjbrbQKIs76ba9D08pVGe6YiqnPFvBcmoOY0Zgk/YoZudD1ZHcnu','admin','2026-01-17 15:50:41','Aziz ','abc@live.com','454545',NULL,'active');

