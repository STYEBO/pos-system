<?php
include 'auth.php';
include 'db.php';

$backupDir = __DIR__ . "/backups/";
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0777, true);
}

$tables = $conn->query("SHOW TABLES");
if (!$tables) {
    die("Database error!");
}

$sql = "";

while ($row = $tables->fetch_array()) {
    $table = $row[0];

    // Table structure
    $row2 = $conn->query("SHOW CREATE TABLE `$table`")->fetch_row();
    $sql .= "DROP TABLE IF EXISTS `$table`;\n";
    $sql .= $row2[1] . ";\n\n";

    // Table data
    $data = $conn->query("SELECT * FROM `$table`");
    while ($d = $data->fetch_assoc()) {
        $vals = array_map(function ($v) use ($conn) {
            return isset($v) ? "'" . $conn->real_escape_string($v) . "'" : "NULL";
        }, array_values($d));

        $sql .= "INSERT INTO `$table` VALUES (" . implode(",", $vals) . ");\n";
    }
    $sql .= "\n";
}

$fileName = "backup_" . date("Y-m-d_H-i-s") . ".sql";
$fullPath = $backupDir . $fileName;

if (file_put_contents($fullPath, $sql)) {
    echo "✅ Backup Successfully Created: <b>$fileName</b>";
} else {
    echo "❌ Backup Failed!";
}

echo "<br><br><a href='backup_panel.php'>⬅ Back to Panel</a>";
