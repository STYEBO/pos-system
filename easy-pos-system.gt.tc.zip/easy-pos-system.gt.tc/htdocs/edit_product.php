<?php
// edit_product.php - WITH UNIT SUPPORT
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
if ($user_role != 'admin') {
    header("Location: pos.php");
    exit;
}

require_once 'db.php';
include("header.php");
// Get product ID from URL
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch product details
$product = null;
if ($product_id > 0) {
    $stmt = $conn->prepare("SELECT *, COALESCE(unit, 'pcs') as unit FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    $stmt->close();
}

// If product not found, redirect back
if (!$product) {
    $_SESSION['error'] = "Product not found";
    header("Location: manage_products.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product - QEloERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --header-bg: #001f3f;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
           height:100vh
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            background: white;
            margin-bottom: 20px;
        }
        
        .card-header {
            background: #001f3f;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.25rem rgba(0,123,255,.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            border: none;
            color: white;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #0056b3 0%, #004085 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,123,255,0.3);
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d 0%, #545b62 100%);
            border: none;
            color: white;
        }
        
        .btn-secondary:hover {
            background: linear-gradient(135deg, #5a6268 0%, #484e53 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108,117,125,0.3);
        }
        
        .image-preview {
            width: 150px;
            height: 150px;
            border: 2px solid #ddd;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            margin-bottom: 15px;
        }
        
        .image-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
        
        .alert {
            border-radius: 8px;
            border: none;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .alert-success {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            color: white;
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
        }
    </style>
</head>
    <body>
        </br>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3><i class="fas fa-edit me-2"></i> Edit Product</h3>
            <a href="manage_products.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Back to Products
            </a>
        </div>

        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">
                    <i class="fas fa-box me-2"></i> Edit Product: <?php echo htmlspecialchars($product['name']); ?>
                </h4>
            </div>
            <div class="card-body p-4">
                <form action="update_product.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-tag me-2"></i>Product Name *
                                </label>
                                <input type="text" class="form-control" name="name" 
                                       value="<?php echo htmlspecialchars($product['name']); ?>" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-barcode me-2"></i>Barcode
                                </label>
                                <input type="text" class="form-control" name="barcode" 
                                       value="<?php echo htmlspecialchars($product['barcode'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-dollar-sign me-2"></i>Price *
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" name="price" step="0.01" 
                                           value="<?php echo $product['price']; ?>" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-boxes me-2"></i>Current Stock
                                </label>
                                <input type="number" class="form-control" name="quantity" 
                                       value="<?php echo $product['quantity']; ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-weight me-2"></i>Unit *
                                </label>
                                <select class="form-select" name="unit" required>
                                    <option value="pcs" <?php echo ($product['unit'] ?? 'pcs') == 'pcs' ? 'selected' : ''; ?>>Pieces (pcs)</option>
                                    <option value="kg" <?php echo ($product['unit'] ?? 'pcs') == 'kg' ? 'selected' : ''; ?>>Kilogram (kg)</option>
                                    <option value="g" <?php echo ($product['unit'] ?? 'pcs') == 'g' ? 'selected' : ''; ?>>Gram (g)</option>
                                    <option value="liter" <?php echo ($product['unit'] ?? 'pcs') == 'liter' ? 'selected' : ''; ?>>Liter (L)</option>
                                    <option value="ml" <?php echo ($product['unit'] ?? 'pcs') == 'ml' ? 'selected' : ''; ?>>Milliliter (ml)</option>
                                    <option value="pack" <?php echo ($product['unit'] ?? 'pcs') == 'pack' ? 'selected' : ''; ?>>Pack</option>
                                    <option value="box" <?php echo ($product['unit'] ?? 'pcs') == 'box' ? 'selected' : ''; ?>>Box</option>
                                    <option value="bottle" <?php echo ($product['unit'] ?? 'pcs') == 'bottle' ? 'selected' : ''; ?>>Bottle</option>
                                    <option value="dozen" <?php echo ($product['unit'] ?? 'pcs') == 'dozen' ? 'selected' : ''; ?>>Dozen</option>
                                    <option value="carton" <?php echo ($product['unit'] ?? 'pcs') == 'carton' ? 'selected' : ''; ?>>Carton</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-exclamation-triangle me-2"></i>Minimum Stock
                                </label>
                                <input type="number" class="form-control" name="min_stock" 
                                       value="<?php echo $product['min_stock']; ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-tags me-2"></i>Category *
                                </label>
                                <select class="form-select" name="category_id" required>
                                    <option value="">Select Category</option>
                                    <?php 
                                    // Fetch categories
                                    $cat_result = $conn->query("SELECT id, name FROM categories ORDER BY name");
                                    if ($cat_result->num_rows > 0) {
                                        while($cat = $cat_result->fetch_assoc()) {
                                            $selected = ($product['category_id'] == $cat['id']) ? 'selected' : '';
                                            echo "<option value=\"{$cat['id']}\" $selected>" . htmlspecialchars($cat['name']) . "</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">
                            <i class="fas fa-image me-2"></i>Product Image
                        </label>
                        <input type="file" class="form-control" name="image" accept="image/*">
                        <?php if (!empty($product['image'])): ?>
                            <div class="mt-3">
                                <div class="image-preview">
                                    <img src="<?php echo $product['image']; ?>" alt="Current Image">
                                </div>
                                <div class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" name="remove_image" value="1" id="removeImage">
                                    <label class="form-check-label" for="removeImage">
                                        Remove current image
                                    </label>
                                </div>
                                <small class="text-muted">Current image: <?php echo basename($product['image']); ?></small>
                            </div>
                        <?php endif; ?>
                        <div class="form-text">
                            Leave empty to keep current image. Allowed: JPG, PNG, GIF, WebP (Max: 5MB)
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <a href="manage_products.php" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Cancel
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Update Product
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Preview image when selected
        document.querySelector('input[name="image"]').addEventListener('change', function(e) {
            const preview = document.querySelector('.image-preview');
            if (preview) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                    }
                    reader.readAsDataURL(file);
                }
            }
        });
    </script>
</body>
</html>