<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

require_once 'db.php';

// Check user role
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Grocery Store - Easy Pos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Barcode Scanner Library -->
    <script src="https://unpkg.com/html5-qrcode"></script>
    <style>
        :root {
            --header-bg: #f8f9fa;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            height: 100vh;
        }
        
        .pos-container {
            display: flex;
            height: 100vh;
            background: white;
        }
        
        /* Left Sidebar - Categories */
        .categories-sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            border-right: 1px solid var(--border-color);
            overflow-y: auto;
            padding: 15px;
        }
        
        .section-title {
            color: #333;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 15px;
            padding: 8px 12px;
            background: #f0f0f0;
            border-radius: 4px;
        }
        
        .category-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .category-item {
            padding: 10px 12px;
            margin: 4px 0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        
        .category-item:hover {
            background: #e9ecef;
        }
        
        .category-item.active {
            background: #007bff;
            color: white;
        }
        
        .category-item .item-count {
            margin-left: auto;
            background: #6c757d;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        
        .category-item.active .item-count {
            background: white;
            color: #007bff;
        }
        
        /* Main Content Area */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        /* Top Header */
        .pos-header {
            padding: 15px 20px;
            background: #ffffff;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .store-title {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .search-box {
            flex: 1;
            max-width: 500px;
            margin: 0 20px;
            position: relative;
        }
        
        .search-box input {
            border-radius: 20px;
            padding-left: 40px;
            border: 1px solid #ccc;
            width: 100%;
        }
        
        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        
        .barcode-scan-btn {
            background: #28a745;
            color: white;
            border: none;
            border-radius: 20px;
            padding: 8px 15px;
            margin-right: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
        }
        
        .barcode-scan-btn:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .time-display {
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }
        
        /* Products Grid */
        .products-grid {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .product-card {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            display: flex;
            flex-direction: column;
            min-height: 200px;
            height: 40vh;
        }
        
        .product-card:hover {
            border-color: #007bff;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        
        .product-price {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        
        .product-stock {
            font-size: 12px;
            color: #28a745;
            background: #e8f5e9;
            padding: 2px 8px;
            border-radius: 10px;
            display: inline-block;
            margin-bottom: 8px;
        }
        
        .product-name {
            font-size: 14px;
            color: #333;
            margin-bottom: 5px;
            font-weight: 600;
            flex-grow: 1;
        }
        
        .product-desc {
            font-size: 12px;
            color: #666;
            line-height: 1.4;
            margin-bottom: 10px;
        }
        
        .product-image {
            width: 100%;
            height: 120px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        
        /* Cart Sidebar */
        .cart-sidebar {
            width: 450px;
            background: var(--sidebar-bg);
            border-left: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
        }
        
        .cart-items {
            flex: 1;
            overflow-y: auto;
        }
        
        .cart-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-color);
            background: #f8f9fa;
        }
        
        .cart-title {
            font-size: 18px;
            font-weight: 200;
            color: #333;
        }
        
        .cart-items {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        
        .cart-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .cart-table th {
            text-align: left;
            padding: 10px;
            border-bottom: 2px solid #dee2e6;
            font-size: 14px;
            color: #495057;
            font-weight: 600;
            background: #f8f9fa;
        }
        
        .cart-table td {
            padding: 12px 10px;
            border-bottom: 1px solid #dee2e6;
            vertical-align: middle;
        }
        
        .cart-table tr:hover {
            background: #f8f9fa;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .qty-input {
            width: 85px;
            text-align: center;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 6px 8px;
            font-size: 14px;
            transition: all 0.3s;
            cursor: pointer;
            background: #f8f9fa;
        }
        
        .qty-input:focus {
            outline: none;
            border-color: #adb5bd;
        }
        
        .edit-item {
            color: #007bff;
            cursor: pointer;
            font-size: 16px;
            margin-right: 10px;
            transition: all 0.3s;
        }
        
        .edit-item:hover {
            color: #0056b3;
            transform: scale(1.1);
        }
        
        .delete-item {
            color: #dc3545;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .delete-item:hover {
            color: #bd2130;
            transform: scale(1.1);
        }
        
        .cart-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Cart Footer */
        .cart-footer {
            padding: 20px;
            border-top: 1px solid var(--border-color);
            background: #f8f9fa;
        }
        
        .total-section {
            margin-bottom: 20px;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 16px;
        }
        
        .grand-total {
            font-size: 24px;
            font-weight: 700;
            color: #28a745;
            margin-top: 10px;
            padding-top: 10px;
            border-top: 2px solid #dee2e6;
        }
        
        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .action-btn {
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .fast-cash-btn {
            background: #17a2b8;
            color: white;
        }
        
        .fast-cash-btn:hover {
            background: #138496;
        }
        
        .checkout-btn {
            background: #28a745;
            color: white;
        }
        
        .checkout-btn:hover {
            background: #218838;
        }
        
        .clear-cart-btn {
            width: 100%;
            background: #dc3545;
            color: white;
            margin-top: 10px;
        }
        
        .clear-cart-btn:hover {
            background: #c82333;
        }
        
        .manage-btn {
            background: #6c757d;
            color: white;
        }
        
        .manage-btn:hover {
            background: #545b62;
        }
        
        /* Product Badges */
        .product-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #ffc107;
            color: #212529;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .low-stock {
            background: #dc3545;
            color: white;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        
        /* Windows Activation Bar */
        .windows-bar {
            background: #0078d4;
            color: white;
            padding: 5px 15px;
            font-size: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .windows-bar a {
            color: white;
            text-decoration: none;
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .pos-container {
                flex-direction: column;
            }
            
            .categories-sidebar {
                width: 100%;
                height: 200px;
                border-right: none;
                border-bottom: 1px solid var(--border-color);
            }
            
            .cart-sidebar {
                width: 100%;
                height: 400px;
                border-left: none;
                border-top: 1px solid var(--border-color);
            }
        }
        
        /* Loading Spinner */
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #007bff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Notification */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 9999;
            animation: slideIn 0.3s ease;
        }
        
        .notification.success {
            background: #28a745;
            color: white;
        }
        
        .notification.warning {
            background: #ffc107;
            color: #212529;
        }
        
        .notification.error {
            background: #dc3545;
            color: white;
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        /* Role Badge */
        .role-badge {
            background: <?php echo $user_role == 'admin' ? '#28a745' : '#007bff'; ?>;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
            margin-left: 8px;
        }
        
        .hide-scrollbar {
            scrollbar-width: none;
            -ms-overflow-style: none;
        }

        .hide-scrollbar::-webkit-scrollbar {
            display: none;
        }

        /* Additional CSS for unit display */
        .cart-table td small.text-muted {
            font-size: 11px;
            color: #6c757d;
        }

        .product-price {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }

        .product-stock {
            font-size: 12px;
            color: #28a745;
            background: #e8f5e9;
            padding: 2px 8px;
            border-radius: 10px;
            display: inline-block;
            margin-bottom: 8px;
        }

        .product-stock.low-stock {
            color: #dc3545;
            background: #f8d7da;
        }

        .product-stock.unlimited {
            color: #17a2b8;
            background: #e3f2fd;
        }

        /* Tooltip for icons */
        .cart-actions span[title] {
            position: relative;
        }

        .cart-actions span[title]:hover::after {
            content: attr(title);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background: #333;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            z-index: 1000;
            margin-bottom: 5px;
        }

        .cart-actions span[title]:hover::before {
            content: '';
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            border: 5px solid transparent;
            border-top-color: #333;
            margin-bottom: -5px;
        }

        .unit-info {
            font-size: 11px;
            color: #6c757d;
            margin-top: 2px;
        }

        .quantity-unit-container {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .price-per-unit {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }

        .no-dollar {
            color: #333;
            font-weight: 600;
        }

        /* Edit Modal Custom Styles */
        .edit-modal .modal-content {
            border-radius: 10px;
            border: none;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .edit-modal .modal-header {
            background: #007bff;
            color: white;
            border-radius: 10px 10px 0 0;
            padding: 15px 20px;
        }

        .edit-modal .modal-title {
            font-weight: 600;
            font-size: 18px;
        }

        .edit-modal .modal-body {
            padding: 25px;
        }

        .edit-modal .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
        }

        .edit-modal .form-control,
        .edit-modal .form-select {
            border: 1px solid #ced4da;
            border-radius: 6px;
            padding: 10px 12px;
            font-size: 14px;
        }

        .edit-modal .form-control:focus,
        .edit-modal .form-select:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }

        .edit-modal .modal-footer {
            border-top: 1px solid #dee2e6;
            padding: 15px 25px;
        }

        .edit-modal .btn {
            padding: 8px 20px;
            font-weight: 600;
            border-radius: 6px;
        }

        .stock-info {
            background: #e9ecef;
            padding: 10px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .stock-info strong {
            color: #495057;
        }

        .stock-info .text-success {
            color: #28a745;
            font-weight: 600;
        }

        .stock-info .text-danger {
            color: #dc3545;
            font-weight: 600;
        }

        .stock-info .text-info {
            color: #17a2b8;
            font-weight: 600;
        }

        /* Unlimited Stock Badge */
        .unlimited-badge {
            background: #17a2b8;
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 10px;
            font-weight: 600;
            margin-left: 5px;
        }
        
        /* Unit Type Indicator */
        .unit-type-indicator {
            position: absolute;
            top: 10px;
            left: 10px;
            font-size: 10px;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
        }
        
        .unit-type-weight {
            background: #17a2b8;
            color: white;
        }
        
        .unit-type-piece {
            background: #28a745;
            color: white;
        }
        
        .stock-limit {
            color: #dc3545;
            font-weight: bold;
        }
        
        .no-limit {
            color: #17a2b8;
            font-weight: bold;
        }
        
        /* Barcode Scanner Modal Styles */
        .scanner-modal .modal-dialog {
            max-width: 500px;
        }
        
        .scanner-modal .modal-content {
            border-radius: 15px;
            overflow: hidden;
        }
        
        .scanner-modal .modal-header {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }
        
        .scanner-modal #reader {
            width: 100%;
            height: 300px;
            margin: 0 auto;
            border: 2px solid #28a745;
            border-radius: 8px;
            overflow: hidden;
            position: relative;
        }
        
        .scanner-modal #reader video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .scanner-line {
            position: absolute;
            top: 50%;
            left: 10%;
            right: 10%;
            height: 3px;
            background: #28a745;
            box-shadow: 0 0 10px #28a745;
            animation: scanLine 2s infinite linear;
            z-index: 10;
        }
        
        @keyframes scanLine {
            0% { top: 10%; }
            50% { top: 90%; }
            100% { top: 10%; }
        }
        
        .scanner-instructions {
            text-align: center;
            margin: 15px 0;
            color: #666;
            font-size: 14px;
        }
        
        .scanner-instructions i {
            color: #28a745;
            margin-right: 5px;
        }
        
        .manual-barcode-input {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #dee2e6;
        }
        
        .manual-barcode-input .input-group {
            margin-bottom: 10px;
        }
        
        /* Search Results Dropdown */
        .search-results {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 0 0 8px 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            max-height: 300px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }
        
        .search-result-item {
            padding: 12px 15px;
            border-bottom: 1px solid #f1f1f1;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .search-result-item:hover {
            background: #f8f9fa;
        }
        
        .search-result-item:last-child {
            border-bottom: none;
        }
        
        .result-name {
            font-weight: 600;
            color: #333;
            margin-bottom: 3px;
        }
        
        .result-details {
            font-size: 12px;
            color: #666;
            display: flex;
            gap: 15px;
        }
        
        .result-price {
            color: #28a745;
            font-weight: 600;
        }
        
        .result-stock {
            color: #17a2b8;
        }
        
        .result-barcode {
            color: #6c757d;
        }
        
        /* Keyboard Shortcuts Help */
        .shortcut-help {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #333;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 12px;
            z-index: 999;
            display: none;
        }
        
        .shortcut-key {
            background: #555;
            padding: 2px 8px;
            border-radius: 4px;
            margin: 0 2px;
        }
        
        /* Barcode Scanner Active State */
        .scanner-active {
            color: #28a745;
            animation: pulse 1s infinite;
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="app-header">
        <?php include("header.php"); ?>
    </div>
    </br>
    <div class="pos-container">
        <!-- Left Categories Sidebar -->
        <div class="categories-sidebar">
            
            <ul class="category-list" id="categoryList">
                <div class="spinner" id="categoriesSpinner"></div>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <div class="pos-header">
                <div class="store-title">
                    <i class="fas fa-shopping-cart"></i>
                    Easy Pos System
                </div>
                
                <div class="search-box position-relative">
                    <i class="fas fa-search"></i>
                    <input type="text" class="form-control" id="searchProduct" 
                           placeholder="Search Product Here... (or enter barcode)">
                    <div class="search-results" id="searchResults"></div>
                </div>
                
                <div class="user-info">
                    <button class="barcode-scan-btn" id="startScannerBtn">
                        <i class="fas fa-barcode"></i>
                        Scan Barcode
                    </button>
                    <div class="time-display" id="currentTime"></div>
                </div>
            </div>
            
            <!-- Products Grid -->
            <div class="products-grid hide-scrollbar" id="productsGrid">
                <div class="spinner" id="productsSpinner"></div>
            </div>
        </div>
        
        <!-- Right Cart Sidebar -->
        <div class="cart-sidebar">
            <div class="cart-header">
                <h4 class="cart-title mb-0">Shopping Cart</h4>
            </div>
            
            <div class="cart-items hide-scrollbar">
                <table class="cart-table" id="cartTable">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Price/Unit</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="cartItems">
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <div class="empty-state">
                                    <i class="fas fa-shopping-cart"></i>
                                    <p>Your cart is empty</p>
                                    <small>Add products from the left</small>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="cart-footer">
                <div class="total-section">
                    <div class="total-row">
                        <span>Subtotal:</span>
                        <span id="subtotal">0.00</span>
                    </div>
                    <div class="total-row">
                        <span>Tax:</span>
                        <span id="taxAmount">0.00</span>
                    </div>
                    <div class="total-row grand-total">
                        <span>Total:</span>
                        <span id="totalAmount">0.00</span>
                    </div>
                </div>
                
                <div class="action-buttons">
                    <button class="action-btn fast-cash-btn" onclick="openFastCash()">
                        <i class="fas fa-bolt"></i> Fast Cash
                    </button>
                    <button class="action-btn checkout-btn" onclick="checkout()">
                        <i class="fas fa-credit-card"></i> Check Out
                    </button>
                </div>
                
                <button class="action-btn clear-cart-btn" onclick="clearCart()">
                    <i class="fas fa-trash"></i> Clear Cart
                </button>
            </div>
        </div>
    </div>
    
    <!-- Barcode Scanner Modal -->
    <div class="modal fade scanner-modal" id="barcodeScannerModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-barcode me-2"></i>
                        Scan Barcode
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" onclick="stopScanner()"></button>
                </div>
                <div class="modal-body">
                    <div class="scanner-instructions">
                        <p><i class="fas fa-info-circle"></i> Point camera at barcode to scan automatically</p>
                    </div>
                    
                    <div id="reader">
                        <div class="scanner-line"></div>
                    </div>
                    
                    <div class="manual-barcode-input">
                        <div class="scanner-instructions">
                            <p><i class="fas fa-keyboard"></i> Or enter barcode manually:</p>
                        </div>
                        <div class="input-group">
                            <input type="text" class="form-control" id="manualBarcodeInput" 
                                   placeholder="Enter barcode number...">
                            <button class="btn btn-success" type="button" onclick="processManualBarcode()">
                                <i class="fas fa-arrow-right"></i>
                            </button>
                        </div>
                        <div class="input-group mt-2">
                            <input type="text" class="form-control" id="productSearchInput" 
                                   placeholder="Or search product by name...">
                            <button class="btn btn-primary" type="button" onclick="searchProductByName()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="stopScanner()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-outline-primary" onclick="switchCamera()">
                        <i class="fas fa-sync-alt"></i> Switch Camera
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Fast Cash Modal -->
    <div class="modal fade" id="fastCashModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Fast Cash Payment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <h3>Total Amount</h3>
                        <h1 class="text-success" id="modalTotal">0.00</h1>
                    </div>
                    
                    <div class="row g-2 mb-4">
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(10)">10</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(20)">20</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(50)">50</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(100)">100</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(500)">500</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(1000)">1000</button>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Custom Amount</label>
                        <input type="number" class="form-control" id="customAmount" placeholder="Enter amount" step="0.01" oninput="applyCustomCash()">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Cash Received</label>
                        <input type="number" class="form-control" id="cashReceived" placeholder="0.00" step="0.01" value="0.00" oninput="calculateChange()">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Change Due</label>
                        <input type="text" class="form-control bg-light" id="changeDue" readonly value="0.00">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="processCashPayment()">Complete Payment</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Checkout Modal -->
    <div class="modal fade" id="checkoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Complete Checkout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <h3>Total Amount</h3>
                        <h1 class="text-success" id="checkoutTotal">0.00</h1>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Payment Method</label>
                        <select class="form-select" id="paymentMethod">
                            <option value="cash">Cash</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="debit_card">Debit Card</option>
                            <option value="mobile">Mobile Payment</option>
                            <option value="online">Online Payment</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Customer Name (Optional)</label>
                        <input type="text" class="form-control" id="customerName" placeholder="Enter customer name">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Customer Phone (Optional)</label>
                        <input type="text" class="form-control" id="customerPhone" placeholder="Enter customer phone">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Notes (Optional)</label>
                        <textarea class="form-control" id="customerNotes" rows="2" placeholder="Any special instructions..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="completeCheckout()">
                        <i class="fas fa-check me-1"></i> Complete Sale
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Item Modal -->
    <div class="modal fade edit-modal" id="editItemModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Item Quantity</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="stock-info" id="stockInfo">
                        <!-- Stock information will be inserted here -->
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Product Name</label>
                        <input type="text" class="form-control" id="editProductName" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Price per Unit</label>
                        <input type="text" class="form-control" id="editPricePerUnit" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Quantity (in <span id="editUnitDisplay"></span>)</label>
                        <input type="number" class="form-control" id="editQuantity" 
                               min="0.001" step="0.001" value="0">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Total Price</label>
                        <input type="text" class="form-control bg-light" id="editTotalPrice" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="saveEditedItem()">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Keyboard Shortcuts Help -->
    <div class="shortcut-help" id="shortcutHelp">
        <div><span class="shortcut-key">F1</span> - Scanner</div>
        <div><span class="shortcut-key">F2</span> - Search</div>
        <div><span class="shortcut-key">ESC</span> - Close Scanner</div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let cart = JSON.parse(localStorage.getItem('grocery_pos_cart')) || [];
        let selectedCategory = 'all';
        let categories = [];
        let products = [];
        let cashReceived = 0;
        let storeSettings = {};
        let currentEditingItemId = null;
        
        // Barcode Scanner Variables
        let html5QrCode = null;
        let currentFacingMode = "environment";
        let isScannerActive = false;
        let searchResults = [];

        // Function to check if unit is weight based (KG/G) - NO STOCK LIMIT
        function isWeightUnit(unit) {
            if (!unit) return false;
            const weightUnits = ['kg', 'g', 'gram', 'kilo', 'kilogram', 'ग्राम', 'किलो'];
            return weightUnits.includes(unit.toLowerCase());
        }

        // Function to check if unit is piece based (box/pieces) - HAS STOCK LIMIT
        function isPieceUnit(unit) {
            if (!unit) return false;
            const pieceUnits = ['pcs', 'piece', 'unit', 'pack', 'box', 'bottle', 'dozen', 'carton', 'bag', 'tin', 'can', 'jar'];
            return pieceUnits.includes(unit.toLowerCase());
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            loadCategories();
            loadProducts();
            updateCartDisplay();
            updateTime();
            loadStoreSettings();
            
            // Search functionality
            setupSearch();
            
            // Barcode scanner button
            document.getElementById('startScannerBtn').addEventListener('click', openBarcodeScanner);
            
            // Manual barcode input in scanner modal
            document.getElementById('manualBarcodeInput').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    processManualBarcode();
                }
            });
            
            // Product search in scanner modal
            document.getElementById('productSearchInput').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    searchProductByName();
                }
            });
            
            // Keyboard shortcuts
            setupKeyboardShortcuts();
            
            // Set interval to update time every minute
            setInterval(updateTime, 60000);

            // Add event listeners for edit modal
            document.getElementById('editQuantity').addEventListener('input', updateEditTotal);
        });
        
        function loadStoreSettings() {
            fetch('get_store_settings.php')
                .then(response => response.json())
                .then(data => {
                    storeSettings = data;
                    console.log('✅ Store settings loaded successfully:', storeSettings);
                })
                .catch(error => {
                    console.error('❌ Error loading store settings:', error);
                    storeSettings = {
                        store_name: 'Grocery Store POS',
                        store_address: '123 Main Street',
                        store_phone: '+1 (555) 123-4567',
                        store_email: 'info@store.com',
                        tax_rate: '8.5',
                        currency: 'USD',
                        receipt_footer: 'Thank you for shopping with us!',
                        auto_print: '1'
                    };
                });
        }

        function setupSearch() {
            const searchInput = document.getElementById('searchProduct');
            const searchResults = document.getElementById('searchResults');
            
            searchInput.addEventListener('input', debounce(function() {
                const searchTerm = this.value.trim();
                
                if (searchTerm.length < 2) {
                    searchResults.style.display = 'none';
                    return;
                }
                
                // Check if it's a barcode (numeric)
                if (/^\d+$/.test(searchTerm)) {
                    // It's likely a barcode, search by barcode
                    searchByBarcode(searchTerm);
                } else {
                    // Search by name
                    searchByName(searchTerm);
                }
            }, 300));
            
            // Close results when clicking outside
            document.addEventListener('click', function(e) {
                if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                    searchResults.style.display = 'none';
                }
            });
            
            // Enter key to add first result
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    const searchTerm = this.value.trim();
                    if (searchTerm) {
                        this.value = '';
                        searchResults.style.display = 'none';
                        
                        // Check if it's a barcode
                        if (/^\d+$/.test(searchTerm)) {
                            processBarcode(searchTerm);
                        } else {
                            // Search and add first result
                            if (searchResults.children.length > 0) {
                                const firstResult = searchResults.children[0];
                                const productId = firstResult.getAttribute('data-product-id');
                                if (productId) {
                                    addToCart(parseInt(productId));
                                }
                            }
                        }
                    }
                }
            });
        }
        
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
        
        function searchByBarcode(barcode) {
            const searchResults = document.getElementById('searchResults');
            
            // Find product by barcode
            const product = products.find(p => p.barcode && p.barcode.toString() === barcode);
            
            if (product) {
                searchResults.innerHTML = `
                    <div class="search-result-item" data-product-id="${product.id}" onclick="addToCart(${product.id}); this.parentElement.style.display='none';">
                        <div class="result-name">${product.name}</div>
                        <div class="result-details">
                            <span class="result-price">$${parseFloat(product.price).toFixed(2)}/${product.unit || 'pcs'}</span>
                            <span class="result-stock">Stock: ${parseFloat(product.quantity).toFixed(0)}</span>
                            <span class="result-barcode">Barcode: ${product.barcode}</span>
                        </div>
                    </div>
                `;
                searchResults.style.display = 'block';
            } else {
                searchResults.innerHTML = `
                    <div class="search-result-item">
                        <div class="result-name">Product not found</div>
                        <div class="result-details">
                            <span>Click here to scan barcode</span>
                        </div>
                    </div>
                `;
                searchResults.style.display = 'block';
            }
        }
        
        function searchByName(name) {
            const searchTerm = name.toLowerCase();
            const searchResults = document.getElementById('searchResults');
            
            const filteredProducts = products.filter(product => 
                product.name.toLowerCase().includes(searchTerm) ||
                (product.description && product.description.toLowerCase().includes(searchTerm))
            );
            
            if (filteredProducts.length > 0) {
                searchResults.innerHTML = filteredProducts.map(product => `
                    <div class="search-result-item" data-product-id="${product.id}" onclick="addToCart(${product.id}); this.parentElement.style.display='none';">
                        <div class="result-name">${product.name}</div>
                        <div class="result-details">
                            <span class="result-price">$${parseFloat(product.price).toFixed(2)}/${product.unit || 'pcs'}</span>
                            <span class="result-stock">Stock: ${parseFloat(product.quantity).toFixed(0)}</span>
                            ${product.barcode ? `<span class="result-barcode">Barcode: ${product.barcode}</span>` : ''}
                        </div>
                    </div>
                `).join('');
                searchResults.style.display = 'block';
            } else {
                searchResults.innerHTML = `
                    <div class="search-result-item">
                        <div class="result-name">No products found</div>
                        <div class="result-details">
                            <span>Try a different search term</span>
                        </div>
                    </div>
                `;
                searchResults.style.display = 'block';
            }
        }

        // Barcode Scanner Functions
        function openBarcodeScanner() {
            const scannerModal = new bootstrap.Modal(document.getElementById('barcodeScannerModal'));
            scannerModal.show();
            
            // Initialize scanner after modal is shown
            setTimeout(() => {
                initializeScanner();
            }, 500);
        }
        
        function initializeScanner() {
            if (html5QrCode) {
                stopScanner();
            }
            
            html5QrCode = new Html5Qrcode("reader");
            
            const qrCodeSuccessCallback = (decodedText, decodedResult) => {
                console.log(`Barcode scanned: ${decodedText}`);
                
                // Vibrate if supported
                if (navigator.vibrate) {
                    navigator.vibrate(200);
                }
                
                // Process barcode
                processBarcode(decodedText);
                
                // Stop scanner
                stopScanner();
                
                // Close modal after delay
                setTimeout(() => {
                    const scannerModal = bootstrap.Modal.getInstance(document.getElementById('barcodeScannerModal'));
                    if (scannerModal) {
                        scannerModal.hide();
                    }
                }, 1000);
            };
            
            const config = { 
                fps: 10, 
                qrbox: { width: 250, height: 250 },
                aspectRatio: 1.0
            };
            
            html5QrCode.start(
                { facingMode: currentFacingMode },
                config,
                qrCodeSuccessCallback,
                (errorMessage) => {
                    // Parse error, ignore it
                }
            ).catch(err => {
                console.error(`Unable to start scanning: ${err}`);
                showNotification('Unable to access camera. Please check permissions.', 'error');
            });
        }
        
        function stopScanner() {
            if (html5QrCode) {
                html5QrCode.stop().then(() => {
                    console.log("QR Code scanning stopped.");
                    html5QrCode = null;
                }).catch(err => {
                    console.error(`Unable to stop scanning: ${err}`);
                });
            }
        }
        
        function switchCamera() {
            currentFacingMode = currentFacingMode === "environment" ? "user" : "environment";
            stopScanner();
            setTimeout(() => {
                initializeScanner();
            }, 300);
        }
        
        function processManualBarcode() {
            const barcode = document.getElementById('manualBarcodeInput').value.trim();
            if (barcode) {
                processBarcode(barcode);
                document.getElementById('manualBarcodeInput').value = '';
            }
        }
        
        function searchProductByName() {
            const productName = document.getElementById('productSearchInput').value.trim();
            if (productName) {
                // Search in products array
                const matchedProducts = products.filter(product => 
                    product.name.toLowerCase().includes(productName.toLowerCase())
                );
                
                if (matchedProducts.length > 0) {
                    // Show selection
                    let options = matchedProducts.map(product => 
                        `<option value="${product.id}">${product.name} - $${parseFloat(product.price).toFixed(2)}</option>`
                    ).join('');
                    
                    Swal.fire({
                        title: 'Select Product',
                        html: `
                            <select class="form-control" id="productSelect">
                                ${options}
                            </select>
                        `,
                        showCancelButton: true,
                        confirmButtonText: 'Add to Cart',
                        cancelButtonText: 'Cancel'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            const productId = document.getElementById('productSelect').value;
                            addToCart(parseInt(productId));
                            
                            // Close scanner modal
                            const scannerModal = bootstrap.Modal.getInstance(document.getElementById('barcodeScannerModal'));
                            if (scannerModal) {
                                scannerModal.hide();
                            }
                        }
                    });
                } else {
                    showNotification('Product not found!', 'error');
                }
                document.getElementById('productSearchInput').value = '';
            }
        }
        
        function processBarcode(barcode) {
            console.log(`Processing barcode: ${barcode}`);
            
            // First try exact barcode match
            let product = products.find(p => p.barcode && p.barcode.toString() === barcode);
            
            // If not found, try ID match
            if (!product && !isNaN(barcode)) {
                product = products.find(p => p.id == barcode);
            }
            
            if (product) {
                addToCart(product.id);
                showNotification(`Added: ${product.name}`, 'success');
            } else {
                // Product not found
                Swal.fire({
                    title: 'Product Not Found',
                    html: `
                        <div class="text-start">
                            <p>Barcode: <strong>${barcode}</strong></p>
                            <p>This product is not in the database.</p>
                            <p>Would you like to add it?</p>
                        </div>
                    `,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Add New Product',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = `add_product.php?barcode=${barcode}`;
                    }
                });
            }
        }
        
        function setupKeyboardShortcuts() {
            document.addEventListener('keydown', function(e) {
                // F1 - Open barcode scanner
                if (e.key === 'F1') {
                    e.preventDefault();
                    openBarcodeScanner();
                }
                
                // F2 - Focus search
                if (e.key === 'F2') {
                    e.preventDefault();
                    document.getElementById('searchProduct').focus();
                    document.getElementById('searchProduct').select();
                }
                
                // Escape - Close scanner
                if (e.key === 'Escape') {
                    const scannerModal = bootstrap.Modal.getInstance(document.getElementById('barcodeScannerModal'));
                    if (scannerModal) {
                        stopScanner();
                        scannerModal.hide();
                    }
                }
                
                // Show help on Ctrl+?
                if (e.ctrlKey && e.key === '?') {
                    e.preventDefault();
                    document.getElementById('shortcutHelp').style.display = 'block';
                    setTimeout(() => {
                        document.getElementById('shortcutHelp').style.display = 'none';
                    }, 3000);
                }
                
                // Add product by number (1-9)
                if (e.key >= '1' && e.key <= '9' && !e.ctrlKey && !e.altKey) {
                    const index = parseInt(e.key) - 1;
                    const productCards = document.querySelectorAll('.product-card');
                    if (productCards[index]) {
                        productCards[index].click();
                    }
                }
            });
        }

        function loadCategories() {
            fetch('get_categories.php')
                .then(response => response.json())
                .then(data => {
                    categories = data;
                    const categoryList = document.getElementById('categoryList');
                    categoryList.innerHTML = '';
                    
                    // Add "All Items" first
                    const allItems = document.createElement('li');
                    allItems.className = `category-item ${selectedCategory === 'all' ? 'active' : ''}`;
                    allItems.innerHTML = `
                        All Items
                        <span class="item-count" id="allItemsCount">0</span>
                    `;
                    allItems.onclick = () => selectCategory('all');
                    categoryList.appendChild(allItems);
                    
                    // Add database categories
                    data.forEach(category => {
                        const item = document.createElement('li');
                        item.className = `category-item ${selectedCategory === category.id.toString() ? 'active' : ''}`;
                        item.innerHTML = `
                            ${category.name}
                            <span class="item-count" id="count-${category.id}">0</span>
                        `;
                        item.onclick = () => selectCategory(category.id);
                        categoryList.appendChild(item);
                    });
                    
                    // Update counts after loading products
                    updateCategoryCounts();
                })
                .catch(error => {
                    console.error('Error loading categories:', error);
                    showNotification('Failed to load categories', 'error');
                });
        }

        function loadProducts() {
            fetch('get_products.php')
                .then(response => response.json())
                .then(data => {
                    products = data;
                    console.log('Products loaded with units:', data.map(p => ({name: p.name, unit: p.unit, price: p.price})));
                    displayProducts();
                    updateCategoryCounts();
                    document.getElementById('productsSpinner').style.display = 'none';
                })
                .catch(error => {
                    console.error('Error loading products:', error);
                    document.getElementById('productsSpinner').style.display = 'none';
                });
        }

        function displayProducts() {
            const productsGrid = document.getElementById('productsGrid');
            productsGrid.innerHTML = '';
            
            let filteredProducts = selectedCategory === 'all' 
                ? products 
                : products.filter(p => p.category_id == selectedCategory);
            
            if (filteredProducts.length === 0) {
                productsGrid.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-box-open"></i>
                        <p>No products found in this category</p>
                    </div>
                `;
                return;
            }
            
            filteredProducts.forEach((product, index) => {
                const card = document.createElement('div');
                card.className = 'product-card';
                card.onclick = () => addToCart(product.id);
                
                // Get unit from product or default to 'pcs'
                const unit = product.unit || 'pcs';
                
                // Check unit type
                const isWeightItem = isWeightUnit(unit);
                const isPieceItem = isPieceUnit(unit);
                
                // Determine stock display based on unit type
                let stockDisplay = '';
                let badgeClass = '';
                let badgeText = '';
                let unitTypeBadge = '';
                let unitTypeClass = '';
                
                if (isWeightItem) {
                    // Weight items (KG/G) - NO STOCK LIMIT
                    stockDisplay = `<div class="product-stock unlimited">Unlimited Stock <span class="unlimited-badge">${unit}</span></div>`;
                    badgeText = 'Unlimited';
                    unitTypeBadge = `<span class="unit-type-indicator unit-type-weight">Weight</span>`;
                    unitTypeClass = 'weight-item';
                } else if (isPieceItem) {
                    // Piece items - HAS STOCK LIMIT
                    const isLowStock = product.quantity <= product.min_stock;
                    stockDisplay = `
                        <div class="product-stock ${isLowStock ? 'low-stock' : ''}">
                            ${parseFloat(product.quantity).toFixed(0)} ${unit} in stock
                            ${isLowStock ? ' (Low Stock)' : ''}
                        </div>
                    `;
                    badgeClass = isLowStock ? 'low-stock' : '';
                    badgeText = `${parseFloat(product.quantity).toFixed(0)} ${unit}`;
                    unitTypeBadge = `<span class="unit-type-indicator unit-type-piece">Piece</span>`;
                    unitTypeClass = 'piece-item';
                } else {
                    // Default for other units
                    const isLowStock = product.quantity <= product.min_stock;
                    stockDisplay = `
                        <div class="product-stock ${isLowStock ? 'low-stock' : ''}">
                            ${parseFloat(product.quantity).toFixed(0)} ${unit} in stock
                            ${isLowStock ? ' (Low Stock)' : ''}
                        </div>
                    `;
                    badgeClass = isLowStock ? 'low-stock' : '';
                    badgeText = `${parseFloat(product.quantity).toFixed(0)} ${unit}`;
                }
                
                // Add keyboard shortcut number (1-9)
                let shortcutBadge = '';
                if (index < 9) {
                    shortcutBadge = `<span class="badge bg-secondary position-absolute" style="top: 5px; left: 5px;">${index + 1}</span>`;
                }
                
                card.innerHTML = `
                    ${shortcutBadge}
                    ${unitTypeBadge}
                    ${product.image ? `<img src="${product.image}" class="product-image" alt="${product.name}">` : 
                      `<div class="product-image bg-light d-flex align-items-center justify-content-center">
                         <i class="fas fa-box fa-2x text-muted"></i>
                       </div>`}
                    <div class="product-price">${parseFloat(product.price).toFixed(2)}/${unit}</div>
                    ${stockDisplay}
                    <div class="product-name">${product.name}</div>
                    ${product.barcode ? `<div class="product-desc">Barcode: ${product.barcode}</div>` : ''}
                    <div class="product-badge ${badgeClass} ${unitTypeClass}">
                        ${badgeText}
                    </div>
                `;
                productsGrid.appendChild(card);
            });
        }

        function updateCategoryCounts() {
            document.getElementById('allItemsCount').textContent = products.length;
            
            categories.forEach(category => {
                const count = products.filter(p => p.category_id == category.id).length;
                const countElement = document.getElementById(`count-${category.id}`);
                if (countElement) {
                    countElement.textContent = count;
                }
            });
        }

        function selectCategory(categoryId) {
            selectedCategory = categoryId;
            
            document.querySelectorAll('.category-item').forEach(item => {
                item.classList.remove('active');
            });
            
            document.querySelectorAll('.category-item').forEach(item => {
                if (categoryId === 'all' && item.textContent.includes('All Items')) {
                    item.classList.add('active');
                } else if (item.textContent.includes(categories.find(c => c.id == categoryId)?.name || '')) {
                    item.classList.add('active');
                }
            });
            
            displayProducts();
        }

        function addToCart(productId) {
            const product = products.find(p => p.id == productId);
            if (!product) return;
            
            // Get unit from product or default to 'pcs'
            const unit = product.unit || 'pcs';
            
            // Check unit type
            const isWeightItem = isWeightUnit(unit);
            const isPieceItem = isPieceUnit(unit);
            
            // For PIECE items - CHECK STOCK LIMIT
            if (isPieceItem && product.quantity <= 0) {
                showNotification('Product is out of stock!', 'error');
                return;
            }
            
            // For WEIGHT items - NO STOCK CHECK
            // For other items - check stock normally
            
            const existingItem = cart.find(item => item.id == productId);
            
            // Get default quantity based on unit
            const defaultQuantity = getDefaultQuantity(unit);
            
            if (existingItem) {
                // For piece items, check stock limit
                if (isPieceItem) {
                    const productInDB = products.find(p => p.id == productId);
                    if (existingItem.quantity + defaultQuantity > productInDB.quantity) {
                        showNotification(`Only ${productInDB.quantity} ${unit} available in stock!`, 'error');
                        return;
                    }
                }
                existingItem.quantity += defaultQuantity;
            } else {
                cart.push({
                    id: product.id,
                    name: product.name,
                    price: parseFloat(product.price),
                    quantity: defaultQuantity,
                    unit: unit,
                    stock: parseInt(product.quantity),
                    min_stock: product.min_stock || 0,
                    isWeightItem: isWeightItem,
                    isPieceItem: isPieceItem,
                    hasUnlimitedStock: isWeightItem // Weight items have unlimited stock
                });
            }
            
            updateCart();
            showNotification(`${product.name} (${formatQuantity(defaultQuantity, unit)}) added to cart`, 'success');
        }

        // Function to get default quantity based on unit type
        function getDefaultQuantity(unit) {
            const u = unit || 'pcs';
            switch(u.toLowerCase()) {
                case 'kg':
                case 'kilo':
                case 'kilogram':
                    return 0.100; // 100 grams default
                case 'g':
                case 'gram':
                    return 100; // 100 grams default
                case 'pcs':
                case 'piece':
                case 'unit':
                    return 1;
                case 'pack':
                case 'box':
                case 'bottle':
                case 'dozen':
                case 'carton':
                case 'bag':
                case 'tin':
                case 'can':
                case 'jar':
                    return 1;
                default:
                    return 1;
            }
        }

        // Function to format quantity display
        function formatQuantity(quantity, unit) {
            const u = unit || 'pcs';
            if (u === 'kg' || u === 'kilo' || u === 'kilogram') {
                return parseFloat(quantity).toFixed(3) + ' ' + u;
            } else if (u === 'g' || u === 'gram') {
                return parseInt(quantity) + ' ' + u;
            } else if (u === 'pcs' || u === 'piece' || u === 'unit' || 
                u === 'pack' || u === 'box' || u === 'bottle' || 
                u === 'dozen' || u === 'carton' || u === 'bag' || 
                u === 'tin' || u === 'can' || u === 'jar') {
                return parseInt(quantity) + ' ' + u;
            }
            return quantity + ' ' + u;
        }

        function updateCart() {
            localStorage.setItem('grocery_pos_cart', JSON.stringify(cart));
            updateCartDisplay();
        }

        function updateCartDisplay() {
            const cartItems = document.getElementById('cartItems');
            
            if (cart.length === 0) {
                cartItems.innerHTML = `
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="empty-state">
                                <i class="fas fa-shopping-cart"></i>
                                <p>Your cart is empty</p>
                                <small>Add products from the left</small>
                            </div>
                        </td>
                    </tr>
                `;
                updateTotals();
                return;
            }
            
            let html = '';
            cart.forEach((item, index) => {
                const total = item.price * item.quantity;
                const quantityDisplay = formatQuantity(item.quantity, item.unit);
                const unit = item.unit || 'pcs';
                
                // Stock information
                let stockInfo = '';
                if (item.isWeightItem) {
                    stockInfo = '<span class="no-limit">No Stock Limit</span>';
                } else if (item.isPieceItem) {
                    stockInfo = `Stock: ${parseFloat(item.stock).toFixed(0)} ${unit}`;
                } else {
                    stockInfo = `Stock: ${parseFloat(item.stock).toFixed(0)} ${unit}`;
                }
                
                html += `
                    <tr>
                        <td>
                            <strong>${item.name}</strong><br>
                            <small class="text-muted">
                                ${stockInfo}
                                ${item.isWeightItem ? ' <span class="unlimited-badge">Weight Item</span>' : ''}
                                ${item.isPieceItem ? ' <span class="unlimited-badge">Piece Item</span>' : ''}
                            </small>
                        </td>
                        <td>
                            <div class="price-per-unit">
                                <span class="no-dollar">${item.price.toFixed(2)}</span>/${unit}
                            </div>
                        </td>
                        <td>
                            <div class="quantity-unit-container">
                                <input type="text" 
                                       class="qty-input" 
                                       value="${quantityDisplay}"
                                       readonly>
                            </div>
                        </td>
                        <td>${total.toFixed(2)}</td>
                        <td>
                            <div class="cart-actions">
                                <span class="edit-item" title="Edit Quantity" onclick="openEditModal(${item.id})">
                                    <i class="fas fa-edit"></i>
                                </span>
                                <span class="delete-item" title="Remove Item" onclick="removeFromCart(${item.id})">
                                    <i class="fas fa-trash"></i>
                                </span>
                            </div>
                        </td>
                    </tr>
                `;
            });
            
            cartItems.innerHTML = html;
            updateTotals();
        }

        function openEditModal(productId) {
            const item = cart.find(item => item.id == productId);
            if (!item) return;
            
            currentEditingItemId = productId;
            
            // Get original product info
            const product = products.find(p => p.id == productId);
            const unit = item.unit || 'pcs';
            const isWeightItem = item.isWeightItem;
            const isPieceItem = item.isPieceItem;
            
            // Populate modal fields
            document.getElementById('editProductName').value = item.name;
            document.getElementById('editPricePerUnit').value = `${item.price.toFixed(2)}/${unit}`;
            document.getElementById('editQuantity').value = parseFloat(item.quantity).toFixed(3);
            document.getElementById('editUnitDisplay').textContent = unit;
            
            // Set min and step based on unit
            const quantityInput = document.getElementById('editQuantity');
            
            if (isWeightItem && (unit === 'kg' || unit === 'kilo' || unit === 'kilogram')) {
                quantityInput.min = "0.001";
                quantityInput.step = "0.001";
            } else if (isWeightItem && (unit === 'g' || unit === 'gram')) {
                quantityInput.min = "1";
                quantityInput.step = "1";
            } else {
                quantityInput.min = "1";
                quantityInput.step = "1";
            }
            
            // Update stock info
            const stockInfo = document.getElementById('stockInfo');
            
            if (isWeightItem) {
                // Weight items - NO STOCK LIMIT
                stockInfo.innerHTML = `
                    <strong>Stock Information:</strong><br>
                    <span class="text-info">✨ Unlimited Stock (Weight-based Item)</span><br>
                    <small>No stock limitations for ${unit} items. Add any quantity.</small>
                `;
                
                // Remove max limit for weight items
                quantityInput.removeAttribute('max');
            } else if (isPieceItem && product) {
                // Piece items - HAS STOCK LIMIT
                const productUnit = product.unit || 'pcs';
                
                stockInfo.innerHTML = `
                    <strong>Stock Information:</strong><br>
                    Available Stock: <span class="${product.quantity <= product.min_stock ? 'text-danger stock-limit' : 'text-success'}">
                        ${parseFloat(product.quantity).toFixed(0)} ${productUnit}
                    </span>
                    ${product.min_stock > 0 ? ` | Min Stock: ${product.min_stock} ${productUnit}` : ''}<br>
                    <small class="stock-limit">Stock limit applies for piece items</small>
                `;
                
                // Set max quantity based on available stock
                quantityInput.max = product.quantity;
            } else if (product) {
                // Other items - default stock check
                const productUnit = product.unit || 'pcs';
                
                stockInfo.innerHTML = `
                    <strong>Stock Information:</strong><br>
                    Available Stock: <span class="${product.quantity <= product.min_stock ? 'text-danger stock-limit' : 'text-success'}">
                        ${parseFloat(product.quantity).toFixed(0)} ${productUnit}
                    </span>
                    ${product.min_stock > 0 ? ` | Min Stock: ${product.min_stock} ${productUnit}` : ''}
                `;
                
                // Set max quantity based on available stock
                quantityInput.max = product.quantity;
            } else {
                stockInfo.innerHTML = `<strong>Stock Information:</strong> Not available`;
            }
            
            // Calculate and display total price
            updateEditTotal();
            
            // Show modal
            const editModal = new bootstrap.Modal(document.getElementById('editItemModal'));
            editModal.show();
            
            // Focus on quantity field
            setTimeout(() => {
                quantityInput.focus();
                quantityInput.select();
            }, 500);
        }

        function updateEditTotal() {
            const quantity = parseFloat(document.getElementById('editQuantity').value) || 0;
            const item = cart.find(item => item.id == currentEditingItemId);
            
            if (item) {
                const total = item.price * quantity;
                document.getElementById('editTotalPrice').value = total.toFixed(2);
            }
        }

        function saveEditedItem() {
            if (!currentEditingItemId) return;
            
            const item = cart.find(item => item.id == currentEditingItemId);
            if (!item) return;
            
            const newQuantity = parseFloat(document.getElementById('editQuantity').value);
            const unit = item.unit || 'pcs';
            const isWeightItem = item.isWeightItem;
            const isPieceItem = item.isPieceItem;
            
            // Validate quantity
            if (isNaN(newQuantity) || newQuantity <= 0) {
                showNotification('Please enter a valid quantity greater than 0', 'error');
                document.getElementById('editQuantity').focus();
                return;
            }
            
            // For weight items (kg), ensure proper decimal places
            if (isWeightItem && (unit === 'kg' || unit === 'kilo' || unit === 'kilogram')) {
                if (newQuantity < 0.001) {
                    showNotification('Minimum quantity for weight items is 0.001', 'error');
                    return;
                }
                // Save with 3 decimal places
                item.quantity = parseFloat(newQuantity.toFixed(3));
            } else if (isWeightItem && (unit === 'g' || unit === 'gram')) {
                // Save as whole number for grams
                item.quantity = parseInt(newQuantity);
            } else {
                // For piece items, save as whole number
                item.quantity = parseInt(newQuantity);
            }
            
            // Only check stock for PIECE items (not weight items)
            if (isPieceItem) {
                const product = products.find(p => p.id == currentEditingItemId);
                if (product && newQuantity > product.quantity) {
                    const productUnit = product.unit || 'pcs';
                    Swal.fire({
                        title: 'Stock Limit Exceeded',
                        html: `
                            <div class="text-start">
                                <p><strong>Available Stock:</strong> ${parseFloat(product.quantity).toFixed(0)} ${productUnit}</p>
                                <p><strong>Requested Quantity:</strong> ${formatQuantity(newQuantity, unit)}</p>
                                <p class="text-danger stock-limit">Stock limit applies for piece items!</p>
                                <p>You cannot exceed available stock for box/piece items.</p>
                            </div>
                        `,
                        icon: 'error',
                        showCancelButton: false,
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#dc3545'
                    });
                    return;
                }
            }
            
            // Apply changes
            updateCart();
            
            // Close modal
            const editModal = bootstrap.Modal.getInstance(document.getElementById('editItemModal'));
            if (editModal) {
                editModal.hide();
            }
            
            showNotification(`Updated ${item.name} to ${formatQuantity(newQuantity, unit)}`, 'success');
            currentEditingItemId = null;
        }

        function removeFromCart(productId) {
            Swal.fire({
                title: 'Remove Item',
                text: 'Are you sure you want to remove this item from cart?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, remove it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    cart = cart.filter(item => item.id != productId);
                    updateCart();
                    showNotification('Item removed from cart', 'warning');
                }
            });
        }

        function clearCart() {
            if (cart.length === 0) return;
            
            Swal.fire({
                title: 'Clear Cart',
                text: 'Are you sure you want to clear the entire cart?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, clear cart!'
            }).then((result) => {
                if (result.isConfirmed) {
                    cart = [];
                    updateCart();
                    showNotification('Cart cleared', 'info');
                }
            });
        }

        function updateTotals() {
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            
            const taxRate = parseFloat(storeSettings.tax_rate || 0.0) / 100;
            const taxAmount = subtotal * taxRate;
            const total = subtotal + taxAmount;
            
            document.getElementById('subtotal').textContent = subtotal.toFixed(2);
            document.getElementById('taxAmount').textContent = taxAmount.toFixed(2);
            document.getElementById('totalAmount').textContent = total.toFixed(2);
        }

        function openFastCash() {
            if (cart.length === 0) {
                showNotification('Cart is empty! Add some products first.', 'error');
                return;
            }
            
            updateTotals();
            const total = parseFloat(document.getElementById('totalAmount').textContent);
            document.getElementById('modalTotal').textContent = total.toFixed(2);
            
            document.getElementById('cashReceived').value = '0.00';
            document.getElementById('changeDue').value = '0.00';
            document.getElementById('customAmount').value = '';
            cashReceived = 0;
            
            const modal = new bootstrap.Modal(document.getElementById('fastCashModal'));
            modal.show();
        }

        function applyCash(amount) {
            cashReceived += amount;
            document.getElementById('cashReceived').value = cashReceived.toFixed(2);
            calculateChange();
        }

        function applyCustomCash() {
            const customAmount = parseFloat(document.getElementById('customAmount').value) || 0;
            if (customAmount > 0) {
                cashReceived = customAmount;
                document.getElementById('cashReceived').value = cashReceived.toFixed(2);
                calculateChange();
            }
        }

        function calculateChange() {
            const total = parseFloat(document.getElementById('modalTotal').textContent);
            cashReceived = parseFloat(document.getElementById('cashReceived').value) || 0;
            const change = cashReceived - total;
            
            if (change >= 0) {
                document.getElementById('changeDue').value = change.toFixed(2);
                document.getElementById('changeDue').classList.remove('text-danger');
                document.getElementById('changeDue').classList.add('text-success');
            } else {
                document.getElementById('changeDue').value = `-${Math.abs(change).toFixed(2)}`;
                document.getElementById('changeDue').classList.remove('text-success');
                document.getElementById('changeDue').classList.add('text-danger');
            }
        }

        function processCashPayment() {
            const total = parseFloat(document.getElementById('modalTotal').textContent);
            cashReceived = parseFloat(document.getElementById('cashReceived').value) || 0;
            
            if (cashReceived < total) {
                showNotification('Insufficient cash received!', 'error');
                return;
            }
            
            const change = cashReceived - total;
            
            Swal.fire({
                title: 'Confirm Cash Payment',
                html: `
                    <div class="text-start">
                        <p><strong>Total:</strong> ${total.toFixed(2)}</p>
                        <p><strong>Cash Received:</strong> ${cashReceived.toFixed(2)}</p>
                        <p><strong>Change Due:</strong> ${change.toFixed(2)}</p>
                    </div>
                `,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Complete Payment',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    completeSale('cash', change);
                }
            });
        }

        function checkout() {
            if (cart.length === 0) {
                showNotification('Cart is empty! Add some products first.', 'error');
                return;
            }
            
            updateTotals();
            const total = parseFloat(document.getElementById('totalAmount').textContent);
            document.getElementById('checkoutTotal').textContent = total.toFixed(2);
            
            const modal = new bootstrap.Modal(document.getElementById('checkoutModal'));
            modal.show();
        }

        function completeCheckout() {
            const paymentMethod = document.getElementById('paymentMethod').value;
            const customerName = document.getElementById('customerName').value;
            const customerPhone = document.getElementById('customerPhone').value;
            const customerNotes = document.getElementById('customerNotes').value;
            
            Swal.fire({
                title: 'Confirm Checkout',
                html: `
                    <div class="text-start">
                        <p><strong>Payment Method:</strong> ${paymentMethod.replace('_', ' ').toUpperCase()}</p>
                        ${customerName ? `<p><strong>Customer:</strong> ${customerName}</p>` : ''}
                        ${customerPhone ? `<p><strong>Phone:</strong> ${customerPhone}</p>` : ''}
                    </div>
                `,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Complete Sale',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    completeSale(paymentMethod, 0, customerName, customerPhone, customerNotes);
                }
            });
        }

        function completeSale(paymentMethod, change = 0, customerName = '', customerPhone = '', notes = '') {
            const saleData = {
                items: cart,
                subtotal: parseFloat(document.getElementById('subtotal').textContent),
                tax: parseFloat(document.getElementById('taxAmount').textContent),
                total: parseFloat(document.getElementById('totalAmount').textContent),
                payment_method: paymentMethod,
                change: change,
                customer_name: customerName,
                customer_phone: customerPhone,
                notes: notes,
                cashier: '<?php echo $_SESSION["username"]; ?>',
                timestamp: new Date().toISOString()
            };
            
            fetch('save_sale.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(saleData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update product quantities in database (only for PIECE items, not weight items)
                    updateProductQuantitiesAfterSale();
                    
                    printReceipt(saleData, data.sale_id);
                    
                    cart = [];
                    currentEditingItemId = null;
                    updateCart();
                    
                    const fastCashModal = bootstrap.Modal.getInstance(document.getElementById('fastCashModal'));
                    const checkoutModal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
                    const editModal = bootstrap.Modal.getInstance(document.getElementById('editItemModal'));
                    
                    if (fastCashModal) fastCashModal.hide();
                    if (checkoutModal) checkoutModal.hide();
                    if (editModal) editModal.hide();
                    
                    Swal.fire({
                        title: 'Sale Completed!',
                        text: 'Transaction completed successfully',
                        icon: 'success',
                        timer: 2000
                    }).then(() => {
                        loadProducts(); // Reload products to get updated stock for piece items
                    });
                } else {
                    showNotification('Error: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Network error. Please check your connection.', 'error');
            });
        }

        function updateProductQuantitiesAfterSale() {
            // Filter only PIECE items to update in database (NOT weight items)
            const pieceItemsToUpdate = cart.filter(item => 
                item.isPieceItem && !item.isWeightItem
            );
            
            if (pieceItemsToUpdate.length === 0) return;
            
            // Create an array of product updates
            const updates = pieceItemsToUpdate.map(item => ({
                product_id: item.id,
                quantity_sold: item.quantity
            }));
            
            // Send update to server
            fetch('update_product_quantities.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ updates: updates })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Piece items quantities updated successfully');
                    console.log('Weight items NOT updated (unlimited stock)');
                } else {
                    console.error('Failed to update product quantities:', data.message);
                }
            })
            .catch(error => {
                console.error('Error updating product quantities:', error);
            });
        }

        function printReceipt(saleData, receiptNumber, settings = {}) {
            const storeSettingsToUse = Object.keys(settings).length > 0 ? settings : storeSettings;
            
            const storeName = storeSettingsToUse.store_name || 'Grocery Store POS';
            const storeAddress = storeSettingsToUse.store_address || '';
            const storePhone = storeSettingsToUse.store_phone || '';
            const receiptFooter = storeSettingsToUse.receipt_footer || 'Thank you for shopping with us!';
            const taxRate = parseFloat(storeSettingsToUse.tax_rate || 0.0);
            
            const receiptWindow = window.open('', '_blank', 'width=600,height=700');
            
            receiptWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Receipt</title>
                    <style>
                        @media print {
                            @page { margin: 0; }
                            body { margin: 0.5cm; }
                        }
                        body { 
                            font-family: 'Courier New', monospace; 
                            max-width: 80mm; 
                            margin: 0 auto; 
                            padding: 10px;
                            font-size: 13px;
                            color: #000;
                        }
                        .header { text-align: center; margin-bottom: 15px; }
                        .header h2 { margin: 0; font-size: 18px; font-weight: bold; }
                        .store-info { font-size: 12px; margin: 2px 0; }
                        .details { margin: 15px 0; font-size: 12px; }
                        .details div { margin-bottom: 2px; }
                        table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 10px; }
                        th, td { padding: 5px; text-align: left; }
                        th { border-bottom: 2px solid #000; }
                        td { border-bottom: 1px dashed #000; }
                        .text-right { text-align: right; }
                        .total, .subtotal, .tax { font-weight: bold; font-size: 14px; }
                        .totals { margin-top: 10px; }
                        .footer { text-align: center; margin-top: 20px; font-size: 11px; border-top: 1px dashed #000; padding-top: 5px; }
                        .line { border-bottom: 1px dashed #000; margin: 5px 0; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h2>${storeName}</h2>
                        ${storeAddress ? `<div class="store-info">${storeAddress}</div>` : ''}
                        ${storePhone ? `<div class="store-info">📞 ${storePhone}</div>` : ''}
                    </div>
                    
                    <div class="details">
                        <div><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>
                        <div><strong>Time:</strong> ${new Date().toLocaleTimeString()}</div>
                        <div><strong>Cashier:</strong> ${saleData.cashier}</div>
                        <div><strong>Receipt #:</strong> ${receiptNumber}</div>
                    </div>
                    
                    <table>
                        <tr>
                            <th>Item</th>
                            <th>Qty</th>
                            <th>Unit</th>
                            <th class="text-right">Price/Unit</th>
                            <th class="text-right">Total</th>
                        </tr>
                        ${saleData.items.map(item => `
                            <tr>
                                <td>${item.name}</td>
                                <td>${formatQuantity(item.quantity, item.unit || 'pcs')}</td>
                                <td>${item.unit || 'pcs'}</td>
                                <td class="text-right">${item.price.toFixed(2)}</td>
                                <td class="text-right">${(item.price * item.quantity).toFixed(2)}</td>
                            </tr>
                        `).join('')}
                    </table>

                    <div class="totals">
                        <div class="subtotal">Subtotal: ${saleData.subtotal.toFixed(2)}</div>
                        <div class="tax">Tax (${taxRate}%): ${saleData.tax.toFixed(2)}</div>
                        <div class="total">TOTAL: ${saleData.total.toFixed(2)}</div>
                        <div>Payment: ${saleData.payment_method.toUpperCase()}</div>
                        ${saleData.change > 0 ? `<div>Change: ${saleData.change.toFixed(2)}</div>` : ''}
                    </div>
                    
                    <div class="footer">
                        ${receiptFooter}
                    </div>
                </body>
                </html>
            `);
            
            receiptWindow.document.close();
        }

        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            const dateString = now.toLocaleDateString([], {weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'});
            document.getElementById('currentTime').textContent = `${dateString} ${timeString}`;
        }

        function logout() {
            Swal.fire({
                title: 'Logout',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, logout!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        }

        function activateWindows() {
            Swal.fire({
                title: 'Activate Windows',
                text: 'This feature is for demonstration purposes only.',
                icon: 'info',
                confirmButtonText: 'OK'
            });
        }

        function showNotification(message, type = 'info') {
            document.querySelectorAll('.notification').forEach(n => n.remove());
            
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : type === 'error' ? 'times-circle' : 'info-circle'} me-2"></i>
                ${message}
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }, 3000);
        }
    </script>
</body>
</html>