<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

require_once 'db.php';

// Check user role
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>POS System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        :root {
            --primary-color: #4a6baf;
            --secondary-color: #ff9800;
            --success-color: #4caf50;
            --danger-color: #f44336;
            --warning-color: #ffc107;
            --light-color: #f5f5f5;
            --dark-color: #333333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: #f0f2f5;
            height: 100vh;
            overflow: hidden;
        }

        /* Main Container */
        .pos-container {
            display: flex;
            height: calc(100vh - 70px);
            background: white;
            margin: 0;
            overflow: hidden;
        }

        /* Categories Section */
        .categories-section {
            width: 200px;
            background: #2c3e50;
            color: white;
            padding: 15px 0;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,0.3) rgba(0,0,0,0.1);
        }

        .categories-section::-webkit-scrollbar {
            width: 6px;
        }

        .categories-section::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.1);
            border-radius: 3px;
        }

        .categories-section::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .categories-section::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .category-tab {
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            font-weight: 500;
            white-space: nowrap;
            min-width: 100%;
        }

        .category-tab:hover {
            background: rgba(255,255,255,0.1);
        }

        .category-tab.active {
            background: var(--secondary-color);
            color: white;
        }

        /* Main Content Area */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* Top Header */
        .pos-header {
            padding: 15px;
            background: white;
            border-bottom: 1px solid #ddd;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .search-scan-bar {
            flex: 1;
            position: relative;
        }

        .search-scan-bar input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid var(--success-color);
            border-radius: 5px;
            font-size: 16px;
            background: #f8fff9;
        }

        .search-scan-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--success-color);
        }

        /* Compact Product Card Styles */
        .product-card {
            background: white;
            border-radius: 8px;
            padding: 10px;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            display: flex;
            flex-direction: column;
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            min-height: 190px;
            height: 43vh;
            gap: 8px;
        }

        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .product-image-container {
            width: 100%;
            height: 100px;
            border-radius: 6px;
            overflow: hidden;
            margin-bottom: 8px;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 6px;
        }

        .product-image-placeholder {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #666;
        }

        .product-image-placeholder i {
            font-size: 30px;
            margin-bottom: 5px;
        }

        .product-info-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 0;
            gap: 4px;
        }

        .product-header {
            margin-bottom: 6px;
            min-height: auto;
        }

        .product-price {
            font-size: 15px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 4px;
            line-height: 1.2;
        }

        .product-name {
            font-size: 13px;
            color: var(--dark-color);
            margin-bottom: 4px;
            font-weight: 600;
            line-height: 1.3;
            height: auto;
            overflow: visible;
            display: block;
            word-break: break-word;
            min-height: 34px;
        }

        .product-details {
            font-size: 11px;
            color: #666;
            line-height: 1.2;
            margin-bottom: 6px;
            height: auto;
            overflow: visible;
            display: block;
            min-height: 26px;
        }

        .product-footer {
            margin-top: auto;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .product-stock {
            font-size: 11px;
            padding: 4px 6px;
            border-radius: 4px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-bottom: 3px;
            width: 100%;
            justify-content: center;
        }

        .product-barcode {
            font-size: 10px;
            color: #6c757d;
            margin-top: 3px;
            display: flex;
            align-items: center;
            gap: 4px;
            justify-content: center;
            padding: 2px 6px;
            background: #f8f9fa;
            border-radius: 4px;
            border: 1px solid #e9ecef;
        }

        /* Products Grid - More compact */
        .products-grid {
            flex: 1;
            padding: 12px;
            overflow-y: auto;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
            gap: 12px;
            background: white;
        }

        /* Status badges - Smaller */
        .status-badge {
            position: absolute;
            top: 8px;
            right: 8px;
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 9px;
            font-weight: 600;
            z-index: 2;
        }

        /* Fixed Right Cart Section - COMPACT */
        .cart-section {
            width: 400px;
            background: white;
            border-left: 1px solid #ddd;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .cart-header {
            padding: 15px 20px;
            background: var(--primary-color);
            border-bottom: 1px solid #ddd;
            font-size: 16px;
            font-weight: 600;
            color: white;
            flex-shrink: 0;
        }

        .cart-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            height: 100%;
        }

        .cart-items-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            min-height: 0;
            height: calc(100% - 180px);
        }

        .cart-items {
            flex: 1;
            overflow-y: auto;
            padding: 12px;
            background: #fff;
            height: 100%;
        }

        .cart-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        .cart-table th {
            text-align: left;
            padding: 8px 10px;
            border-bottom: 2px solid #e0e0e0;
            font-weight: 600;
            color: #555;
            background: #f8f9fa;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .cart-table th:first-child {
            width: 45%;
        }

        .cart-table th:nth-child(2),
        .cart-table th:nth-child(3) {
            width: 15%;
        }

        .cart-table th:last-child {
            width: 25%;
            text-align: center;
        }

        .cart-table td {
            padding: 8px 10px;
            border-bottom: 1px solid #f0f0f0;
            vertical-align: middle;
        }

        .cart-table tr:hover {
            background-color: #f9f9f9;
        }

        .cart-table td:last-child {
            text-align: center;
            min-width: 100px;
        }

        /* Product info in cart */
        .product-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .cart-product-name {
            font-weight: 600;
            font-size: 13px;
            color: #333;
            line-height: 1.2;
            margin-bottom: 3px;
        }

        .cart-product-barcode {
            font-size: 11px;
            color: #777;
            display: flex;
            align-items: center;
            gap: 4px;
            margin-bottom: 3px;
        }

        .cart-product-price {
            font-size: 11px;
            color: #28a745;
            font-weight: 500;
        }

        /* Quantity display in cart - FIXED */
        .quantity-display {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            background: #f8f9fa;
            border-radius: 4px;
            padding: 4px 8px;
            min-width: 80px;
            cursor: pointer;
            transition: all 0.3s;
            border: 1px solid #e0e0e0;
            height: 32px;
        }

        .quantity-display:hover {
            background: #e9ecef;
            border-color: var(--secondary-color);
        }

        .quantity-value {
            font-weight: 600;
            color: var(--primary-color);
            min-width: 30px;
            text-align: center;
            font-size: 13px;
        }

        .quantity-unit {
            font-size: 11px;
            color: #666;
            font-weight: 500;
            min-width: 30px;
            text-align: center;
        }

        /* Action buttons in cart - FIXED */
        .action-buttons-container {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-width: 70px;
        }

        .edit-btn, .delete-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 11px;
        }

        .edit-btn {
            background: var(--primary-color);
            color: white;
        }

        .edit-btn:hover {
            background: #3a5999;
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        .delete-btn {
            background: var(--danger-color);
            color: white;
        }

        .delete-btn:hover {
            background: #d32f2f;
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        /* Cart totals - SIMPLIFIED (ONLY TOTAL) */
        .cart-totals {
            background: #f8f9fa;
            border-top: 2px solid #e0e0e0;
            padding: 20px;
            flex-shrink: 0;
            height: 80px;
            display: none;
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 18px;
            font-weight: 700;
            color: var(--primary-color);
        }

        .total-label {
            color: #333;
            font-weight: 600;
        }

        .total-value {
            font-weight: 700;
            color: var(--primary-color);
            font-size: 22px;
        }

        /* Options Section */
        .options-section {
            padding: 12px;
            background: white;
            border-top: 1px solid #ddd;
            flex-shrink: 0;
            height: 100px;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-bottom: 8px;
        }

        .action-btn {
            width: 100%;
            padding: 10px;
            background: var(--success-color);
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .action-btn:hover {
            transform: translateY(-2px);
        }

        .fast-cash-btn {
            background: var(--warning-color);
        }

        .fast-cash-btn:hover {
            background: #e67e22;
            box-shadow: 0 5px 15px rgba(243, 156, 18, 0.3);
        }

        .checkout-btn {
            background: var(--success-color);
        }

        .checkout-btn:hover {
            background: #45a049;
            box-shadow: 0 5px 15px rgba(76, 175, 80, 0.3);
        }

        .clear-cart-btn {
            background: var(--danger-color);
        }

        .clear-cart-btn:hover {
            background: #d32f2f;
            box-shadow: 0 5px 15px rgba(244, 67, 54, 0.3);
        }

        /* Hold/Recall button styles */
        .hold-btn {
            background: var(--secondary-color);
        }

        .hold-btn:hover {
            background: #e67e22;
            box-shadow: 0 5px 15px rgba(255, 152, 0, 0.3);
        }

        .recall-btn {
            background: #9c27b0;
        }

        .recall-btn:hover {
            background: #7b1fa2;
            box-shadow: 0 5px 15px rgba(156, 39, 176, 0.3);
        }

        /* Loading Spinner */
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid var(--secondary-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 50px auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Modal Styles */
        .modal-content {
            border-radius: 12px;
            border: none;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }

        .modal-header {
            background: var(--primary-color);
            color: white;
            border-radius: 12px 12px 0 0;
            border: none;
            padding: 20px 25px;
        }

        .modal-header .btn-close {
            filter: brightness(0) invert(1);
            opacity: 0.8;
        }

        .modal-body {
            padding: 25px;
        }

        .modal-footer {
            border-top: 1px solid #e0e0e0;
            padding: 20px 25px;
        }

        /* Hold carts list */
        .hold-cart-item {
            padding: 12px;
            margin-bottom: 8px;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .hold-cart-item:hover {
            background-color: #f0f7ff;
            border-color: var(--primary-color);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .hold-cart-time {
            font-size: 12px;
            color: #666;
        }

        .hold-cart-items {
            font-size: 12px;
            color: #888;
        }

        .hold-cart-total {
            font-weight: 600;
            color: var(--primary-color);
            font-size: 14px;
        }

        /* Hold cart badge */
        .hold-badge {
            background: var(--warning-color);
            color: #333;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 10px;
            font-weight: 600;
            margin-left: 5px;
        }

        /* No items message */
        .no-items-message {
            text-align: center;
            color: #666;
            padding: 40px 20px;
            font-style: italic;
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .pos-container {
                flex-direction: column;
            }
            
            .categories-section {
                width: 100%;
                height: auto;
                max-height: 70px;
                display: flex;
                overflow-x: auto;
                overflow-y: hidden;
                flex-wrap: nowrap;
                padding: 8px 12px;
            }
            
            .category-tab {
                flex: 0 0 auto;
                min-width: 130px;
                justify-content: center;
                border-bottom: none;
                border-right: 1px solid rgba(255,255,255,0.1);
                white-space: nowrap;
                padding: 12px 15px;
                font-size: 14px;
            }
            
            .cart-section {
                width: 100%;
                height: 400px;
            }
            
            .categories-section::-webkit-scrollbar {
                height: 6px;
                width: auto;
            }
            
            .categories-section::-webkit-scrollbar-track {
                background: rgba(0, 0, 0, 0.1);
                border-radius: 3px;
                margin: 0 10px;
            }
            
            .categories-section::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 3px;
            }
            
            .categories-section::-webkit-scrollbar-thumb:hover {
                background: rgba(255, 255, 255, 0.5);
            }
        }

        @media (max-width: 768px) {
            .products-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                gap: 10px;
                padding: 10px;
            }
            
            .product-card {
                min-height: 200px;
                padding: 10px;
            }
            
            .product-image-container {
                height: 100px;
            }
            
            .product-name {
                font-size: 13px;
                height: 34px;
            }
            
            .cart-section {
                height: 350px;
            }
            
            .cart-table th,
            .cart-table td {
                padding: 6px 8px;
                font-size: 12px;
            }
            
            .cart-product-name {
                font-size: 12px;
            }
            
            .quantity-display {
                min-width: 70px;
            }
            
            .action-buttons-container {
                min-width: 60px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        .products-grid::-webkit-scrollbar {
            width: 8px;
        }

        .products-grid::-webkit-scrollbar-track {
            background: #f8f9fa;
            border-radius: 4px;
        }

        .products-grid::-webkit-scrollbar-thumb {
            background: #d1d5db;
            border-radius: 4px;
        }

        .products-grid::-webkit-scrollbar-thumb:hover {
            background: #9ca3af;
        }

        .cart-items::-webkit-scrollbar {
            width: 6px;
        }

        .cart-items::-webkit-scrollbar-track {
            background: #f8f9fa;
            border-radius: 3px;
        }

        .cart-items::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }

        .cart-items::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        /* Status badges */
        .status-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: 600;
            z-index: 2;
        }
        
        .discount-badge {
            background: var(--danger-color);
            color: white;
        }
        
        .new-badge {
            background: var(--success-color);
            color: white;
        }
        
        /* Stock status */
        .stock-out {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
        
        .stock-available {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }
        
        /* Disabled product */
        .product-disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .product-disabled:hover {
            transform: none !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05) !important;
        }
    </style>
</head>

<body>
    <?php include("header.php"); ?>
    
    <!-- Main POS Container -->
    <div class="pos-container">
        <!-- Left Categories Section -->
        <div class="categories-section">
            <div class="category-tab active" onclick="selectCategory('all')">
                <i class="fas fa-boxes"></i>
                ALL ITEMS
            </div>
            <div id="categoryList"></div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Combined Search/Scan Bar -->
            <div class="pos-header">
                <div class="search-scan-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search product or scan barcode..." autocomplete="off" autofocus>
                </div>
            </div>
            
            <!-- Products Grid -->
            <div class="products-grid" id="productsGrid">
                <div class="spinner" id="productsSpinner"></div>
            </div>
        </div>
        
        <!-- Fixed Right Cart Section -->
        <div class="cart-section">
            <div class="cart-header">
                <div style="display: flex; align-items: center; justify-content: space-between;">
                    <div>
                        <i class="fas fa-shopping-cart me-2"></i>
                        CURRENT SALE
                        <span id="holdStatusBadge" class="hold-badge" style="display: none;">HOLD</span>
                    </div>
                    <div class="badge bg-light text-dark rounded-pill" id="cartCount">0</div>
                </div>
            </div>
            
            <div class="cart-content">
                <div class="cart-items-container">
                    <div class="cart-items">
                        <table class="cart-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Qty</th>
                                    <th>Total</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="cartTableBody">
                                <tr id="emptyCartMessage">
                                    <td colspan="4" class="no-items-message">
                                        <div style="text-align: center; padding: 40px 20px;">
                                            <i class="fas fa-shopping-cart" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                                            <p style="color: #999; font-size: 16px;">Your cart is empty</p>
                                            <p style="color: #777; font-size: 14px;">Add products to start a sale</p>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Cart Totals - ONLY TOTAL DISPLAY -->
                <div class="cart-totals" id="cartTotals" style="display: none;">
                    <div class="total-row">
                        <span class="total-label">Total:</span>
                        <span class="total-value" id="totalDisplay">€0.00</span>
                    </div>
                </div>
                
                <!-- Options Section -->
                <div class="options-section">
                    <div class="action-buttons">
                        <button class="action-btn hold-btn" onclick="holdCurrentCart()">
                            <i class="fas fa-pause me-2"></i> Hold Cart
                        </button>
                        <button class="action-btn recall-btn" onclick="showHoldCarts()">
                            <i class="fas fa-history me-2"></i> Recall Cart
                        </button>
                    </div>
                    
                    <div class="action-buttons">
                        <button class="action-btn fast-cash-btn" onclick="openFastCash()">
                            <i class="fas fa-money-bill-wave me-2"></i> Cash
                        </button>
                        <button class="action-btn checkout-btn" onclick="openCheckout()">
                            <i class="fas fa-credit-card me-2"></i> Checkout
                        </button>
                    </div>
                    
                    <button class="action-btn clear-cart-btn" onclick="clearCart()">
                        <i class="fas fa-trash-alt me-2"></i> Clear Cart
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Quantity Modal -->
    <div class="modal fade" id="editQuantityModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-edit me-2"></i>
                        Edit Quantity
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-4">
                        <h6 id="productNameLabel" class="text-center mb-3"></h6>
                        <div class="text-center text-muted small">
                            <span id="currentQuantityDisplay">0</span> <span id="currentUnitDisplay"></span> currently in cart
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label mb-2">
                            <i class="fas fa-layer-group me-1"></i>
                            Enter New Quantity
                        </label>
                        <div class="input-group input-group-lg">
                            <input type="number" 
                                   class="form-control" 
                                   id="newQuantity" 
                                   value="1" 
                                   min="0.001" 
                                   step="0.001"
                                   autofocus>
                            <span class="input-group-text" id="unitDisplay"></span>
                        </div>
                        <div class="form-text mt-2">
                            <i class="fas fa-info-circle me-1"></i>
                            <span id="quantityHelper">Enter new quantity</span>
                            <br>
                            <span id="stockInfo" class="text-muted"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" onclick="deleteItem()">
                        <i class="fas fa-trash me-1"></i> Remove
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-primary" onclick="saveQuantity()">
                        <i class="fas fa-save me-1"></i> Update
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Hold Carts Modal -->
    <div class="modal fade" id="holdCartsModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-history me-2"></i>
                        Hold Carts
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="holdCartsList">
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-clock fa-3x mb-3" style="color: #ddd;"></i>
                            <p>No carts on hold</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger" onclick="clearAllHoldCarts()">
                        <i class="fas fa-trash me-1"></i> Clear All
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Fast Cash Modal -->
    <div class="modal fade" id="fastCashModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cash Payment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <h3>Total Amount</h3>
                        <h1 class="text-success" id="modalTotal">€0.00</h1>
                    </div>
                    
                    <div class="row g-2 mb-4">
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(10)">€10</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(20)">€20</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(50)">€50</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(100)">€100</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(500)">€500</button>
                        </div>
                        <div class="col-4">
                            <button class="btn btn-outline-primary w-100 py-3" onclick="applyCash(1000)">€1000</button>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Custom Amount</label>
                        <input type="number" class="form-control" id="customAmount" placeholder="Enter amount" step="0.01" oninput="applyCustomCash()">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Cash Received</label>
                        <input type="number" class="form-control" id="cashReceived" placeholder="0.00" step="0.01" value="0.00" oninput="calculateChange()">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Change</label>
                        <input type="text" class="form-control bg-light" id="changeDue" readonly value="0.00">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="processCashPayment()">Complete Payment</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Checkout Modal -->
    <div class="modal fade" id="checkoutModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Complete Sale</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <h3>Total Amount</h3>
                        <h1 class="text-success" id="checkoutTotal">€0.00</h1>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Payment Method</label>
                        <select class="form-select" id="paymentMethod">
                            <option value="cash">Cash</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="debit_card">Debit Card</option>
                            <option value="mobile">Mobile Payment</option>
                            <option value="online">Online Payment</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Customer Name (Optional)</label>
                        <input type="text" class="form-control" id="customerName" placeholder="Enter customer name">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Customer Phone (Optional)</label>
                        <input type="text" class="form-control" id="customerPhone" placeholder="Enter customer phone">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Notes (Optional)</label>
                        <textarea class="form-control" id="customerNotes" rows="2" placeholder="Any special instructions..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" onclick="completeCheckout()">
                        <i class="fas fa-check me-1"></i> Complete Sale
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    // Main variables
    let cart = JSON.parse(localStorage.getItem('pos_cart')) || [];
    let holdCarts = JSON.parse(localStorage.getItem('pos_hold_carts')) || [];
    let selectedCategory = 'all';
    let categories = [];
    let products = [];
    let isProcessingBarcode = false;
    let lastBarcodeTime = 0;
    let cashReceived = 0;
    let searchTimer;
    let isManualSearch = false;
    let storeSettings = {
        store_name: 'My Store',
        store_address: '123 Main Street, City',
        store_phone: '+1 234 567 8900',
        receipt_footer: 'Thank you for shopping with us!',
        tax_rate: '0.0',
        currency: 'USD',
        store_email: 'store@example.com'
    };
    
    // Edit modal variables
    let editingProductId = null;
    let editingProductData = null;
    
    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        console.log('POS System Initializing...');
        loadCategories();
        loadProducts();
        loadStoreSettings();
        updateCartDisplay();
        updateCartCount();
        calculateCartTotals();
        
        // Setup combined search/scan bar
        setupSearchScanBar();
        
        // Auto-focus search input
        setTimeout(() => {
            document.getElementById('searchInput').focus();
        }, 500);
        
        // Listen for storage changes (for multi-tab sync)
        window.addEventListener('storage', function(e) {
            if (e.key === 'pos_cart') {
                cart = JSON.parse(e.newValue || '[]');
                updateCartDisplay();
                calculateCartTotals();
                updateCartCount();
            }
            if (e.key === 'pos_hold_carts') {
                holdCarts = JSON.parse(e.newValue || '[]');
            }
        });
    });
    
    // Load store settings
    function loadStoreSettings() {
        fetch('get_settings.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok: ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                // Merge with existing settings
                storeSettings = { ...storeSettings, ...data };
                
                // Save to localStorage for offline use
                localStorage.setItem('store_settings', JSON.stringify(storeSettings));
                
                // Apply settings to UI
                applyStoreSettings();
                
                // Recalculate cart with new settings
                if (cart.length > 0) {
                    calculateCartTotals();
                }
            })
            .catch(error => {
                // Fallback to localStorage
                const savedSettings = localStorage.getItem('store_settings');
                if (savedSettings) {
                    try {
                        storeSettings = JSON.parse(savedSettings);
                    } catch (e) {
                        console.error('Error parsing localStorage settings:', e);
                    }
                }
                
                applyStoreSettings();
                
                if (cart.length > 0) {
                    calculateCartTotals();
                }
            });
    }
    
    // Apply store settings to UI
    function applyStoreSettings() {
        const taxRate = parseFloat(storeSettings.tax_rate || 0);
        
        // Show/hide tax row
        const taxRow = document.getElementById('taxRow');
        if (taxRow) {
            taxRow.style.display = 'none'; // Hide tax row
        }
    }
    
    // Get currency symbol
    function getCurrencySymbol() {
        const currency = storeSettings.currency || 'USD';
        switch(currency) {
            case 'USD': return '$';
            case 'EUR': return '€';
            case 'GBP': return '£';
            case 'INR': return '₹';
            default: return '$';
        }
    }
    
    // Setup combined search and scan bar
    function setupSearchScanBar() {
        const searchInput = document.getElementById('searchInput');
        
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const value = this.value.trim();
                
                if (value && !isProcessingBarcode && isValidBarcode(value)) {
                    processBarcode(value);
                }
            }
            
            if (e.key === 'Escape') {
                this.value = '';
                displayProducts();
                isManualSearch = false;
            }
        });
        
        searchInput.addEventListener('input', function() {
            const value = this.value.trim();
            
            if (value.length === 0) {
                clearTimeout(searchTimer);
                displayProducts();
                isManualSearch = false;
                return;
            }
            
            clearTimeout(searchTimer);
            
            if (/^\d+$/.test(value) && value.length >= 8 && !isProcessingBarcode) {
                searchTimer = setTimeout(() => {
                    processBarcode(value);
                }, 300);
                isManualSearch = false;
            } else {
                isManualSearch = true;
                searchTimer = setTimeout(() => {
                    displayProducts(value);
                }, 300);
            }
        });
    }
    
    // Check if it's a valid barcode
    function isValidBarcode(barcode) {
        if (!barcode || barcode.trim() === '') return false;
        barcode = barcode.trim();
        return /^\d+$/.test(barcode) && barcode.length >= 8;
    }
    
    // Process barcode
    function processBarcode(barcode) {
        if (isProcessingBarcode || isManualSearch) return;
        
        const now = Date.now();
        if (now - lastBarcodeTime < 500) {
            return;
        }
        lastBarcodeTime = now;
        
        isProcessingBarcode = true;
        
        // Find product by barcode
        let product = products.find(p => {
            if (!p.barcode) return false;
            return p.barcode.toString().trim() === barcode.toString().trim();
        });
        
        // If not found, try removing leading zeros
        if (!product) {
            product = products.find(p => {
                if (!p.barcode) return false;
                const dbBarcode = p.barcode.toString().replace(/^0+/, '');
                const scanBarcode = barcode.toString().replace(/^0+/, '');
                return dbBarcode === scanBarcode;
            });
        }
        
        if (product) {
            const unit = product.unit || 'pcs';
            const currentStock = parseFloat(product.quantity);
            
            // Check stock for piece items
            if (isPieceUnit(unit) && currentStock <= 0) {
                showNotification(`${product.name} is out of stock!`, 'error');
                
                setTimeout(() => {
                    document.getElementById('searchInput').value = '';
                    document.getElementById('searchInput').focus();
                    isProcessingBarcode = false;
                    isManualSearch = false;
                }, 1000);
                return;
            }
            
            // Add to cart
            const existingItem = cart.find(item => item.id == product.id);
            const defaultQuantity = getDefaultQuantity(unit);
            
            if (existingItem) {
                if (isPieceUnit(unit)) {
                    if (existingItem.quantity + defaultQuantity > currentStock) {
                        showNotification(`Only ${currentStock} ${unit} available!`, 'error');
                        
                        setTimeout(() => {
                            document.getElementById('searchInput').value = '';
                            document.getElementById('searchInput').focus();
                            isProcessingBarcode = false;
                            isManualSearch = false;
                        }, 1000);
                        return;
                    }
                }
                existingItem.quantity += defaultQuantity;
            } else {
                cart.push({
                    id: product.id,
                    name: product.name,
                    price: parseFloat(product.price),
                    quantity: defaultQuantity,
                    unit: unit,
                    stock: currentStock,
                    min_stock: product.min_stock || 0,
                    barcode: product.barcode,
                    image: product.image || ''
                });
            }
            
            updateCart();
            showNotification(`${product.name} added to cart`, 'success');
            
            // Clear input and focus again
            setTimeout(() => {
                document.getElementById('searchInput').value = '';
                document.getElementById('searchInput').focus();
                isProcessingBarcode = false;
                isManualSearch = false;
            }, 500);
            
        } else {
            showNotification(`Product not found! Code: ${barcode}`, 'error');
            
            setTimeout(() => {
                document.getElementById('searchInput').value = '';
                document.getElementById('searchInput').focus();
                isProcessingBarcode = false;
                isManualSearch = false;
            }, 1500);
        }
    }
    
    // Load categories
    function loadCategories() {
        fetch('get_categories.php')
            .then(response => response.json())
            .then(data => {
                categories = data;
                updateCategoryList();
            })
            .catch(error => {
                console.error('Error loading categories:', error);
            });
    }
    
    // Update category list
    function updateCategoryList() {
        const categoryList = document.getElementById('categoryList');
        categoryList.innerHTML = '';
        
        categories.forEach(category => {
            const tab = document.createElement('div');
            tab.className = 'category-tab';
            tab.innerHTML = `
                <i class="fas fa-tag"></i>
                ${category.name.toUpperCase()}
            `;
            tab.onclick = () => selectCategory(category.id);
            categoryList.appendChild(tab);
        });
    }
    
    // Load products with image debugging
    function loadProducts() {
        console.log('Loading products...');
        fetch('get_products.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Products loaded successfully:', data.length);
                products = data;
                
                // Debug: Log products with images
                const productsWithImages = products.filter(p => p.image && p.image.trim() !== '');
                console.log(`Products with images: ${productsWithImages.length}/${products.length}`);
                
                if (productsWithImages.length > 0) {
                    console.log('Sample products with images:', 
                        productsWithImages.slice(0, 3).map(p => ({
                            name: p.name,
                            image: p.image,
                            imageUrl: `uploads/products/${p.image}`
                        }))
                    );
                }
                
                displayProducts();
                document.getElementById('productsSpinner').style.display = 'none';
            })
            .catch(error => {
                console.error('Error loading products:', error);
                document.getElementById('productsSpinner').style.display = 'none';
                showNotification('Error loading products', 'error');
            });
    }
    
    // Handle image loading errors
    function handleImageError(imgElement, productName = '') {
        console.warn(`Image failed to load: ${imgElement.src} for product: ${productName}`);
        
        const container = imgElement.parentElement;
        container.innerHTML = `
            <div class="product-image-placeholder">
                <i class="fas fa-box"></i>
                <div style="font-size: 10px; margin-top: 5px; color: #666;">
                    ${productName.substring(0, 15)}${productName.length > 15 ? '...' : ''}
                </div>
            </div>
        `;
    }
    
    // Display product card with IMAGE and NAME
    function displayProductCard(product) {
        const productsGrid = document.getElementById('productsGrid');
        const card = document.createElement('div');
        
        const unit = product.unit || 'pcs';
        const currentStock = parseFloat(product.quantity);
        const isOutOfStock = currentStock <= 0 && isPieceUnit(unit);
        const price = parseFloat(product.price || 0);
        
        // Get product image URL - FIXED PATH
        let imageUrl = '';
        let hasValidImage = false;
        
        if (product.image && product.image.trim() !== '' && product.image !== 'null') {
            const imageName = product.image.trim();
            
            // Use consistent path: uploads/products/filename
            imageUrl = `uploads/products/${imageName}`;
            hasValidImage = true;
            
            console.log(`Setting image for ${product.name}: ${imageUrl}`);
        }
        
        card.className = `product-card ${isOutOfStock ? 'product-disabled' : ''}`;
        
        if (!isOutOfStock) {
            card.onclick = () => addToCart(product.id);
        }
        
        // Add status badges if needed
        let statusBadge = '';
        if (product.discount_percent && product.discount_percent > 0) {
            statusBadge = `<span class="status-badge discount-badge">-${product.discount_percent}%</span>`;
        } else if (product.is_new) {
            statusBadge = `<span class="status-badge new-badge">NEW</span>`;
        }
        
        card.innerHTML = `
            ${statusBadge}
            <div class="product-image-container">
                ${hasValidImage ? 
                    `<img src="${imageUrl}" 
                          alt="${product.name}" 
                          class="product-image" 
                          onerror="handleImageError(this, '${product.name.replace(/'/g, "\\'")}')">` : 
                    `<div class="product-image-placeholder">
                        <i class="fas fa-box"></i>
                        <div style="font-size: 10px; margin-top: 5px;">
                            ${product.name.substring(0, 10)}${product.name.length > 10 ? '...' : ''}
                        </div>
                    </div>`
                }
            </div>
            
            <div class="product-info-container">
                <div class="product-header">
                    <div class="product-price">
                        ${getCurrencySymbol()}${price.toFixed(2)}
                    </div>
                    <div class="product-name" title="${product.name}">
                        ${product.name}
                    </div>
                    ${product.description ? 
                        `<div class="product-details" title="${product.description}">${product.description}</div>` : 
                        ''
                    }
                </div>
                
                ${product.barcode ? 
                    `<div class="product-barcode">
                        <i class="fas fa-barcode"></i> ${product.barcode}
                    </div>` : 
                    ''
                }
                
                <div class="product-footer">
                    <div class="product-stock ${isOutOfStock ? 'stock-out' : 'stock-available'}">
                        <i class="fas fa-${isOutOfStock ? 'times-circle' : 'check-circle'}"></i>
                        ${isOutOfStock ? 'Out of stock' : `Stock: ${formatQuantity(currentStock)} ${unit}`}
                    </div>
                </div>
            </div>
        `;
        
        productsGrid.appendChild(card);
    }
    
    // Format quantity display
    function formatQuantity(qty) {
        if (Number.isInteger(qty)) {
            return qty;
        }
        return parseFloat(qty).toFixed(2);
    }
    
    // Display products
    function displayProducts(searchTerm = '') {
        const productsGrid = document.getElementById('productsGrid');
        productsGrid.innerHTML = '';
        
        let filteredProducts = selectedCategory === 'all' 
            ? products 
            : products.filter(p => p.category_id == selectedCategory);
        
        // Apply search filter
        if (searchTerm) {
            filteredProducts = filteredProducts.filter(product => 
                product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                (product.barcode && product.barcode.toString().includes(searchTerm)) ||
                (product.description && product.description.toLowerCase().includes(searchTerm.toLowerCase()))
            );
        }
        
        if (filteredProducts.length === 0) {
            productsGrid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 50px; color: #666;">
                    <i class="fas fa-box-open" style="font-size: 50px; margin-bottom: 20px; opacity: 0.3;"></i>
                    <p style="font-size: 18px; margin-bottom: 10px;">No products found</p>
                    <p style="color: #777;">Try a different search term or category</p>
                </div>
            `;
            return;
        }
        
        filteredProducts.forEach(product => {
            displayProductCard(product);
        });
    }
    
    // Select category
    function selectCategory(categoryId) {
        selectedCategory = categoryId;
        
        // Update active class
        document.querySelectorAll('.category-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        
        if (categoryId === 'all') {
            document.querySelectorAll('.category-tab')[0].classList.add('active');
        } else {
            const categoryTab = Array.from(document.querySelectorAll('.category-tab')).find(tab => 
                tab.textContent.includes(categories.find(c => c.id == categoryId)?.name || '')
            );
            if (categoryTab) categoryTab.classList.add('active');
        }
        
        // Clear search when changing category
        document.getElementById('searchInput').value = '';
        isManualSearch = false;
        displayProducts();
    }
    
    // Add to cart (manual click)
    function addToCart(productId) {
        const product = products.find(p => p.id == productId);
        if (!product) return;
        
        const unit = product.unit || 'pcs';
        
        // Check stock
        if (isPieceUnit(unit) && parseFloat(product.quantity) <= 0) {
            showNotification('This product is out of stock!', 'error');
            return;
        }
        
        const existingItem = cart.find(item => item.id == productId);
        const defaultQuantity = getDefaultQuantity(unit);
        
        if (existingItem) {
            if (isPieceUnit(unit)) {
                const productInDB = products.find(p => p.id == productId);
                if (existingItem.quantity + defaultQuantity > productInDB.quantity) {
                    showNotification(`Only ${productInDB.quantity} ${unit} available!`, 'error');
                    return;
                }
            }
            existingItem.quantity += defaultQuantity;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: parseFloat(product.price),
                quantity: defaultQuantity,
                unit: unit,
                stock: parseFloat(product.quantity),
                min_stock: product.min_stock || 0,
                barcode: product.barcode,
                image: product.image || ''
            });
        }
        
        updateCart();
        showNotification(`${product.name} added to cart`, 'success');
    }
    
    // Get default quantity based on unit
    function getDefaultQuantity(unit) {
        const u = unit || 'pcs';
        switch(u.toLowerCase()) {
            case 'kg':
            case 'kilo':
            case 'kilogram':
                return 0.100; // 100 grams
            case 'g':
            case 'gram':
                return 100; // 100 grams
            case 'pcs':
            case 'piece':
            case 'unit':
            case 'unidade':
                return 1;
            default:
                return 1;
        }
    }
    
    // Check if piece unit
    function isPieceUnit(unit) {
        if (!unit) return false;
        const pieceUnits = ['pcs', 'piece', 'unit', 'pack', 'box', 'bottle', 'unidade'];
        return pieceUnits.includes(unit.toLowerCase());
    }
    
    // Update cart
    function updateCart() {
        localStorage.setItem('pos_cart', JSON.stringify(cart));
        updateCartDisplay();
        calculateCartTotals();
        updateCartCount();
        updateHoldStatusBadge();
    }
    
    // Update cart count
    function updateCartCount() {
        const cartCount = document.getElementById('cartCount');
        if (cartCount) {
            cartCount.textContent = cart.length;
        }
    }
    
    // Update hold status badge
    function updateHoldStatusBadge() {
        const holdBadge = document.getElementById('holdStatusBadge');
        if (holdBadge) {
            if (cart.length > 0) {
                holdBadge.style.display = 'inline-block';
            } else {
                holdBadge.style.display = 'none';
            }
        }
    }
    
    // Update cart display
    function updateCartDisplay() {
        const cartTableBody = document.getElementById('cartTableBody');
        const cartTotals = document.getElementById('cartTotals');
        
        if (cart.length === 0) {
            cartTableBody.innerHTML = `
                <tr id="emptyCartMessage">
                    <td colspan="4" class="no-items-message">
                        <div style="text-align: center; padding: 40px 20px;">
                            <i class="fas fa-shopping-cart" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                            <p style="color: #999; font-size: 16px;">Your cart is empty</p>
                            <p style="color: #777; font-size: 14px;">Add products to start a sale</p>
                        </div>
                    </td>
                </tr>
            `;
            
            cartTotals.style.display = 'none';
            updateHoldStatusBadge();
            return;
        }
        
        // Build cart items HTML
        let html = '';
        
        cart.forEach((item, index) => {
            const itemTotal = item.price * item.quantity;
            const quantityDisplay = isPieceUnit(item.unit) ? 
                Math.round(item.quantity) : 
                parseFloat(item.quantity).toFixed(3);
            
            html += `
                <tr>
                    <td>
                        <div class="product-info">
                            <div class="cart-product-name">${item.name}</div>
                            ${item.barcode ? 
                                `<div class="cart-product-barcode">
                                    <i class="fas fa-barcode"></i> ${item.barcode}
                                </div>` : 
                                ''
                            }
                            <div class="cart-product-price">
                                ${getCurrencySymbol()}${item.price.toFixed(2)} / ${item.unit}
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="quantity-display" onclick="openEditModal(${item.id})" 
                             title="Click to edit quantity">
                            <span class="quantity-value">${quantityDisplay}</span>
                            <span class="quantity-unit">${item.unit}</span>
                        </div>
                    </td>
                    <td style="font-weight: 600; color: var(--primary-color);">
                        ${getCurrencySymbol()}${itemTotal.toFixed(2)}
                    </td>
                    <td>
                        <div class="action-buttons-container">
                            <button class="edit-btn" onclick="openEditModal(${item.id})" 
                                    title="Edit quantity">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="delete-btn" onclick="removeFromCart(${item.id})" 
                                    title="Remove item">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        });
        
        cartTableBody.innerHTML = html;
        cartTotals.style.display = 'block';
        updateHoldStatusBadge();
    }
    
    // Calculate cart totals - SIMPLIFIED (ONLY TOTAL)
    function calculateCartTotals() {
        if (cart.length === 0) {
            document.getElementById('cartTotals').style.display = 'none';
            return;
        }
        
        // Calculate subtotal
        const subtotal = cart.reduce((sum, item) => {
            return sum + (item.price * item.quantity);
        }, 0);
        
        // Calculate tax using store settings
        const taxRate = parseFloat(storeSettings.tax_rate || 0);
        const tax = subtotal * (taxRate / 100);
        
        // Calculate total
        const total = subtotal + tax;
        
        // Get currency symbol
        const symbol = getCurrencySymbol();
        
        // Update ONLY TOTAL display
        const totalElement = document.getElementById('totalDisplay');
        if (totalElement) {
            totalElement.textContent = symbol + total.toFixed(2);
        }
        
        // Update modal totals
        const modalTotal = document.getElementById('modalTotal');
        const checkoutTotal = document.getElementById('checkoutTotal');
        
        if (modalTotal) modalTotal.textContent = symbol + total.toFixed(2);
        if (checkoutTotal) checkoutTotal.textContent = symbol + total.toFixed(2);
        
        // Show cart totals
        document.getElementById('cartTotals').style.display = 'block';
    }
    
    // Get cart amounts (subtotal, tax, total)
    function getCartAmounts() {
        if (cart.length === 0) {
            return {
                subtotal: 0,
                tax: 0,
                total: 0
            };
        }
        
        // Calculate subtotal
        const subtotal = cart.reduce((sum, item) => {
            return sum + (item.price * item.quantity);
        }, 0);
        
        // Calculate tax using store settings
        const taxRate = parseFloat(storeSettings.tax_rate || 0);
        const tax = subtotal * (taxRate / 100);
        
        // Calculate total
        const total = subtotal + tax;
        
        return {
            subtotal: subtotal,
            tax: tax,
            total: total
        };
    }
    
    // Hold current cart function
    function holdCurrentCart() {
        if (cart.length === 0) {
            showNotification('Cart is empty! Cannot hold.', 'error');
            return;
        }
        
        // Calculate totals
        const amounts = getCartAmounts();
        
        // Create hold cart object
        const holdCart = {
            id: Date.now().toString(),
            timestamp: new Date().toISOString(),
            items: [...cart],
            subtotal: amounts.subtotal,
            tax: amounts.tax,
            total: amounts.total,
            cashier: '<?php echo $_SESSION["username"]; ?>',
            itemCount: cart.length
        };
        
        // Add to hold carts array
        holdCarts.unshift(holdCart); // Add to beginning
        
        // Save to localStorage
        localStorage.setItem('pos_hold_carts', JSON.stringify(holdCarts));
        
        // Clear current cart
        cart = [];
        updateCart();
        
        showNotification(`Cart held successfully! Total: ${getCurrencySymbol()}${amounts.total.toFixed(2)}`, 'success');
    }
    
    // Show hold carts modal
    function showHoldCarts() {
        const holdCartsList = document.getElementById('holdCartsList');
        
        if (holdCarts.length === 0) {
            holdCartsList.innerHTML = `
                <div class="text-center text-muted py-4">
                    <i class="fas fa-clock fa-3x mb-3" style="color: #ddd;"></i>
                    <p>No carts on hold</p>
                </div>
            `;
        } else {
            let html = '<div class="row">';
            
            holdCarts.forEach((holdCart, index) => {
                const date = new Date(holdCart.timestamp);
                const timeString = date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                const dateString = date.toLocaleDateString();
                
                // Get first few items for preview
                const previewItems = holdCart.items.slice(0, 3).map(item => 
                    `${item.name.substring(0, 15)}${item.name.length > 15 ? '...' : ''}`
                ).join(', ');
                
                html += `
                    <div class="col-md-6 mb-3">
                        <div class="hold-cart-item" onclick="recallHoldCart('${holdCart.id}')">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <strong>Hold #${holdCarts.length - index}</strong>
                                    <div class="hold-cart-time">
                                        ${dateString} ${timeString}
                                    </div>
                                </div>
                                <div class="hold-cart-total">
                                    ${getCurrencySymbol()}${holdCart.total.toFixed(2)}
                                </div>
                            </div>
                            <div class="hold-cart-items">
                                <i class="fas fa-box me-1"></i>
                                ${holdCart.itemCount} items
                            </div>
                            <div class="text-muted small mt-1" style="font-size: 11px;">
                                ${previewItems}
                            </div>
                            <div class="mt-2 text-muted small">
                                <i class="fas fa-user me-1"></i>${holdCart.cashier}
                            </div>
                        </div>
                    </div>
                `;
            });
            
            html += '</div>';
            holdCartsList.innerHTML = html;
        }
        
        const modal = new bootstrap.Modal(document.getElementById('holdCartsModal'));
        modal.show();
    }
    
    // Recall hold cart
    function recallHoldCart(holdCartId) {
        const holdCart = holdCarts.find(cart => cart.id === holdCartId);
        
        if (!holdCart) {
            showNotification('Hold cart not found!', 'error');
            return;
        }
        
        Swal.fire({
            title: 'Recall Hold Cart?',
            html: `
                <div class="text-start">
                    <p>Hold Cart: ${new Date(holdCart.timestamp).toLocaleString()}</p>
                    <p><strong>Items:</strong> ${holdCart.itemCount}</p>
                    <p><strong>Total:</strong> ${getCurrencySymbol()}${holdCart.total.toFixed(2)}</p>
                    <p>Current cart has ${cart.length} items.</p>
                    <p>What would you like to do?</p>
                </div>
            `,
            icon: 'question',
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: 'Replace Current',
            denyButtonText: 'Add to Current',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                // Replace current cart
                cart = [...holdCart.items];
                updateCart();
                
                // Remove from hold carts
                holdCarts = holdCarts.filter(cart => cart.id !== holdCartId);
                localStorage.setItem('pos_hold_carts', JSON.stringify(holdCarts));
                
                showNotification('Cart recalled (replaced)', 'success');
                bootstrap.Modal.getInstance(document.getElementById('holdCartsModal')).hide();
                
            } else if (result.isDenied) {
                // Add to current cart
                holdCart.items.forEach(holdItem => {
                    const existingItem = cart.find(item => item.id == holdItem.id);
                    if (existingItem) {
                        existingItem.quantity += holdItem.quantity;
                    } else {
                        cart.push({...holdItem});
                    }
                });
                
                updateCart();
                
                // Remove from hold carts
                holdCarts = holdCarts.filter(cart => cart.id !== holdCartId);
                localStorage.setItem('pos_hold_carts', JSON.stringify(holdCarts));
                
                showNotification('Cart items added to current cart', 'success');
                bootstrap.Modal.getInstance(document.getElementById('holdCartsModal')).hide();
            }
        });
    }
    
    // Clear all hold carts
    function clearAllHoldCarts() {
        if (holdCarts.length === 0) {
            showNotification('No hold carts to clear', 'info');
            return;
        }
        
        Swal.fire({
            title: 'Clear All Hold Carts?',
            text: `This will remove ${holdCarts.length} hold carts permanently`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#f44336',
            cancelButtonColor: '#95a5a6',
            confirmButtonText: 'Yes, clear all!'
        }).then((result) => {
            if (result.isConfirmed) {
                holdCarts = [];
                localStorage.setItem('pos_hold_carts', JSON.stringify(holdCarts));
                
                // Update modal
                const holdCartsList = document.getElementById('holdCartsList');
                holdCartsList.innerHTML = `
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-clock fa-3x mb-3" style="color: #ddd;"></i>
                        <p>No carts on hold</p>
                    </div>
                `;
                
                showNotification('All hold carts cleared', 'info');
            }
        });
    }
    
    // Open edit modal
    function openEditModal(productId) {
        const item = cart.find(item => item.id == productId);
        if (!item) return;
        
        editingProductId = productId;
        editingProductData = item;
        
        // Get product from database for stock info
        const product = products.find(p => p.id == productId);
        const availableStock = product ? parseFloat(product.quantity) : 0;
        
        // Set modal content
        document.getElementById('productNameLabel').innerHTML = 
            `<strong>${item.name}</strong><br>
             <small class="text-muted">Price: ${getCurrencySymbol()}${item.price.toFixed(2)} per ${item.unit}</small>`;
        
        const currentQuantity = isPieceUnit(item.unit) ? 
            Math.round(item.quantity) : 
            parseFloat(item.quantity);
        
        document.getElementById('currentQuantityDisplay').textContent = formatQuantity(currentQuantity);
        document.getElementById('currentUnitDisplay').textContent = item.unit;
        
        // Set input values
        document.getElementById('newQuantity').value = currentQuantity;
        document.getElementById('unitDisplay').textContent = item.unit;
        
        // Update helper text
        const helper = document.getElementById('quantityHelper');
        const stockInfo = document.getElementById('stockInfo');
        
        if (isPieceUnit(item.unit)) {
            helper.textContent = `Enter whole number quantity`;
            document.getElementById('newQuantity').step = 1;
            document.getElementById('newQuantity').min = 1;
            stockInfo.textContent = `Available stock: ${Math.floor(availableStock)} ${item.unit}`;
        } else {
            helper.textContent = `Enter quantity in ${item.unit}`;
            document.getElementById('newQuantity').step = 0.001;
            document.getElementById('newQuantity').min = 0.001;
            stockInfo.textContent = `Available stock: ${availableStock.toFixed(2)} ${item.unit}`;
        }
        
        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('editQuantityModal'));
        modal.show();
        
        // Auto-focus input
        setTimeout(() => {
            document.getElementById('newQuantity').focus();
            document.getElementById('newQuantity').select();
        }, 500);
    }
    
    // Save quantity changes
    function saveQuantity() {
        const newQuantity = parseFloat(document.getElementById('newQuantity').value);
        
        if (isNaN(newQuantity) || newQuantity <= 0) {
            showNotification('Please enter a valid quantity', 'error');
            return;
        }
        
        const item = cart.find(item => item.id == editingProductId);
        if (!item) return;
        
        // Check stock for piece items
        if (isPieceUnit(item.unit)) {
            const product = products.find(p => p.id == editingProductId);
            if (product && newQuantity > product.quantity) {
                showNotification(`Only ${product.quantity} ${item.unit} available!`, 'error');
                return;
            }
            item.quantity = Math.round(newQuantity);
        } else {
            item.quantity = parseFloat(newQuantity.toFixed(3));
        }
        
        updateCart();
        
        // Close modal
        bootstrap.Modal.getInstance(document.getElementById('editQuantityModal')).hide();
        
        showNotification('Quantity updated successfully', 'success');
    }
    
    // Delete item from edit modal
    function deleteItem() {
        removeFromCart(editingProductId);
        bootstrap.Modal.getInstance(document.getElementById('editQuantityModal')).hide();
    }
    
    // Remove from cart
    function removeFromCart(productId) {
        Swal.fire({
            title: 'Remove Item',
            text: 'Are you sure you want to remove this item from cart?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#f44336',
            cancelButtonColor: '#95a5a6',
            confirmButtonText: 'Yes, remove!'
        }).then((result) => {
            if (result.isConfirmed) {
                cart = cart.filter(item => item.id != productId);
                updateCart();
                showNotification('Item removed from cart', 'info');
            }
        });
    }
    
    // Clear cart
    function clearCart() {
        if (cart.length === 0) return;
        
        Swal.fire({
            title: 'Clear Cart',
            text: 'Are you sure you want to clear all items?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#f44336',
            cancelButtonColor: '#95a5a6',
            confirmButtonText: 'Yes, clear!'
        }).then((result) => {
            if (result.isConfirmed) {
                cart = [];
                updateCart();
                showNotification('Cart cleared', 'info');
            }
        });
    }
    
    // Fast cash functions
    function openFastCash() {
        if (cart.length === 0) {
            showNotification('Cart is empty!', 'error');
            return;
        }
        
        const totalElement = document.getElementById('totalDisplay');
        if (!totalElement) {
            showNotification('Cannot get total amount', 'error');
            return;
        }
        
        const total = parseFloat(totalElement.textContent.replace(/[^\d.]/g, ''));
        document.getElementById('modalTotal').textContent = getCurrencySymbol() + total.toFixed(2);
        
        document.getElementById('cashReceived').value = '0.00';
        document.getElementById('changeDue').value = '0.00';
        document.getElementById('customAmount').value = '';
        cashReceived = 0;
        
        const modal = new bootstrap.Modal(document.getElementById('fastCashModal'));
        modal.show();
    }
    
    function applyCash(amount) {
        cashReceived += amount;
        document.getElementById('cashReceived').value = cashReceived.toFixed(2);
        calculateChange();
    }
    
    function applyCustomCash() {
        const customAmount = parseFloat(document.getElementById('customAmount').value) || 0;
        if (customAmount > 0) {
            cashReceived = customAmount;
            document.getElementById('cashReceived').value = cashReceived.toFixed(2);
            calculateChange();
        }
    }
    
    function calculateChange() {
        const totalElement = document.getElementById('modalTotal');
        if (!totalElement) return;
        
        const total = parseFloat(totalElement.textContent.replace(/[^\d.]/g, ''));
        cashReceived = parseFloat(document.getElementById('cashReceived').value) || 0;
        const change = cashReceived - total;
        
        const changeDueElement = document.getElementById('changeDue');
        if (changeDueElement) {
            if (change >= 0) {
                changeDueElement.value = getCurrencySymbol() + change.toFixed(2);
                changeDueElement.classList.remove('text-danger');
                changeDueElement.classList.add('text-success');
            } else {
                changeDueElement.value = getCurrencySymbol() + Math.abs(change).toFixed(2);
                changeDueElement.classList.remove('text-success');
                changeDueElement.classList.add('text-danger');
            }
        }
    }
    
    function processCashPayment() {
        const totalElement = document.getElementById('modalTotal');
        if (!totalElement) return;
        
        const total = parseFloat(totalElement.textContent.replace(/[^\d.]/g, ''));
        cashReceived = parseFloat(document.getElementById('cashReceived').value) || 0;
        
        if (cashReceived < total) {
            showNotification('Insufficient cash!', 'error');
            return;
        }
        
        const change = cashReceived - total;
        
        Swal.fire({
            title: 'Confirm Payment',
            html: `
                <div class="text-start">
                    <p><strong>Total:</strong> ${getCurrencySymbol()}${total.toFixed(2)}</p>
                    <p><strong>Cash Received:</strong> ${getCurrencySymbol()}${cashReceived.toFixed(2)}</p>
                    <p><strong>Change:</strong> ${getCurrencySymbol()}${change.toFixed(2)}</p>
                </div>
            `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Complete Payment',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                completeSale('cash', change);
            }
        });
    }
    
    // Checkout functions
    function openCheckout() {
        if (cart.length === 0) {
            showNotification('Cart is empty!', 'error');
            return;
        }
        
        const totalElement = document.getElementById('totalDisplay');
        if (!totalElement) {
            showNotification('Cannot get total amount', 'error');
            return;
        }
        
        const total = parseFloat(totalElement.textContent.replace(/[^\d.]/g, ''));
        document.getElementById('checkoutTotal').textContent = getCurrencySymbol() + total.toFixed(2);
        
        // Reset form fields
        document.getElementById('customerName').value = '';
        document.getElementById('customerPhone').value = '';
        document.getElementById('customerNotes').value = '';
        
        const modal = new bootstrap.Modal(document.getElementById('checkoutModal'));
        modal.show();
    }
    
    function completeCheckout() {
        const paymentMethod = document.getElementById('paymentMethod').value;
        const customerName = document.getElementById('customerName').value;
        const customerPhone = document.getElementById('customerPhone').value;
        const customerNotes = document.getElementById('customerNotes').value;
        const totalElement = document.getElementById('checkoutTotal');
        
        if (!totalElement) {
            showNotification('Cannot get total amount', 'error');
            return;
        }
        
        const total = parseFloat(totalElement.textContent.replace(/[^\d.]/g, ''));
        
        Swal.fire({
            title: 'Confirm Sale',
            html: `
                <div class="text-start">
                    <p><strong>Total Amount:</strong> ${getCurrencySymbol()}${total.toFixed(2)}</p>
                    <p><strong>Payment Method:</strong> ${paymentMethod.replace('_', ' ').toUpperCase()}</p>
                    ${customerName ? `<p><strong>Customer:</strong> ${customerName}</p>` : ''}
                    ${customerPhone ? `<p><strong>Phone:</strong> ${customerPhone}</p>` : ''}
                </div>
            `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Complete Sale',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                completeSale(paymentMethod, 0, customerName, customerPhone, customerNotes);
            }
        });
    }
    
    // Complete sale
    function completeSale(paymentMethod, change = 0, customerName = '', customerPhone = '', notes = '') {
        const amounts = getCartAmounts();
        
        const saleData = {
            items: cart,
            subtotal: amounts.subtotal,
            tax: amounts.tax,
            total: amounts.total,
            payment_method: paymentMethod,
            change: change,
            customer_name: customerName,
            customer_phone: customerPhone,
            notes: notes,
            cashier: '<?php echo $_SESSION["username"]; ?>',
            timestamp: new Date().toISOString(),
            tax_rate: parseFloat(storeSettings.tax_rate || 0)
        };
        
        console.log('Sale Data:', saleData);
        
        fetch('save_sale.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(saleData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Print receipt with subtotal
                const receiptNumber = data.receipt_number || 'SALE' + Date.now().toString().slice(-6);
                
                // Make sure we have all the data for receipt
                const receiptSaleData = {
                    ...saleData,
                    subtotal: data.subtotal || saleData.subtotal,
                    tax: data.tax || saleData.tax,
                    total: data.total || saleData.total,
                    tax_rate: data.tax_rate || parseFloat(storeSettings.tax_rate || 0)
                };
                
                printReceipt(receiptSaleData, receiptNumber, data.sale_id);
                
                // Update product quantities
                updateProductQuantitiesAfterSale();
                
                // Clear cart
                cart = [];
                updateCart();
                calculateCartTotals();
                
                // Close modals
                const fastCashModal = bootstrap.Modal.getInstance(document.getElementById('fastCashModal'));
                const checkoutModal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
                
                if (fastCashModal) fastCashModal.hide();
                if (checkoutModal) checkoutModal.hide();
                
                // Show success message
                Swal.fire({
                    title: 'Sale Completed!',
                    text: 'Transaction completed successfully',
                    icon: 'success',
                    timer: 2000
                }).then(() => {
                    loadProducts();
                    document.getElementById('searchInput').focus();
                });
            } else {
                showNotification('Error: ' + (data.message || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Network error', 'error');
        });
    }
    
    // Update product quantities after sale
    function updateProductQuantitiesAfterSale() {
        const pieceItemsToUpdate = cart.filter(item => isPieceUnit(item.unit));
        
        if (pieceItemsToUpdate.length === 0) return;
        
        const updates = pieceItemsToUpdate.map(item => ({
            product_id: item.id,
            quantity_sold: item.quantity
        }));
        
        fetch('update_product_quantities.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ updates: updates })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadProducts();
            }
        })
        .catch(error => {
            console.error('Error updating quantities:', error);
        });
    }
    
    // Print Receipt Function
    function printReceipt(saleData, receiptNumber, saleId = null) {
        // If we have a sale ID, use the PHP receipt printer
        if (saleId) {
            const receiptWindow = window.open(`print_receipt.php?id=${saleId}`, '_blank', 'width=600,height=800');
            
            // Auto-print after loading
            setTimeout(() => {
                if (receiptWindow && !receiptWindow.closed) {
                    receiptWindow.print();
                }
            }, 1000);
        } else {
            // Fallback to HTML receipt
            printHTMLReceipt(saleData, receiptNumber);
        }
    }
    
    // Fallback HTML receipt function
    function printHTMLReceipt(saleData, receiptNumber) {
        const storeName = storeSettings.store_name || 'POS System';
        const storeAddress = storeSettings.store_address || '';
        const storePhone = storeSettings.store_phone || '';
        const storeEmail = storeSettings.store_email || '';
        const receiptFooter = storeSettings.receipt_footer || 'Thank you for shopping with us!';
        const taxRate = saleData.tax_rate || parseFloat(storeSettings.tax_rate || 0.0);
        const currencySymbol = getCurrencySymbol();
        
        // Get values from saleData
        const subtotal = parseFloat(saleData.subtotal) || saleData.items.reduce((sum, item) => 
            sum + (parseFloat(item.price) * parseFloat(item.quantity)), 0
        );
        
        const tax = parseFloat(saleData.tax) || (subtotal * (taxRate / 100));
        const total = parseFloat(saleData.total) || (subtotal + tax);
        
        console.log('Receipt Calculation:');
        console.log('Subtotal:', subtotal.toFixed(2));
        console.log('Tax Rate:', taxRate);
        console.log('Tax:', tax.toFixed(2));
        console.log('Total:', total.toFixed(2));
        
        const receiptWindow = window.open('', '_blank', 'width=600,height=700');
        
        receiptWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Receipt - ${receiptNumber}</title>
                <style>
                    @media print {
                        @page { margin: 0; }
                        body { margin: 0.5cm; }
                        .no-print { display: none !important; }
                    }
                    body { 
                        font-family: 'Courier New', monospace; 
                        max-width: 80mm; 
                        margin: 0 auto; 
                        padding: 10px;
                        font-size: 13px;
                        color: #000;
                    }
                    .header { text-align: center; margin-bottom: 15px; }
                    .header h2 { margin: 0; font-size: 18px; font-weight: bold; }
                    .store-info { font-size: 12px; margin: 2px 0; }
                    .details { margin: 15px 0; font-size: 12px; }
                    .details div { margin-bottom: 2px; }
                    table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 10px; }
                    th, td { padding: 5px; text-align: left; }
                    th { border-bottom: 2px solid #000; }
                    td { border-bottom: 1px dashed #000; }
                    .text-right { text-align: right; }
                    .text-center { text-align: center; }
                    .total, .subtotal, .tax { font-weight: bold; font-size: 14px; }
                    .totals { margin-top: 10px; }
                    .footer { text-align: center; margin-top: 20px; font-size: 11px; border-top: 1px dashed #000; padding-top: 5px; }
                    .print-btn { 
                        background: #007bff; 
                        color: white; 
                        border: none; 
                        padding: 10px 20px; 
                        border-radius: 5px; 
                        cursor: pointer; 
                        margin: 20px auto; 
                        display: block; 
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <h2>${storeName}</h2>
                    ${storeAddress ? `<div class="store-info">${storeAddress}</div>` : ''}
                    ${storePhone ? `<div class="store-info">📞 ${storePhone}</div>` : ''}
                    ${storeEmail ? `<div class="store-info">📧 ${storeEmail}</div>` : ''}
                    <div class="store-info">--------------------------------</div>
                </div>
                
                <div class="details">
                    <div><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>
                    <div><strong>Time:</strong> ${new Date().toLocaleTimeString()}</div>
                    <div><strong>Cashier:</strong> ${saleData.cashier}</div>
                    <div><strong>Receipt #:</strong> ${receiptNumber}</div>
                    ${saleData.customer_name ? `<div><strong>Customer:</strong> ${saleData.customer_name}</div>` : ''}
                    ${saleData.customer_phone ? `<div><strong>Phone:</strong> ${saleData.customer_phone}</div>` : ''}
                    <div>--------------------------------</div>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th class="text-right">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${saleData.items.map(item => {
                            const quantityDisplay = isPieceUnit(item.unit) ? 
                                Math.round(parseFloat(item.quantity)) : 
                                parseFloat(item.quantity).toFixed(3);
                            const itemPrice = parseFloat(item.price);
                            const itemQuantity = parseFloat(item.quantity);
                            const itemTotal = itemPrice * itemQuantity;
                            return `
                                <tr>
                                    <td>${item.name}</td>
                                    <td>${quantityDisplay} ${item.unit}</td>
                                    <td>${currencySymbol}${itemPrice.toFixed(2)}</td>
                                    <td class="text-right">${currencySymbol}${itemTotal.toFixed(2)}</td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>

                <div class="totals">
                    <div>--------------------------------</div>
                    <div class="subtotal">Subtotal: ${currencySymbol}${subtotal.toFixed(2)}</div>
                    <div class="tax">Tax (${taxRate.toFixed(1)}%): ${currencySymbol}${tax.toFixed(2)}</div>
                    <div class="total">TOTAL: ${currencySymbol}${total.toFixed(2)}</div>
                    <div>Payment: ${saleData.payment_method.replace('_', ' ').toUpperCase()}</div>
                    ${saleData.change > 0 ? `<div>Change: ${currencySymbol}${parseFloat(saleData.change).toFixed(2)}</div>` : ''}
                    <div>--------------------------------</div>
                </div>
                
                ${saleData.notes ? `<div class="notes" style="margin-top: 10px; font-size: 11px;">
                    <strong>Notes:</strong> ${saleData.notes}
                </div>` : ''}
                
                <div class="footer">
                    ${receiptFooter}
                    <div style="margin-top: 5px; font-size: 10px;">${new Date().toLocaleString()}</div>
                </div>
                
                <button class="print-btn no-print" onclick="window.print()">
                    <i class="fas fa-print"></i> Print Receipt
                </button>
                
                <script>
                    // Auto print after 1 second
                    setTimeout(() => {
                        window.print();
                    }, 1000);
                <\/script>
            </body>
            </html>
        `);
        
        receiptWindow.document.close();
    }
    
    // Utility functions
    function showNotification(message, type = 'info') {
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: type,
            title: message,
            showConfirmButton: false,
            timer: 3000
        });
    }
    </script>
</body>
</html>
