<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// Check if user is logged in and has permission
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Only admin can update barcodes
if ($_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Admin permission required']);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['product_id']) || !isset($data['barcode'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required data']);
    exit;
}

$product_id = intval($data['product_id']);
$barcode = $conn->real_escape_string(trim($data['barcode']));

// Start transaction
$conn->begin_transaction();

try {
    // Check if barcode already exists for another product
    $check_sql = "SELECT id, name FROM products WHERE barcode = ? AND barcode != '' AND barcode IS NOT NULL AND id != ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("si", $barcode, $product_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $existing = $check_result->fetch_assoc();
        $conn->rollback();
        echo json_encode([
            'success' => false, 
            'message' => "Barcode already assigned to: " . htmlspecialchars($existing['name'])
        ]);
        exit;
    }
    $check_stmt->close();
    
    // Update product barcode
    $sql = "UPDATE products SET barcode = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $barcode, $product_id);
    
    if ($stmt->execute()) {
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Barcode updated successfully']);
    } else {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

$conn->close();
?>