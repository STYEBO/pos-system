<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h1>Welcome, Admin <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <h5>Administrator Privileges</h5>
                    <ul>
                        <li>Manage all users (create, edit, delete)</li>
                        <li>View all sales reports</li>
                        <li>Configure system settings</li>
                        <li>Access all modules</li>
                    </ul>
                </div>
                <div class="mt-4">
                    <a href="dashboard.php" class="btn btn-primary me-2">Go to Main Dashboard</a>
                    <a href="manage_users.php" class="btn btn-success me-2">Manage Users</a>
                    <a href="logout.php" class="btn btn-danger">Logout</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>