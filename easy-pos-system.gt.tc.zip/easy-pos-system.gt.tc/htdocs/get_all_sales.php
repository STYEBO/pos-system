<?php
// get_all_sales.php
session_start();
require_once 'db.php';

// Fetch all sales for export
$sales = $conn->query("SELECT s.*, COUNT(si.id) as items_count FROM sales s LEFT JOIN sale_items si ON s.id = si.sale_id GROUP BY s.id ORDER BY s.created_at DESC");

$sales_data = [];
while($sale = $sales->fetch_assoc()) {
    $sales_data[] = $sale;
}

echo json_encode($sales_data);

$conn->close();
?>