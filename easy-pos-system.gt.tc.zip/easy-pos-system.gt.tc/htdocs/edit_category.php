<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

// Check if user is admin
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
if ($user_role != 'admin') {
    header("Location: dashboard.php");
    exit;
}

require_once 'db.php';

$category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$category = null;
$error = '';
$success = '';

// Fetch category data
if ($category_id > 0) {
    $stmt = $conn->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $category = $result->fetch_assoc();
    } else {
        $error = "Category not found!";
        header("Location: manage_categories.php?error=" . urlencode($error));
        exit;
    }
    $stmt->close();
} else {
    header("Location: manage_categories.php?error=Invalid category ID");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Category - QEloERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --header-bg: #001f3f;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
            --admin-color: #28a745;
            --cashier-color: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            background: white;
            margin-bottom: 20px;
        }
        
        .btn {
            padding: 10px 25px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #007bff;
            border: none;
        }
        
        .btn-primary:hover {
            background: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,123,255,0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
            border: none;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .form-control {
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.25rem rgba(0,123,255,0.25);
        }
        
        .alert {
            border-radius: 10px;
            border: none;
        }
        
        .header-title {
            color: #001f3f;
            font-weight: 700;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 3px solid #007bff;
        }
        
        .container-fluid {
            padding: 40px;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .back-link {
            color: #6c757d;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-bottom: 20px;
        }
        
        .back-link:hover {
            color: #007bff;
        }
        
        .system-badge {
            background: #17a2b8;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9em;
        }
        
        .success-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        
        .success-message {
            background: white;
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .success-icon {
            font-size: 60px;
            color: #28a745;
            margin-bottom: 20px;
        }
        
        .loading {
            opacity: 0.7;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <?php include("header.php"); ?>
    
    <!-- Success Overlay -->
    <div class="success-overlay" id="successOverlay">
        <div class="success-message">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3>Success!</h3>
            <p id="successMessage">Category updated successfully!</p>
            <p>Redirecting back to categories...</p>
            <div class="spinner-border text-primary mt-3" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>
    
    <!-- Error Alert -->
    <div class="alert-container" style="position: fixed; top: 80px; right: 20px; z-index: 1000; max-width: 400px;">
        <div class="alert alert-danger alert-dismissible fade show" id="errorAlert" style="display: none;">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <span id="errorMessage"></span>
            <button type="button" class="btn-close" onclick="hideError()"></button>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="container-fluid">
        <a href="manage_categories.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Categories
        </a>
        
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card" id="mainCard">
                    <div class="card-body p-4">
                        <h2 class="header-title text-center">Edit Category</h2>
                        
                        <?php if ($category): ?>
                        <div class="info-card mb-4" style="background: #f8f9fa; padding: 15px; border-radius: 8px; border-left: 4px solid #007bff;">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Category ID:</strong> <?php echo $category['id']; ?>
                                </div>
                                <div class="col-md-6">
                                    <strong>Status:</strong> 
                                    <?php if ($category['name'] == 'All Items'): ?>
                                        <span class="system-badge">
                                            <i class="fas fa-lock"></i> System Category
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Editable</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <form id="editCategoryForm">
                            <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                            
                            <div class="mb-4">
                                <label for="category_name" class="form-label fw-bold">Category Name *</label>
                                <input type="text" class="form-control" id="category_name" 
                                       name="category_name" 
                                       value="<?php echo htmlspecialchars($category['name']); ?>" 
                                       required
                                       placeholder="Enter category name"
                                       <?php echo ($category['name'] == 'All Items') ? 'readonly' : ''; ?>>
                                <?php if ($category['name'] == 'All Items'): ?>
                                    <div class="form-text text-warning">
                                        <i class="fas fa-exclamation-circle"></i>
                                        This is a system category. Name cannot be changed.
                                    </div>
                                <?php else: ?>
                                    <div class="form-text">Enter a unique category name</div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                                <a href="manage_categories.php" class="btn btn-secondary me-md-2">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                                <?php if ($category['name'] != 'All Items'): ?>
                                <button type="submit" class="btn btn-primary" id="submitBtn">
                                    <i class="fas fa-save"></i> Update Category
                                </button>
                                <?php endif; ?>
                            </div>
                        </form>
                        <?php else: ?>
                            <div class="alert alert-warning text-center">
                                <h5><i class="fas fa-exclamation-triangle"></i> Category not found!</h5>
                                <p>The category you're trying to edit doesn't exist or has been deleted.</p>
                                <a href="manage_categories.php" class="btn btn-warning mt-2">
                                    <i class="fas fa-arrow-left"></i> Back to Categories
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        // Auto-focus on category name field
        document.addEventListener('DOMContentLoaded', function() {
            const categoryNameField = document.getElementById('category_name');
            if (categoryNameField && !categoryNameField.readOnly) {
                categoryNameField.focus();
                categoryNameField.select();
            }
        });
        
        // Show error function
        function showError(message) {
            $('#errorMessage').text(message);
            $('#errorAlert').fadeIn();
        }
        
        // Hide error function
        function hideError() {
            $('#errorAlert').fadeOut();
        }
        
        // Show success function
        function showSuccess(message) {
            $('#successMessage').text(message);
            $('#successOverlay').fadeIn();
            
            // Redirect after 1.5 seconds
            setTimeout(function() {
                window.location.href = 'manage_categories.php?success=' + encodeURIComponent(message);
            }, 1500);
        }
        
        // Form submission with AJAX
        $('#editCategoryForm').on('submit', function(e) {
            e.preventDefault();
            
            const categoryName = $('#category_name').val().trim();
            const submitBtn = $('#submitBtn');
            const formData = $(this).serialize();
            
            // Validate
            if (!categoryName) {
                showError('Category name cannot be empty!');
                $('#category_name').focus();
                return;
            }
            
            // Disable submit button
            submitBtn.prop('disabled', true);
            submitBtn.html('<i class="fas fa-spinner fa-spin"></i> Updating...');
            $('#mainCard').addClass('loading');
            
            // Submit via AJAX to update_category.php
            $.ajax({
                url: 'update_category.php',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showSuccess(response.message);
                    } else {
                        // Re-enable submit button
                        submitBtn.prop('disabled', false);
                        submitBtn.html('<i class="fas fa-save"></i> Update Category');
                        $('#mainCard').removeClass('loading');
                        
                        // Show error
                        showError(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    // Re-enable submit button
                    submitBtn.prop('disabled', false);
                    submitBtn.html('<i class="fas fa-save"></i> Update Category');
                    $('#mainCard').removeClass('loading');
                    
                    showError('Network error. Please try again.');
                    console.error('AJAX Error:', error);
                }
            });
        });
    </script>
</body>
</html>