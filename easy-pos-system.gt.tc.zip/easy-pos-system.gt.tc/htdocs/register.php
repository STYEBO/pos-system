<?php
session_start();
include "db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Invalid request";
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    echo "Username and password are required";
    exit;
}

// Validate username
if (strlen($username) < 3) {
    echo "Username must be at least 3 characters";
    exit;
}

if (strlen($password) < 4) {
    echo "Password must be at least 4 characters";
    exit;
}

// Prevent creating admin via registration
if (strtolower($username) === 'admin') {
    echo "Cannot create admin account via registration";
    exit;
}

// Check if username exists
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "Username already exists";
    exit;
}

// Hash password and insert cashier
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$role = 'cashier';

$stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $hashedPassword, $role);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "Error: " . $conn->error;
}

$stmt->close();
$conn->close();
?>