<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

require_once 'db.php';
include ("header.php");

$message = '';
$message_type = '';

// Get current user info
$username = $_SESSION['username'];
$user_query = "SELECT * FROM users WHERE username = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("s", $username);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Get system settings
$settings_query = "SELECT setting_key, setting_value FROM system_settings";
$settings_result = $conn->query($settings_query);
$settings = [];
while($row = $settings_result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Validate passwords
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $message = 'All fields are required';
            $message_type = 'error';
        } elseif ($new_password !== $confirm_password) {
            $message = 'New passwords do not match';
            $message_type = 'error';
        } elseif (strlen($new_password) < 6) {
            $message = 'New password must be at least 6 characters';
            $message_type = 'error';
        } else {
            // Verify current password
            if (password_verify($current_password, $user['password_hash'])) {
                // Update password
                $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $update_query = "UPDATE users SET password_hash = ? WHERE username = ?";
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("ss", $new_password_hash, $username);
                
                if ($update_stmt->execute()) {
                    $message = 'Password changed successfully!';
                    $message_type = 'success';
                } else {
                    $message = 'Error updating password: ' . $conn->error;
                    $message_type = 'error';
                }
            } else {
                $message = 'Current password is incorrect';
                $message_type = 'error';
            }
        }
    }
    
    // Handle system settings update
    if (isset($_POST['save_settings'])) {
        $store_name = $_POST['store_name'] ?? $settings['store_name'];
        $tax_rate = $_POST['tax_rate'] ?? $settings['tax_rate'];
        $currency = $_POST['currency'] ?? $settings['currency'];
        $receipt_footer = $_POST['receipt_footer'] ?? $settings['receipt_footer'];
        $auto_print = isset($_POST['auto_print']) ? '1' : '0';
        $store_address = $_POST['store_address'] ?? '';
        $store_phone = $_POST['store_phone'] ?? '';
        $store_email = $_POST['store_email'] ?? '';
        
        try {
            $conn->begin_transaction();
            
            // Update each setting
            $update_setting = "INSERT INTO system_settings (setting_key, setting_value) 
                               VALUES (?, ?) 
                               ON DUPLICATE KEY UPDATE setting_value = ?";
            $stmt = $conn->prepare($update_setting);
            
            $settings_to_update = [
                'store_name' => $store_name,
                'tax_rate' => $tax_rate,
                'currency' => $currency,
                'receipt_footer' => $receipt_footer,
                'auto_print' => $auto_print,
                'store_address' => $store_address,
                'store_phone' => $store_phone,
                'store_email' => $store_email
            ];
            
            foreach ($settings_to_update as $key => $value) {
                $stmt->bind_param("sss", $key, $value, $value);
                $stmt->execute();
            }
            
            $conn->commit();
            
            // Update local settings array
            $settings = array_merge($settings, $settings_to_update);
            
            $message = 'Settings saved successfully!';
            $message_type = 'success';
        } catch (Exception $e) {
            $conn->rollback();
            $message = 'Error saving settings: ' . $e->getMessage();
            $message_type = 'error';
        }
    }
    
    // Handle profile update
    if (isset($_POST['update_profile'])) {
        $full_name = $_POST['full_name'] ?? '';
        $email = $_POST['email'] ?? '';
        $phone = $_POST['phone'] ?? '';
        
        $update_query = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE username = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("ssss", $full_name, $email, $phone, $username);
        
        if ($update_stmt->execute()) {
            $message = 'Profile updated successfully!';
            $message_type = 'success';
            // Refresh user data
            $user['full_name'] = $full_name;
            $user['email'] = $email;
            $user['phone'] = $phone;
        } else {
            $message = 'Error updating profile: ' . $conn->error;
            $message_type = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - QEloERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --header-bg: #001f3f;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
            --admin-color: #28a745;
            --cashier-color: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background: #007bff;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .nav-tabs .nav-link {
            color: #495057;
            font-weight: 500;
        }
        
        .nav-tabs .nav-link.active {
            color: #007bff;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #007bff;
            border: none;
            padding: 10px 25px;
            font-weight: 600;
        }
        
        .btn-primary:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">
                            <i class="fas fa-cog me-2"></i> Settings
                        </h4>
                    </div>
                    
                    <div class="card-body p-4">
                        <?php if ($message): ?>
                            <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show">
                                <?php echo $message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Tabs Navigation -->
                        <ul class="nav nav-tabs mb-4" id="settingsTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="password-tab" data-bs-toggle="tab" data-bs-target="#password" type="button">
                                    <i class="fas fa-key me-2"></i> Change Password
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button">
                                    <i class="fas fa-user me-2"></i> Profile
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="system-tab" data-bs-toggle="tab" data-bs-target="#system" type="button">
                                    <i class="fas fa-desktop me-2"></i> System Settings
                                </button>
                            </li>
                        </ul>
                        
                        <!-- Tabs Content -->
                        <div class="tab-content" id="settingsTabContent">
                            <!-- Change Password Tab -->
                            <div class="tab-pane fade show active" id="password" role="tabpanel">
                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label for="current_password" class="form-label">
                                            <i class="fas fa-lock me-2"></i>Current Password
                                        </label>
                                        <input type="password" 
                                               class="form-control" 
                                               id="current_password" 
                                               name="current_password"
                                               required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="new_password" class="form-label">
                                            <i class="fas fa-key me-2"></i>New Password
                                        </label>
                                        <input type="password" 
                                               class="form-control" 
                                               id="new_password" 
                                               name="new_password"
                                               required>
                                        <div class="form-text">Password must be at least 6 characters long</div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="confirm_password" class="form-label">
                                            <i class="fas fa-key me-2"></i>Confirm New Password
                                        </label>
                                        <input type="password" 
                                               class="form-control" 
                                               id="confirm_password" 
                                               name="confirm_password"
                                               required>
                                    </div>
                                    
                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                        <button type="submit" name="change_password" class="btn btn-primary">
                                            <i class="fas fa-save me-1"></i> Change Password
                                        </button>
                                    </div>
                                </form>
                            </div>
                            
                            <!-- Profile Tab -->
                            <div class="tab-pane fade" id="profile" role="tabpanel">
                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label class="form-label">Username</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username'] ?? $_SESSION['username']); ?>" readonly>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Full Name</label>
                                        <input type="text" class="form-control" name="full_name" 
                                               value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Email</label>
                                        <input type="email" class="form-control" name="email" 
                                               value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Phone</label>
                                        <input type="text" class="form-control" name="phone" 
                                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Role</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars(ucfirst($user['role'] ?? 'cashier')); ?>" readonly>
                                    </div>
                                    
                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                        <button type="submit" name="update_profile" class="btn btn-primary">
                                            <i class="fas fa-save me-1"></i> Update Profile
                                        </button>
                                    </div>
                                </form>
                            </div>
                            
                            <!-- System Settings Tab -->
                            <div class="tab-pane fade" id="system" role="tabpanel">
                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label class="form-label">Store Name</label>
                                        <input type="text" class="form-control" name="store_name" 
                                               value="<?php echo htmlspecialchars($settings['store_name'] ?? 'Grocery Store POS'); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Store Address</label>
                                        <textarea class="form-control" name="store_address" rows="2"><?php echo htmlspecialchars($settings['store_address'] ?? ''); ?></textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Store Phone</label>
                                        <input type="text" class="form-control" name="store_phone" 
                                               value="<?php echo htmlspecialchars($settings['store_phone'] ?? ''); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Store Email</label>
                                        <input type="email" class="form-control" name="store_email" 
                                               value="<?php echo htmlspecialchars($settings['store_email'] ?? ''); ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Tax Rate (%)</label>
                                        <input type="number" class="form-control" name="tax_rate" 
                                               value="<?php echo htmlspecialchars($settings['tax_rate'] ?? '8.5'); ?>" 
                                               step="0.1" min="0" max="100">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Currency</label>
                                        <select class="form-select" name="currency">
                                            <option value="USD" <?php echo ($settings['currency'] ?? 'USD') == 'USD' ? 'selected' : ''; ?>>USD ($)</option>
                                            <option value="EUR" <?php echo ($settings['currency'] ?? 'USD') == 'EUR' ? 'selected' : ''; ?>>EUR (€)</option>
                                            <option value="GBP" <?php echo ($settings['currency'] ?? 'USD') == 'GBP' ? 'selected' : ''; ?>>GBP (£)</option>
                                            <option value="INR" <?php echo ($settings['currency'] ?? 'USD') == 'INR' ? 'selected' : ''; ?>>INR (₹)</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Receipt Footer Message</label>
                                        <textarea class="form-control" name="receipt_footer" rows="3"><?php echo htmlspecialchars($settings['receipt_footer'] ?? 'Thank you for shopping with us!'); ?></textarea>
                                    </div>
                                    
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="checkbox" name="auto_print" id="autoPrint" 
                                               <?php echo ($settings['auto_print'] ?? '1') == '1' ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="autoPrint">
                                            Auto-print receipt after sale
                                        </label>
                                    </div>
                                    
                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                        <button type="submit" name="save_settings" class="btn btn-primary">
                                            <i class="fas fa-save me-1"></i> Save Settings
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Keep selected tab active on page refresh
        document.addEventListener('DOMContentLoaded', function() {
            // Check for saved tab in localStorage
            const activeTab = localStorage.getItem('activeSettingsTab');
            if (activeTab) {
                const tab = document.querySelector(`button[data-bs-target="${activeTab}"]`);
                if (tab) {
                    new bootstrap.Tab(tab).show();
                }
            }
            
            // Save tab on click
            document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(tab => {
                tab.addEventListener('click', function() {
                    localStorage.setItem('activeSettingsTab', this.getAttribute('data-bs-target'));
                });
            });
        });
    </script>
</body>
</html>