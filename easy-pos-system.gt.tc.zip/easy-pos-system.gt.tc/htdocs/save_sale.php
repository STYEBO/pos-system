<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// Get system settings (tax rate) from database
$settings_query = "SELECT setting_key, setting_value FROM system_settings";
$settings_result = $conn->query($settings_query);
$system_settings = [];
while($row = $settings_result->fetch_assoc()) {
    $system_settings[$row['setting_key']] = $row['setting_value'];
}

// Get tax rate from settings (default 0.00 if not set)
$tax_rate_percent = isset($system_settings['tax_rate']) ? floatval($system_settings['tax_rate']) : 0.00;
$tax_rate_decimal = $tax_rate_percent / 100;

// Get currency settings
$currency = $system_settings['currency'] ?? 'USD';
$store_name = $system_settings['store_name'] ?? 'Grocery Store POS';

// Debug: Log the received data
error_log("Save sale request received - Store: " . $store_name . ", Tax Rate: " . $tax_rate_percent . "%");
$json = file_get_contents('php://input');
error_log("Raw JSON: " . $json);

$data = json_decode($json, true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
    exit;
}

// Recalculate tax based on system settings if needed
if (isset($data['subtotal'])) {
    $data['tax'] = $data['subtotal'] * $tax_rate_decimal;
    $data['total'] = $data['subtotal'] + $data['tax'];
    error_log("Recalculated tax: " . $data['tax'] . ", Total: " . $data['total']);
}

try {
    $conn->begin_transaction();
    
    // First, check what columns exist in sales table
    $columns_result = $conn->query("SHOW COLUMNS FROM sales");
    $sales_columns = [];
    while($row = $columns_result->fetch_assoc()) {
        $sales_columns[] = $row['Field'];
    }
    
    // Build dynamic INSERT query based on available columns
    $insert_fields = [];
    $insert_values = [];
    $param_types = "";
    $params = [];
    
    // Always include basic required fields
    $subtotal = $data['subtotal'] ?? 0;
    $tax = $data['tax'] ?? 0;
    $total = $data['total'] ?? 0;
    $payment_method = $data['payment_method'] ?? 'cash';
    $change_amount = $data['change'] ?? 0;
    $cashier = $data['cashier'] ?? $_SESSION['username'] ?? 'Unknown';
    
    // Check and add each column if it exists
    if (in_array('cashier', $sales_columns)) {
        $insert_fields[] = 'cashier';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $cashier;
    }
    
    if (in_array('store_name', $sales_columns)) {
        $insert_fields[] = 'store_name';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $store_name;
    }
    
    if (in_array('tax_rate', $sales_columns)) {
        $insert_fields[] = 'tax_rate';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $tax_rate_percent;
    }
    
    if (in_array('currency', $sales_columns)) {
        $insert_fields[] = 'currency';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $currency;
    }
    
    if (in_array('subtotal', $sales_columns)) {
        $insert_fields[] = 'subtotal';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $subtotal;
    }
    
    if (in_array('tax_amount', $sales_columns)) {
        $insert_fields[] = 'tax_amount';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $tax;
    }
    
    if (in_array('total_amount', $sales_columns)) {
        $insert_fields[] = 'total_amount';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $total;
    }
    
    if (in_array('payment_method', $sales_columns)) {
        $insert_fields[] = 'payment_method';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $payment_method;
    }
    
    if (in_array('customer_name', $sales_columns)) {
        $insert_fields[] = 'customer_name';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $data['customer_name'] ?? '';
    }
    
    if (in_array('customer_phone', $sales_columns)) {
        $insert_fields[] = 'customer_phone';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $data['customer_phone'] ?? '';
    }
    
    if (in_array('notes', $sales_columns)) {
        $insert_fields[] = 'notes';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $data['notes'] ?? '';
    }
    
    if (in_array('change_amount', $sales_columns)) {
        $insert_fields[] = 'change_amount';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $change_amount;
    }
    
    // Add timestamp if column exists
    if (in_array('sale_date', $sales_columns) || in_array('created_at', $sales_columns)) {
        $col_name = in_array('sale_date', $sales_columns) ? 'sale_date' : 'created_at';
        $insert_fields[] = $col_name;
        $insert_values[] = 'NOW()';
    }
    
    // Build and execute the query
    $query = "INSERT INTO sales (" . implode(', ', $insert_fields) . ") 
              VALUES (" . implode(', ', $insert_values) . ")";
    
    error_log("Executing query: " . $query);
    
    $stmt = $conn->prepare($query);
    
    if (!empty($params)) {
        $stmt->bind_param($param_types, ...$params);
    }
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to save sale: ' . $stmt->error);
    }
    
    $sale_id = $conn->insert_id;
    
    // Insert sale items
    if (isset($data['items']) && is_array($data['items'])) {
        $item_query = "INSERT INTO sale_items (sale_id, product_id, product_name, 
                      quantity, unit_price, total_price) 
                      VALUES (?, ?, ?, ?, ?, ?)";
        $item_stmt = $conn->prepare($item_query);
        
        foreach($data['items'] as $item) {
            $product_id = $item['id'] ?? 0;
            $product_name = $item['name'] ?? 'Unknown Product';
            $quantity = $item['quantity'] ?? 1;
            $unit_price = $item['price'] ?? 0;
            $total_price = $quantity * $unit_price;
            
            $item_stmt->bind_param("iisddd", 
                $sale_id,
                $product_id,
                $product_name,
                $quantity,
                $unit_price,
                $total_price
            );
            
            if (!$item_stmt->execute()) {
                throw new Exception('Failed to save sale item: ' . $item_stmt->error);
            }
            
            // Update product stock
            $update_query = "UPDATE products SET quantity = quantity - ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("ii", $quantity, $product_id);
            
            if (!$update_stmt->execute()) {
                throw new Exception('Failed to update stock: ' . $update_stmt->error);
            }
            $update_stmt->close();
        }
        $item_stmt->close();
    }
    
    $conn->commit();
    
    // Return additional info for receipt
    echo json_encode([
        'success' => true, 
        'sale_id' => $sale_id,
        'store_name' => $store_name,
        'tax_rate' => $tax_rate_percent,
        'currency' => $currency
    ]);
    
} catch(Exception $e) {
    if (isset($conn)) {
        $conn->rollback();
    }
    error_log("Error in save_sale.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>