<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// Get system settings
$settings_query = "SELECT setting_key, setting_value FROM system_settings";
$settings_result = $conn->query($settings_query);
$system_settings = [];
while($row = $settings_result->fetch_assoc()) {
    $system_settings[$row['setting_key']] = $row['setting_value'];
}

// Get tax rate from settings
$tax_rate_percent = isset($system_settings['tax_rate']) ? floatval($system_settings['tax_rate']) : 0.00;
$tax_rate_decimal = $tax_rate_percent / 100;

// Get other settings
$currency = $system_settings['currency'] ?? 'USD';
$store_name = $system_settings['store_name'] ?? 'Grocery Store POS';

// Get the JSON data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data || !is_array($data)) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
    exit;
}

// Validate and calculate totals
$subtotal = floatval($data['subtotal'] ?? 0);
$tax = floatval($data['tax'] ?? 0);
$total = floatval($data['total'] ?? 0);

// Recalculate if necessary
if ($tax == 0 || $total == 0) {
    $tax = $subtotal * $tax_rate_decimal;
    $total = $subtotal + $tax;
}

// Validate required data
if ($subtotal <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid subtotal amount']);
    exit;
}

try {
    $conn->begin_transaction();
    
    // Check sales table columns
    $columns_result = $conn->query("SHOW COLUMNS FROM sales");
    $sales_columns = [];
    while($row = $columns_result->fetch_assoc()) {
        $sales_columns[] = $row['Field'];
    }
    
    // Prepare sale data
    $payment_method = $data['payment_method'] ?? 'cash';
    $change_amount = floatval($data['change'] ?? 0);
    $cashier = $data['cashier'] ?? $_SESSION['username'] ?? 'Unknown';
    $customer_name = $data['customer_name'] ?? '';
    $customer_phone = $data['customer_phone'] ?? '';
    $notes = $data['notes'] ?? '';
    
    // Build INSERT query based on available columns
    $insert_fields = [];
    $insert_values = [];
    $param_types = "";
    $params = [];
    
    // Add basic fields
    if (in_array('cashier', $sales_columns)) {
        $insert_fields[] = 'cashier';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $cashier;
    }
    
    if (in_array('store_name', $sales_columns)) {
        $insert_fields[] = 'store_name';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $store_name;
    }
    
    if (in_array('tax_rate', $sales_columns)) {
        $insert_fields[] = 'tax_rate';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $tax_rate_percent;
    }
    
    if (in_array('currency', $sales_columns)) {
        $insert_fields[] = 'currency';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $currency;
    }
    
    // Add totals - check for different column names
    if (in_array('subtotal', $sales_columns)) {
        $insert_fields[] = 'subtotal';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $subtotal;
    } elseif (in_array('subtotal_amount', $sales_columns)) {
        $insert_fields[] = 'subtotal_amount';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $subtotal;
    }
    
    if (in_array('tax', $sales_columns)) {
        $insert_fields[] = 'tax';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $tax;
    } elseif (in_array('tax_amount', $sales_columns)) {
        $insert_fields[] = 'tax_amount';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $tax;
    }
    
    if (in_array('total', $sales_columns)) {
        $insert_fields[] = 'total';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $total;
    } elseif (in_array('total_amount', $sales_columns)) {
        $insert_fields[] = 'total_amount';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $total;
    }
    
    // Add other fields
    if (in_array('payment_method', $sales_columns)) {
        $insert_fields[] = 'payment_method';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $payment_method;
    }
    
    if (in_array('customer_name', $sales_columns)) {
        $insert_fields[] = 'customer_name';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $customer_name;
    }
    
    if (in_array('customer_phone', $sales_columns)) {
        $insert_fields[] = 'customer_phone';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $customer_phone;
    }
    
    if (in_array('notes', $sales_columns)) {
        $insert_fields[] = 'notes';
        $insert_values[] = '?';
        $param_types .= "s";
        $params[] = $notes;
    }
    
    if (in_array('change_amount', $sales_columns)) {
        $insert_fields[] = 'change_amount';
        $insert_values[] = '?';
        $param_types .= "d";
        $params[] = $change_amount;
    }
    
    // Add timestamp
    $timestamp_col = '';
    if (in_array('sale_date', $sales_columns)) {
        $timestamp_col = 'sale_date';
    } elseif (in_array('created_at', $sales_columns)) {
        $timestamp_col = 'created_at';
    }
    
    if ($timestamp_col) {
        $insert_fields[] = $timestamp_col;
        $insert_values[] = 'NOW()';
    }
    
    // Build and execute query
    $query = "INSERT INTO sales (" . implode(', ', $insert_fields) . ") 
              VALUES (" . implode(', ', $insert_values) . ")";
    
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        throw new Exception('Failed to prepare statement: ' . $conn->error);
    }
    
    if (!empty($params)) {
        $stmt->bind_param($param_types, ...$params);
    }
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to save sale: ' . $stmt->error);
    }
    
    $sale_id = $conn->insert_id;
    
    // Insert sale items
    if (isset($data['items']) && is_array($data['items']) && count($data['items']) > 0) {
        $item_query = "INSERT INTO sale_items (sale_id, product_id, product_name, 
                      quantity, unit_price, total_price) 
                      VALUES (?, ?, ?, ?, ?, ?)";
        $item_stmt = $conn->prepare($item_query);
        
        if (!$item_stmt) {
            throw new Exception('Failed to prepare item statement: ' . $conn->error);
        }
        
        foreach($data['items'] as $item) {
            $product_id = intval($item['id'] ?? 0);
            $product_name = $item['name'] ?? 'Unknown Product';
            $quantity = floatval($item['quantity'] ?? 1);
            $unit_price = floatval($item['price'] ?? 0);
            $total_price = $quantity * $unit_price;
            
            $item_stmt->bind_param("iisddd", 
                $sale_id,
                $product_id,
                $product_name,
                $quantity,
                $unit_price,
                $total_price
            );
            
            if (!$item_stmt->execute()) {
                throw new Exception('Failed to save sale item: ' . $item_stmt->error);
            }
            
            // Update product stock for piece items
            $unit = $item['unit'] ?? 'pcs';
            $piece_units = ['pcs', 'piece', 'unit', 'pack', 'box', 'bottle', 'unidade'];
            if (in_array(strtolower($unit), $piece_units)) {
                $update_query = "UPDATE products SET quantity = quantity - ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_query);
                if ($update_stmt) {
                    $update_stmt->bind_param("di", $quantity, $product_id);
                    $update_stmt->execute();
                    $update_stmt->close();
                }
            }
        }
        $item_stmt->close();
    }
    
    $conn->commit();
    
    // Generate receipt number
    $receipt_number = 'REC' . str_pad($sale_id, 6, '0', STR_PAD_LEFT);
    
    echo json_encode([
        'success' => true, 
        'sale_id' => $sale_id,
        'receipt_number' => $receipt_number,
        'store_name' => $store_name,
        'tax_rate' => $tax_rate_percent,
        'currency' => $currency,
        'subtotal' => $subtotal,
        'tax' => $tax,
        'total' => $total,
        'message' => 'Sale saved successfully'
    ]);
    
} catch(Exception $e) {
    $conn->rollback();
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>