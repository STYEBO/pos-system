<?php
include 'auth.php';
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Database Backup Panel</title>

<style>
body{
    font-family: Arial, sans-serif;
    background:#f4f6f9;
}
.container{
    width:800px;
    margin:40px auto;
    background:#fff;
    padding:25px;
    border-radius:8px;
    box-shadow:0 0 10px rgba(0,0,0,.1);
}
h2{
    text-align:center;
    margin-bottom:30px;
}
.card{
    border:1px solid #ddd;
    padding:20px;
    margin-bottom:20px;
    border-radius:6px;
}
.card h3{
    margin-top:0;
}
button{
    background:#007bff;
    color:#fff;
    border:none;
    padding:10px 18px;
    border-radius:4px;
    cursor:pointer;
}
button:hover{
    background:#0056b3;
}
input[type=file], select{
    padding:8px;
    width:100%;
    margin-bottom:10px;
}
.footer{
    text-align:center;
    color:#888;
    font-size:13px;
}
</style>
</head>

<body>

<div class="container">
    <h2>🔐 Database Backup & Restore Panel</h2>
    <!-- EXPORT FULL DATABASE -->
    <div class="card">
        <h3>📤 Export Full Database</h3>
        <a href="export_db.php">
            <button>Download Full Backup</button>
        </a>
    </div>

    <!-- EXPORT SINGLE TABLE -->
    <div class="card">
        <h3>📂 Export Specific Table</h3>
        <form method="post" action="export_table.php">
            <select name="table" required>
                <?php
                $tables = $conn->query("SHOW TABLES");
                while ($t = $tables->fetch_array()) {
                    echo "<option value='$t[0]'>$t[0]</option>";
                }
                ?>
            </select>
            <button name="export">Export Table</button>
        </form>
    </div>

    <!-- IMPORT DATABASE -->
    <div class="card">
        <h3>📥 Import Database (.sql)</h3>
        <form method="post" action="import_db.php" enctype="multipart/form-data">
            <input type="file" name="sql_file" accept=".sql" required>
            <button name="import">Import Database</button>
        </form>
    </div>

    <!-- AUTO BACKUP -->
    <div class="card">
        <h3>⏰ Auto Backup</h3>
        <a href="auto_backup.php">
            <button>Run Backup Now</button>
        </a>
        <p style="font-size:13px;color:#555">Daily / Weekly backup ke liye use karo</p>
    </div>
 <!-- LOGOUT BUTTON -->
    <div class="card" style="text-align:center;">
        <h3>🚪 Logout</h3>
        <a href="logout_back_panel.php">
            <button style="background:#dc3545;">Logout</button>
        </a>
    </div>
    <div class="footer">
        Backup System • PHP Based • Secure
    </div>
</div>

</body>
</html>
