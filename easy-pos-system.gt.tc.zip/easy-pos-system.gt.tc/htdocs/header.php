<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

// Get user role from database
$username = $_SESSION['username'];
$query = "SELECT role FROM users WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_data = $result->fetch_assoc();
    $user_role = $user_data['role'];
    $_SESSION['role'] = $user_role;
} else {
    $user_role = 'cashier';
    $_SESSION['role'] = $user_role;
}

// NEW: Restrict cashier from accessing settings
if ($user_role === 'cashier' && basename($_SERVER['PHP_SELF']) === 'settings.php') {
    header("Location: dashboard.php");
    exit;
}
$stmt->close();

// Get categories for dropdown if needed
$categories = [];
if (isset($need_categories) && $need_categories) {
    $cat_result = $conn->query("SELECT id, name FROM categories ORDER BY name");
    if ($cat_result->num_rows > 0) {
        while($row = $cat_result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'POS System'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        :root {
            --header-bg: #001f3f;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
            --admin-color: #28a745;
            --cashier-color: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Top Header Bar */
        .admin-header {
            background: var(--header-bg);
            color: white;
            padding: 8px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: relative;
            z-index: 1000;
        }
        
        .admin-header-left {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-shrink: 0;
            min-width: 200px;
        }
        
        .admin-header-center {
            flex: 1;
            text-align: center;
            min-width: 300px;
            padding: 0 10px;
        }
        
        .admin-header-right {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .store-title {
            font-size: 20px;
            font-weight: 700;
            color: white;
            display: flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }
        
        .time-display-large {
            font-size: 14px;
            font-weight: 500;
            color: #fff;
            background: rgba(255,255,255,0.1);
            padding: 6px 15px;
            border-radius: 4px;
            display: inline-block;
            white-space: nowrap;
        }
        
        .header-btn {
            background: rgba(255,255,255,0.1);
            border: none;
            color: white;
            padding: 5px 12px;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            white-space: nowrap;
            height: 32px;
        }
        
        .header-btn:hover {
            background: rgba(255,255,255,0.2);
        }
        
        .role-badge {
            background: <?php echo $user_role == 'admin' ? 'var(--admin-color)' : 'var(--cashier-color)'; ?>;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
            white-space: nowrap;
            height: 32px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .screen-controls {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .control-buttons {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        /* Admin Menu (Right Side) */
        .admin-menu {
            background: white;
            border-radius: 8px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            position: absolute;
            top: calc(100% + 5px);
            right: 0;
            z-index: 1000;
            min-width: 250px;
            display: none;
            animation: fadeIn 0.2s ease;
        }
        
        .admin-menu.show {
            display: block;
        }
        
        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.2s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .menu-item:hover {
            background: #f8f9fa;
        }
        
        .menu-item.active {
            background: #f8f9fa;
            border-left: 3px solid #28a745;
        }
        
        .menu-item:last-child {
            border-bottom: none;
        }
        
        .menu-icon {
            width: 20px;
            color: #007bff;
        }
        
        /* Notification Styles */
        .notification {
            position: fixed;
            top: 70px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 9999;
            animation: slideIn 0.3s ease;
            color: white;
            font-weight: 500;
        }
        
        .notification.success {
            background: #28a745;
        }
        
        .notification.warning {
            background: #ffc107;
            color: #212529;
        }
        
        .notification.error {
            background: #dc3545;
        }
        
        .notification.info {
            background: #17a2b8;
        }
        
        /* Windows Activation Bar */
        .windows-bar {
            background: #0078d4;
            color: white;
            padding: 5px 15px;
            font-size: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 1000;
        }
        
        .windows-bar a {
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .windows-bar a:hover {
            text-decoration: underline;
            opacity: 0.8;
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        /* Responsive Styles */
        @media (max-width: 1200px) {
            .admin-header {
                flex-wrap: wrap;
                padding: 8px 15px;
            }
            
            .admin-header-left,
            .admin-header-center,
            .admin-header-right {
                min-width: auto;
                flex: 1;
                justify-content: center;
            }
            
            .admin-header-center {
                order: 3;
                flex-basis: 100%;
                margin-top: 8px;
            }
            
            .store-title {
                font-size: 18px;
            }
            
            .time-display-large {
                font-size: 13px;
                padding: 5px 10px;
            }
        }
        
        @media (max-width: 768px) {
            .admin-header {
                flex-direction: column;
                gap: 8px;
                padding: 8px 10px;
            }
            
            .admin-header-left,
            .admin-header-center,
            .admin-header-right {
                width: 100%;
                justify-content: center;
                text-align: center;
            }
            
            .admin-header-center {
                order: 1;
                margin-top: 0;
            }
            
            .admin-header-left {
                order: 2;
            }
            
            .admin-header-right {
                order: 3;
            }
            
            .screen-controls {
                justify-content: center;
            }
            
            .header-btn {
                padding: 4px 10px;
                font-size: 12px;
            }
            
            .store-title {
                font-size: 16px;
                justify-content: center;
            }
            
            .time-display-large {
                font-size: 12px;
                padding: 4px 8px;
            }
        }
        
        @media (max-width: 480px) {
            .screen-controls {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .control-buttons {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .header-btn span {
                display: none;
            }
            
            .header-btn i {
                margin-right: 0;
            }
            
            .role-badge {
                padding: 4px 8px;
                font-size: 10px;
            }
            
            .store-title span {
                display: none;
            }
            
            .store-title i {
                margin-right: 0;
            }
            
            .admin-menu {
                min-width: 200px;
            }
        }
        
        /* Main Content Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            background: white;
        }
        
        .card-header {
            background: var(--header-bg);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .btn-success {
            background: #28a745;
            border: none;
            padding: 10px 25px;
            font-weight: 600;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40,167,69,0.3);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 0.25rem rgba(40,167,69,.25);
        }
        
        /* User Info Styles */
        .role-badge {
            background: <?php echo $user_role == 'admin' ? 'var(--admin-color)' : 'var(--cashier-color)'; ?>;
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        /* Form Styles */
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            padding: 10px 15px;
            border-radius: 6px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }
        
        .form-control:hover, .form-select:hover {
            border-color: #28a745;
        }
        
        /* Alert Styles */
        .alert {
            border-radius: 8px;
            border: none;
            padding: 15px 20px;
            animation: slideDown 0.3s ease;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <!-- Top Header Bar -->
    <div class="admin-header">
        <div class="admin-header-left">
            <div class="store-title">
                <i class="fas fa-store"></i>
                <span>Easy Pos (<?php echo htmlspecialchars(ucfirst($user_role)); ?>)</span>
            </div>
        </div>
        
        <div class="admin-header-center">
            <div class="time-display-large" id="currentTime">Loading...</div>
        </div>
        
        <div class="admin-header-right">
            <!-- Control buttons -->
            <div class="screen-controls">
                <button class="header-btn" onclick="toggleFullscreen()">
                    <i class="fas fa-expand"></i>
                    <span>Full Screen</span>
                </button>
            </div>
            
            <!-- User Menu -->
            <div class="control-buttons">
                <!-- Role Badge -->
                <div class="role-badge">
                    <i class="fas <?php echo $user_role == 'admin' ? 'fa-user-shield' : 'fa-user'; ?>"></i>
                    <span><?php echo strtoupper($user_role); ?></span>
                </div>
                
                <!-- User Menu Button -->
                <div class="position-relative">
                    <button class="header-btn" onclick="toggleUserMenu()">
                        <i class="fas fa-user-circle"></i>
                        <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        <i class="fas fa-chevron-down ms-1"></i>
                    </button>
                    
                    <!-- User Menu Dropdown -->
                    <div class="admin-menu" id="userMenu">
                       <div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" onclick="location.href='dashboard.php'">
    <i class="fas fa-home menu-icon"></i>
    <small class="text-muted">Go to dashboard</small>
</div>

<div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'add_product.php' ? 'active' : ''; ?>" onclick="location.href='add_product.php'">
    <i class="fas fa-plus menu-icon"></i>
    <small class="text-muted">Add new products</small>
</div>

<div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'add_category.php' ? 'active' : ''; ?>" onclick="location.href='add_category.php'">
    <i class="fas fa-tag menu-icon"></i>
    <small class="text-muted">Create categories</small>
</div>

<div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'manage_products.php' ? 'active' : ''; ?>" onclick="location.href='manage_products.php'">
    <i class="fas fa-boxes menu-icon"></i>
    <small class="text-muted">Edit/Delete products</small>
</div>

<div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'manage_categories.php' ? 'active' : ''; ?>" onclick="location.href='manage_categories.php'">
    <i class="fas fa-tags menu-icon"></i>
    <small class="text-muted">Edit/Delete categories</small>
</div>

<div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>" onclick="location.href='reports.php'">
    <i class="fas fa-chart-bar menu-icon"></i>
    <small class="text-muted">View sales reports</small>
</div>

<!-- SETTINGS -->
<div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>" onclick="location.href='settings.php'">
    <i class="fas fa-sliders-h menu-icon"></i>
    <small class="text-muted">System configuration</small>
</div>

<!-- 🔐 BACKUP PANEL -->
<div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'backup_panel.php' ? 'active' : ''; ?>" onclick="location.href='backup_panel.php'">
    <i class="fas fa-database menu-icon"></i>
    <small class="text-muted">Backup & Restore</small>
</div>

                        
                        <!-- Logout option (visible to all) -->
                        <div class="menu-item text-danger" onclick="logout()">
                            <i class="fas fa-sign-out-alt menu-icon"></i>
                            <div>
                                <div class="fw-bold">Logout</div>
                                <small class="text-muted">Exit system</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        // Global variables
        let isUserMenuOpen = false;
        let isFullscreen = false;

        // Initialize
        $(document).ready(function() {
            updateTime();
            setInterval(updateTime, 1000);
            
            // Close user menu when clicking outside
            $(document).on('click', function(event) {
                if (isUserMenuOpen && !$(event.target).closest('.control-buttons').length) {
                    hideUserMenu();
                }
            });
            
            // Handle keyboard shortcuts
            $(document).on('keydown', function(e) {
                // F11 for fullscreen
                if (e.key === 'F11') {
                    e.preventDefault();
                    toggleFullscreen();
                }
                
                // Escape to close menu
                if (e.key === 'Escape') {
                    if (isUserMenuOpen) {
                        hideUserMenu();
                    }
                }
            });
        });
        
        // Update time display
        function updateTime() {
            const now = new Date();
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: true
            };
            const timeString = now.toLocaleDateString('en-US', options);
            $('#currentTime').text(timeString);
        }
        
        // Toggle user menu
        function toggleUserMenu() {
            const menu = $('#userMenu');
            if (menu.hasClass('show')) {
                hideUserMenu();
            } else {
                menu.addClass('show');
                isUserMenuOpen = true;
            }
        }
        
        function hideUserMenu() {
            $('#userMenu').removeClass('show');
            isUserMenuOpen = false;
        }
        
        // Toggle fullscreen
        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(err => {
                    showNotification('Fullscreen not supported', 'warning');
                });
                isFullscreen = true;
                showNotification('Fullscreen mode enabled', 'success');
            } else {
                document.exitFullscreen();
                isFullscreen = false;
                showNotification('Fullscreen mode disabled', 'info');
            }
        }
        
        // Logout function
        function logout() {
            Swal.fire({
                title: 'Logout?',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, logout!',
                cancelButtonText: 'Cancel',
                backdrop: true,
                allowOutsideClick: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        }
        
        // Activate Windows function
        function activateWindows() {
            Swal.fire({
                title: 'Activate Windows',
                text: 'This feature is for demonstration purposes only.',
                icon: 'info',
                confirmButtonText: 'OK',
                confirmButtonColor: '#0078d4'
            });
        }
        
        // Show notification
        function showNotification(message, type = 'info') {
            // Remove existing notifications
            $('.notification').remove();
            
            const icon = {
                'success': 'check-circle',
                'error': 'times-circle',
                'warning': 'exclamation-triangle',
                'info': 'info-circle'
            }[type] || 'info-circle';
            
            const notification = $(`
                <div class="notification ${type}">
                    <i class="fas fa-${icon} me-2"></i>
                    ${message}
                </div>
            `);
            
            $('body').append(notification);
            
            // Remove after 3 seconds
            setTimeout(() => {
                notification.css('animation', 'slideOut 0.3s ease');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 3000);
        }
        
        // Fullscreen change event listeners
        document.addEventListener('fullscreenchange', updateFullscreenState);
        document.addEventListener('webkitfullscreenchange', updateFullscreenState);
        document.addEventListener('mozfullscreenchange', updateFullscreenState);
        document.addEventListener('msfullscreenchange', updateFullscreenState);
        
        function updateFullscreenState() {
            isFullscreen = !!(document.fullscreenElement || 
                            document.webkitFullscreenElement || 
                            document.mozFullScreenElement || 
                            document.msFullscreenElement);
        }
    </script>