<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

// Get user role from database
$username = $_SESSION['username'];
$query = "SELECT role FROM users WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_data = $result->fetch_assoc();
    $user_role = $user_data['role'];
    $_SESSION['role'] = $user_role;
} else {
    $user_role = 'cashier';
    $_SESSION['role'] = $user_role;
}

// NEW: Restrict cashier from accessing settings
if ($user_role === 'cashier' && basename($_SERVER['PHP_SELF']) === 'settings.php') {
    header("Location: dashboard.php");
    exit;
}
$stmt->close();

// Get categories for dropdown if needed
$categories = [];
if (isset($need_categories) && $need_categories) {
    $cat_result = $conn->query("SELECT id, name FROM categories ORDER BY name");
    if ($cat_result->num_rows > 0) {
        while($row = $cat_result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'POS System'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        :root {
            --header-bg: #001f3f;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
            --admin-color: #28a745;
            --cashier-color: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Top Header Bar */
        .admin-header {
            background: var(--header-bg);
            color: white;
            padding: 8px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: relative;
            z-index: 1000;
        }
        
        .admin-header-left {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-shrink: 0;
            min-width: 200px;
        }
        
        .admin-header-center {
            flex: 1;
            text-align: center;
            min-width: 300px;
            padding: 0 10px;
        }
        
        .admin-header-right {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            min-width: 300px;
            justify-content: flex-end;
        }
        
        .store-title {
            font-size: 20px;
            font-weight: 700;
            color: white;
            display: flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }
        
        .time-display-large {
            font-size: 14px;
            font-weight: 500;
            color: #fff;
            background: rgba(255,255,255,0.1);
            padding: 6px 15px;
            border-radius: 4px;
            display: inline-block;
            white-space: nowrap;
        }
        
        .header-btn {
            background: rgba(255,255,255,0.1);
            border: none;
            color: white;
            padding: 5px 12px;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            white-space: nowrap;
            height: 32px;
        }
        
        .header-btn:hover {
            background: rgba(255,255,255,0.2);
        }
        
        .role-badge {
            background: <?php echo $user_role == 'admin' ? 'var(--admin-color)' : 'var(--cashier-color)'; ?>;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
            white-space: nowrap;
            height: 32px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .screen-controls {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .control-buttons {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        /* Admin Menu (Right Side) */
        .admin-menu {
            background: white;
            border-radius: 8px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            position: absolute;
            top: calc(100% + 5px);
            right: 0;
            z-index: 1000;
            min-width: 250px;
            display: none;
            animation: fadeIn 0.2s ease;
        }
        
        .admin-menu.show {
            display: block;
        }
        
        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.2s;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .menu-item:hover {
            background: #f8f9fa;
        }
        
        .menu-item.active {
            background: #f8f9fa;
            border-left: 3px solid #28a745;
        }
        
        .menu-item:last-child {
            border-bottom: none;
        }
        
        .menu-icon {
            width: 20px;
            color: #007bff;
        }
        
        /* Virtual Keyboard Styles */
        .keyboard-container {
            background: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.2);
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1060;
            border: 1px solid #dee2e6;
            display: none;
            animation: slideUp 0.3s ease;
        }
        
        .keyboard-container.show {
            display: block;
        }
        
        .keyboard-row {
            display: flex;
            justify-content: center;
            margin-bottom: 8px;
            gap: 5px;
        }
        
        .keyboard-key {
            min-width: 45px;
            height: 45px;
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: 500;
            user-select: none;
            font-size: 14px;
        }
        
        .keyboard-key:hover {
            background: #e9ecef;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .keyboard-key:active {
            background: #dee2e6;
            transform: translateY(0);
        }
        
        .keyboard-key.special {
            background: #007bff;
            color: white;
            min-width: 80px;
            border-color: #0056b3;
        }
        
        .keyboard-key.space {
            min-width: 250px;
        }
        
        .keyboard-key.backspace {
            min-width: 90px;
        }
        
        .keyboard-key.active {
            background: #28a745;
            color: white;
            border-color: #1e7e34;
        }
        
        /* Notification Styles */
        .notification {
            position: fixed;
            top: 70px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 9999;
            animation: slideIn 0.3s ease;
            color: white;
            font-weight: 500;
        }
        
        .notification.success {
            background: #28a745;
        }
        
        .notification.warning {
            background: #ffc107;
            color: #212529;
        }
        
        .notification.error {
            background: #dc3545;
        }
        
        .notification.info {
            background: #17a2b8;
        }
        
        /* Windows Activation Bar */
        .windows-bar {
            background: #0078d4;
            color: white;
            padding: 5px 15px;
            font-size: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 1000;
        }
        
        .windows-bar a {
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .windows-bar a:hover {
            text-decoration: underline;
            opacity: 0.8;
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        /* Responsive Styles */
        @media (max-width: 1200px) {
            .admin-header {
                flex-wrap: wrap;
                padding: 8px 15px;
            }
            
            .admin-header-left,
            .admin-header-center,
            .admin-header-right {
                min-width: auto;
                flex: 1;
                justify-content: center;
            }
            
            .admin-header-center {
                order: 3;
                flex-basis: 100%;
                margin-top: 8px;
            }
            
            .store-title {
                font-size: 18px;
            }
            
            .time-display-large {
                font-size: 13px;
                padding: 5px 10px;
            }
        }
        
        @media (max-width: 768px) {
            .admin-header {
                flex-direction: column;
                gap: 8px;
                padding: 8px 10px;
            }
            
            .admin-header-left,
            .admin-header-center,
            .admin-header-right {
                width: 100%;
                justify-content: center;
                text-align: center;
            }
            
            .admin-header-center {
                order: 1;
                margin-top: 0;
            }
            
            .admin-header-left {
                order: 2;
            }
            
            .admin-header-right {
                order: 3;
            }
            
            .screen-controls {
                justify-content: center;
            }
            
            .header-btn {
                padding: 4px 10px;
                font-size: 12px;
            }
            
            .store-title {
                font-size: 16px;
                justify-content: center;
            }
            
            .time-display-large {
                font-size: 12px;
                padding: 4px 8px;
            }
            
            .keyboard-container {
                bottom: 10px;
                right: 10px;
                left: 10px;
                padding: 10px;
            }
            
            .keyboard-key {
                min-width: 35px;
                height: 35px;
                font-size: 12px;
            }
            
            .keyboard-key.special {
                min-width: 60px;
            }
            
            .keyboard-key.space {
                min-width: 200px;
            }
            
            .keyboard-key.backspace {
                min-width: 70px;
            }
        }
        
        @media (max-width: 480px) {
            .screen-controls {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .control-buttons {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .header-btn span {
                display: none;
            }
            
            .header-btn i {
                margin-right: 0;
            }
            
            .role-badge {
                padding: 4px 8px;
                font-size: 10px;
            }
            
            .store-title span {
                display: none;
            }
            
            .store-title i {
                margin-right: 0;
            }
            
            .admin-menu {
                min-width: 200px;
            }
            
            .keyboard-key {
                min-width: 30px;
                height: 30px;
                font-size: 11px;
            }
            
            .keyboard-key.special {
                min-width: 50px;
            }
            
            .keyboard-key.space {
                min-width: 150px;
            }
            
            .keyboard-key.backspace {
                min-width: 60px;
            }
        }
        
        /* Main Content Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            background: white;
        }
        
        .card-header {
            background: var(--header-bg);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .btn-success {
            background: #28a745;
            border: none;
            padding: 10px 25px;
            font-weight: 600;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40,167,69,0.3);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 0.25rem rgba(40,167,69,.25);
        }
        
        /* User Info Styles */
        .role-badge {
            background: <?php echo $user_role == 'admin' ? 'var(--admin-color)' : 'var(--cashier-color)'; ?>;
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        
        /* Form Styles */
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            padding: 10px 15px;
            border-radius: 6px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }
        
        .form-control:hover, .form-select:hover {
            border-color: #28a745;
        }
        
        /* Alert Styles */
        .alert {
            border-radius: 8px;
            border: none;
            padding: 15px 20px;
            animation: slideDown 0.3s ease;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <!-- Top Header Bar -->
    <div class="admin-header">
        <div class="admin-header-left">
            <div class="store-title">
                <i class="fas fa-store"></i>
                <span>Easy Pos (<?php echo htmlspecialchars(ucfirst($user_role)); ?>)</span>
            </div>
        </div>
        
        <div class="admin-header-center">
            <div class="time-display-large" id="currentTime">Loading...</div>
        </div>
        
        <div class="admin-header-right">
            <!-- Control buttons -->
            <div class="screen-controls">
                <button class="header-btn" onclick="toggleKeyboard()">
                    <i class="fas fa-keyboard"></i>
                    <span>Keyboard</span>
                </button>
                <button class="header-btn" onclick="toggleFullscreen()">
                    <i class="fas fa-expand"></i>
                    <span>Full Screen</span>
                </button>
            </div>
            
            <!-- User Menu -->
            <div class="control-buttons">
                <!-- Role Badge -->
                <div class="role-badge">
                    <i class="fas <?php echo $user_role == 'admin' ? 'fa-user-shield' : 'fa-user'; ?>"></i>
                    <span><?php echo strtoupper($user_role); ?></span>
                </div>
                
                <!-- User Menu Button -->
                <div class="position-relative">
                    <button class="header-btn" onclick="toggleUserMenu()">
                        <i class="fas fa-user-circle"></i>
                        <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        <i class="fas fa-chevron-down ms-1"></i>
                    </button>
                    
                    <!-- User Menu Dropdown -->
                    <div class="admin-menu" id="userMenu">
                        <div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" onclick="window.location.href='dashboard.php'">
                            <i class="fas fa-home menu-icon"></i>
                            <div>
                                <div class="fw-bold">Dashboard</div>
                                <small class="text-muted">Go to dashboard</small>
                            </div>
                        </div>
                        
                        <?php if ($user_role == 'admin'): ?>
                        <div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'add_product.php' ? 'active' : ''; ?>" onclick="window.location.href='add_product.php'">
                            <i class="fas fa-plus menu-icon"></i>
                            <div>
                                <div class="fw-bold">Add Product</div>
                                <small class="text-muted">Add new products</small>
                            </div>
                        </div>
                        <div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'add_category.php' ? 'active' : ''; ?>" onclick="window.location.href='add_category.php'">
                            <i class="fas fa-tag menu-icon"></i>
                            <div>
                                <div class="fw-bold">Add Category</div>
                                <small class="text-muted">Create categories</small>
                            </div>
                        </div>
                        <div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'manage_products.php' ? 'active' : ''; ?>" onclick="window.location.href='manage_products.php'">
                            <i class="fas fa-boxes menu-icon"></i>
                            <div>
                                <div class="fw-bold">Manage Products</div>
                                <small class="text-muted">Edit/Delete products</small>
                            </div>
                        </div>
                        <div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'manage_categories.php' ? 'active' : ''; ?>" onclick="window.location.href='manage_categories.php'">
                            <i class="fas fa-tags menu-icon"></i>
                            <div>
                                <div class="fw-bold">Manage Categories</div>
                                <small class="text-muted">Edit/Delete categories</small>
                            </div>
                        </div>
                        <div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>" onclick="window.location.href='reports.php'">
                            <i class="fas fa-chart-bar menu-icon"></i>
                            <div>
                                <div class="fw-bold">Reports</div>
                                <small class="text-muted">View sales reports</small>
                            </div>
                        </div>
                        <!-- Admin-only Settings Menu -->
                        <div class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>" onclick="window.location.href='settings.php'">
                            <i class="fas fa-sliders-h menu-icon"></i>
                            <div>
                                <div class="fw-bold">Settings</div>
                                <small class="text-muted">System configuration</small>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Logout option (visible to all) -->
                        <div class="menu-item text-danger" onclick="logout()">
                            <i class="fas fa-sign-out-alt menu-icon"></i>
                            <div>
                                <div class="fw-bold">Logout</div>
                                <small class="text-muted">Exit system</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Virtual Keyboard -->
    <div id="virtualKeyboard" class="keyboard-container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="mb-0">
                <i class="fas fa-keyboard me-2"></i> Virtual Keyboard
            </h6>
            <div>
                <button type="button" class="btn btn-sm btn-outline-primary me-2" onclick="toggleCapsLock()" id="capsLockBtn">
                    <i class="fas fa-arrow-up"></i> Caps
                </button>
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="hideKeyboard()">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
        </div>
        <div id="keyboardContent"></div>
    </div>

    

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        // Global variables
        let isUserMenuOpen = false;
        let isFullscreen = false;
        let capsLock = false;
        let isKeyboardVisible = false;
        let shiftActive = false;
        let activeInput = null;

        // Initialize
        $(document).ready(function() {
            updateTime();
            setInterval(updateTime, 1000);
            createVirtualKeyboard();
            
            // Track active input
            $(document).on('focus', 'input, textarea', function() {
                activeInput = this;
            });
            
            $(document).on('blur', 'input, textarea', function() {
                if (activeInput === this) {
                    activeInput = null;
                }
            });
            
            // Close user menu when clicking outside
            $(document).on('click', function(event) {
                if (isUserMenuOpen && !$(event.target).closest('.control-buttons').length) {
                    hideUserMenu();
                }
                
                // Close keyboard when clicking outside
                if (isKeyboardVisible && 
                    !$(event.target).closest('#virtualKeyboard').length && 
                    !$(event.target).closest('.header-btn').length) {
                    hideKeyboard();
                }
            });
            
            // Handle keyboard shortcuts
            $(document).on('keydown', function(e) {
                // Ctrl+K to toggle keyboard
                if (e.ctrlKey && e.key === 'k') {
                    e.preventDefault();
                    toggleKeyboard();
                }
                
                // Escape to close keyboard or menu
                if (e.key === 'Escape') {
                    if (isKeyboardVisible) {
                        hideKeyboard();
                    }
                    if (isUserMenuOpen) {
                        hideUserMenu();
                    }
                }
                
                // F11 for fullscreen
                if (e.key === 'F11') {
                    e.preventDefault();
                    toggleFullscreen();
                }
            });
        });
        
        // Update time display
        function updateTime() {
            const now = new Date();
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: true
            };
            const timeString = now.toLocaleDateString('en-US', options);
            $('#currentTime').text(timeString);
        }
        
        // Toggle user menu
        function toggleUserMenu() {
            const menu = $('#userMenu');
            if (menu.hasClass('show')) {
                hideUserMenu();
            } else {
                menu.addClass('show');
                isUserMenuOpen = true;
            }
        }
        
        function hideUserMenu() {
            $('#userMenu').removeClass('show');
            isUserMenuOpen = false;
        }
        
        // Toggle virtual keyboard
        function toggleKeyboard() {
            const keyboard = $('#virtualKeyboard');
            if (isKeyboardVisible) {
                hideKeyboard();
            } else {
                keyboard.addClass('show');
                isKeyboardVisible = true;
                
                // If no input is focused, focus on first input
                if (!activeInput) {
                    const firstInput = $('input[type="text"], input[type="number"], textarea').first();
                    if (firstInput.length) {
                        firstInput.focus();
                        activeInput = firstInput[0];
                    }
                }
                
                showNotification('Virtual keyboard enabled', 'info');
            }
        }
        
        function hideKeyboard() {
            $('#virtualKeyboard').removeClass('show');
            isKeyboardVisible = false;
        }
        
        // Create virtual keyboard
        function createVirtualKeyboard() {
            const keyboardLayout = [
                ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'Backspace'],
                ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
                ['Caps', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'Enter'],
                ['Shift', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '?'],
                ['Space']
            ];

            let keyboardHTML = '';
            keyboardLayout.forEach(row => {
                keyboardHTML += '<div class="keyboard-row">';
                row.forEach(key => {
                    let className = 'keyboard-key';
                    let displayKey = key;
                    let dataKey = key.toLowerCase();
                    
                    if (key === 'Backspace' || key === 'Caps' || key === 'Enter' || key === 'Space' || key === 'Shift') {
                        className += ' special';
                        if (key === 'Space') {
                            className += ' space';
                            displayKey = 'Space';
                            dataKey = ' ';
                        }
                        if (key === 'Backspace') {
                            className += ' backspace';
                            displayKey = '⌫';
                        }
                        if (key === 'Enter') {
                            displayKey = 'Enter';
                        }
                        if (key === 'Shift') {
                            displayKey = '⇧';
                        }
                    }
                    
                    keyboardHTML += `<div class="${className}" data-key="${dataKey}">${displayKey}</div>`;
                });
                keyboardHTML += '</div>';
            });
            
            $('#keyboardContent').html(keyboardHTML);
            
            // Add keyboard event handlers
            $('.keyboard-key').on('mousedown touchstart', function(e) {
                e.preventDefault();
                const key = $(this).data('key');
                handleKeyPress(key);
                $(this).addClass('active');
            });
            
            $('.keyboard-key').on('mouseup mouseleave touchend', function() {
                $(this).removeClass('active');
            });
        }
        
        // Handle key press from virtual keyboard
        function handleKeyPress(key) {
            let input = activeInput;
            
            if (!input) {
                // If no input is focused, try to find an input
                const firstInput = $('input[type="text"], input[type="number"], textarea').first();
                if (firstInput.length) {
                    input = firstInput[0];
                    input.focus();
                } else {
                    return; // No input available
                }
            }
            
            const start = input.selectionStart;
            const end = input.selectionEnd;
            const value = input.value;
            
            switch(key) {
                case 'backspace':
                    if (start === end && start > 0) {
                        input.value = value.substring(0, start - 1) + value.substring(end);
                        input.selectionStart = input.selectionEnd = start - 1;
                    } else if (start !== end) {
                        input.value = value.substring(0, start) + value.substring(end);
                        input.selectionStart = input.selectionEnd = start;
                    }
                    break;
                    
                case 'caps':
                    capsLock = !capsLock;
                    shiftActive = false;
                    $('#capsLockBtn').toggleClass('active', capsLock);
                    updateKeyboardCase();
                    showNotification(capsLock ? 'Caps Lock ON' : 'Caps Lock OFF', 'info');
                    break;
                    
                case 'shift':
                    shiftActive = !shiftActive;
                    if (shiftActive) {
                        capsLock = false;
                        $('#capsLockBtn').removeClass('active');
                    }
                    updateKeyboardCase();
                    break;
                    
                case ' ':
                    input.value = value.substring(0, start) + ' ' + value.substring(end);
                    input.selectionStart = input.selectionEnd = start + 1;
                    break;
                    
                case 'enter':
                    if (input.form) {
                        // Don't submit on Enter in inputs, move to next input
                        if (input.type !== 'submit') {
                            const inputs = Array.from(input.form.querySelectorAll('input, select, textarea'));
                            const currentIndex = inputs.indexOf(input);
                            if (currentIndex < inputs.length - 1) {
                                inputs[currentIndex + 1].focus();
                            }
                        } else {
                            input.form.submit();
                        }
                    }
                    break;
                    
                default:
                    let char = key;
                    
                    // Handle letter case
                    if (key.length === 1 && /[a-z]/.test(key)) {
                        if (capsLock || shiftActive) {
                            char = key.toUpperCase();
                        }
                    }
                    
                    // Handle symbol case for shift
                    if (shiftActive) {
                        const shiftMap = {
                            '1': '!', '2': '@', '3': '#', '4': '$', '5': '%',
                            '6': '^', '7': '&', '8': '*', '9': '(', '0': ')',
                            '-': '_', '=': '+', '[': '{', ']': '}', '\\': '|',
                            ';': ':', "'": '"', ',': '<', '.': '>', '/': '?',
                            '`': '~'
                        };
                        char = shiftMap[char] || char;
                    }
                    
                    // Insert character at cursor position
                    input.value = value.substring(0, start) + char + value.substring(end);
                    input.selectionStart = input.selectionEnd = start + 1;
                    
                    // If shift was active for a single character, turn it off
                    if (shiftActive && !capsLock) {
                        shiftActive = false;
                        updateKeyboardCase();
                    }
                    break;
            }
            
            // Trigger input event for validation
            $(input).trigger('input');
            $(input).trigger('change');
            
            // Keep focus on the input
            input.focus();
        }
        
        // Update keyboard case based on caps and shift
        function updateKeyboardCase() {
            $('.keyboard-key').each(function() {
                const key = $(this).data('key');
                if (key && key.length === 1 && /[a-z]/.test(key)) {
                    let displayKey = key;
                    if (capsLock || shiftActive) {
                        displayKey = key.toUpperCase();
                    }
                    $(this).text(displayKey);
                }
            });
        }
        
        // Toggle caps lock
        function toggleCapsLock() {
            capsLock = !capsLock;
            shiftActive = false;
            $('#capsLockBtn').toggleClass('active', capsLock);
            updateKeyboardCase();
            showNotification(capsLock ? 'Caps Lock ON' : 'Caps Lock OFF', 'info');
        }
        
        // Toggle fullscreen
        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(err => {
                    showNotification('Fullscreen not supported', 'warning');
                });
                isFullscreen = true;
                showNotification('Fullscreen mode enabled', 'success');
            } else {
                document.exitFullscreen();
                isFullscreen = false;
                showNotification('Fullscreen mode disabled', 'info');
            }
        }
        
        // Logout function
        function logout() {
            Swal.fire({
                title: 'Logout?',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, logout!',
                cancelButtonText: 'Cancel',
                backdrop: true,
                allowOutsideClick: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        }
        
        // Activate Windows function
        function activateWindows() {
            Swal.fire({
                title: 'Activate Windows',
                text: 'This feature is for demonstration purposes only.',
                icon: 'info',
                confirmButtonText: 'OK',
                confirmButtonColor: '#0078d4'
            });
        }
        
        // Show notification
        function showNotification(message, type = 'info') {
            // Remove existing notifications
            $('.notification').remove();
            
            const icon = {
                'success': 'check-circle',
                'error': 'times-circle',
                'warning': 'exclamation-triangle',
                'info': 'info-circle'
            }[type] || 'info-circle';
            
            const notification = $(`
                <div class="notification ${type}">
                    <i class="fas fa-${icon} me-2"></i>
                    ${message}
                </div>
            `);
            
            $('body').append(notification);
            
            // Remove after 3 seconds
            setTimeout(() => {
                notification.css('animation', 'slideOut 0.3s ease');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 3000);
        }
        
        // Fullscreen change event listeners
        document.addEventListener('fullscreenchange', updateFullscreenState);
        document.addEventListener('webkitfullscreenchange', updateFullscreenState);
        document.addEventListener('mozfullscreenchange', updateFullscreenState);
        document.addEventListener('msfullscreenchange', updateFullscreenState);
        
        function updateFullscreenState() {
            isFullscreen = !!(document.fullscreenElement || 
                            document.webkitFullscreenElement || 
                            document.mozFullScreenElement || 
                            document.msFullscreenElement);
        }
    </script>