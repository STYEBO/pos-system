<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    echo "Unauthorized";
    exit;
}

include "db.php";

$id = intval($_POST['id'] ?? 0);

if ($id <= 0) {
    echo "Invalid user ID";
    exit;
}

// Prevent deleting the main admin account
$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($username);
$stmt->fetch();
$stmt->close();

if ($username === 'admin') {
    echo "Cannot delete main admin account";
    exit;
}

// Delete the user
$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "User deleted successfully";
} else {
    echo "Error deleting user";
}

$stmt->close();
$conn->close();
?>