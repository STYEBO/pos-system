<?php
include 'auth.php';
include 'db.php';

if (isset($_POST['export'])) {
    $table = $_POST['table'];

    $backup = "";
    $row2 = $conn->query("SHOW CREATE TABLE `$table`")->fetch_row();
    $backup .= "DROP TABLE IF EXISTS `$table`;\n";
    $backup .= $row2[1] . ";\n\n";

    $result = $conn->query("SELECT * FROM `$table`");
    while ($row = $result->fetch_assoc()) {
        $cols = array_keys($row);
        $vals = array_map(fn($v) => isset($v) ? "'" . $conn->real_escape_string($v) . "'" : "NULL", $row);
        $backup .= "INSERT INTO `$table` (`".implode("`,`",$cols)."`) VALUES (".implode(",",$vals).");\n";
    }

    header("Content-Disposition: attachment; filename={$table}_backup.sql");
    echo $backup;
    exit;
}

$tables = $conn->query("SHOW TABLES");
?>
<form method="post">
    <select name="table">
        <?php while ($t = $tables->fetch_array()) echo "<option>$t[0]</option>"; ?>
    </select>
    <button name="export">Export Table</button>
</form>
