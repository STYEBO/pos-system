<?php
session_start();
require_once 'db.php';

// Get system settings
$settings_query = "SELECT setting_key, setting_value FROM system_settings";
$settings_result = $conn->query($settings_query);
$settings = [];
while($row = $settings_result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// Set default values if not set
$defaults = [
    'store_name' => 'Grocery Store POS',
    'tax_rate' => '8.5',
    'currency' => 'USD',
    'receipt_footer' => 'Thank you for shopping with us!'
];

foreach ($defaults as $key => $value) {
    if (!isset($settings[$key])) {
        $settings[$key] = $value;
    }
}

header('Content-Type: application/json');
echo json_encode($settings);

$conn->close();
?>