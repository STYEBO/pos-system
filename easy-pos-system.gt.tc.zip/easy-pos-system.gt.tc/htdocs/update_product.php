<?php
// update_product.php - IMPROVED VERSION WITH BETTER VALIDATION
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
if ($user_role != 'admin') {
    header("Location: dashboard.php");
    exit;
}

require_once 'db.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid request method';
    header("Location: manage_products.php");
    exit;
}

// Get form data with validation
$product_id = intval($_POST['product_id'] ?? 0);
if ($product_id <= 0) {
    $_SESSION['error'] = 'Invalid product ID';
    header("Location: manage_products.php");
    exit;
}

// Sanitize inputs
$name = htmlspecialchars(trim($_POST['name'] ?? ''), ENT_QUOTES, 'UTF-8');
$barcode_input = trim($_POST['barcode'] ?? '');
$barcode = !empty($barcode_input) ? $barcode_input : NULL;
$price = floatval($_POST['price'] ?? 0);
$unit = trim($_POST['unit'] ?? 'pcs');
$min_stock = intval($_POST['min_stock'] ?? 0);
$category_id = intval($_POST['category_id'] ?? 0);
$remove_image = isset($_POST['remove_image']) && $_POST['remove_image'] == '1';

// Validate quantity based on unit type
$quantity_input = $_POST['quantity'] ?? 0;
$quantity = 0;

$allowed_units = ['pcs', 'kg', 'g', 'liter', 'ml', 'pack', 'box', 'bottle', 'dozen', 'carton'];
if (!in_array($unit, $allowed_units)) {
    $_SESSION['error'] = 'Invalid unit selected';
    header("Location: edit_product.php?id=" . $product_id);
    exit;
}

// Determine if unit is weight/volume (allows decimals) or piece (integer only)
$weight_volume_units = ['kg', 'g', 'liter', 'ml'];
if (in_array($unit, $weight_volume_units)) {
    // Weight/Volume units - allow decimals
    $quantity = floatval($quantity_input);
    if ($quantity < 0) {
        $_SESSION['error'] = 'Quantity cannot be negative';
        header("Location: edit_product.php?id=" . $product_id);
        exit;
    }
} else {
    // Piece units - integer only
    $quantity = intval($quantity_input);
    if ($quantity < 0) {
        $_SESSION['error'] = 'Quantity cannot be negative';
        header("Location: edit_product.php?id=" . $product_id);
        exit;
    }
}

// Validate required fields
if (empty($name)) {
    $_SESSION['error'] = 'Product name is required';
    header("Location: edit_product.php?id=" . $product_id);
    exit;
}

if ($price <= 0) {
    $_SESSION['error'] = 'Price must be greater than 0';
    header("Location: edit_product.php?id=" . $product_id);
    exit;
}

if ($category_id <= 0) {
    $_SESSION['error'] = 'Please select a category';
    header("Location: edit_product.php?id=" . $product_id);
    exit;
}

if ($min_stock < 0) {
    $_SESSION['error'] = 'Minimum stock cannot be negative';
    header("Location: edit_product.php?id=" . $product_id);
    exit;
}

try {
    // Start transaction
    $conn->begin_transaction();
    
    // Check if product exists
    $checkStmt = $conn->prepare("SELECT id, image, barcode FROM products WHERE id = ?");
    $checkStmt->bind_param("i", $product_id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows === 0) {
        $_SESSION['error'] = 'Product not found';
        header("Location: manage_products.php");
        exit;
    }
    
    $existingProduct = $checkResult->fetch_assoc();
    $checkStmt->close();
    
    // Check if barcode already exists (only if new barcode is provided)
    if ($barcode !== NULL && $barcode !== '') {
        // Check if barcode already exists for another product
        $barcodeStmt = $conn->prepare("SELECT id, name FROM products WHERE barcode = ? AND barcode IS NOT NULL AND barcode != '' AND id != ?");
        $barcodeStmt->bind_param("si", $barcode, $product_id);
        $barcodeStmt->execute();
        $barcodeResult = $barcodeStmt->get_result();
        
        if ($barcodeResult->num_rows > 0) {
            $existing = $barcodeResult->fetch_assoc();
            $conn->rollback();
            $_SESSION['error'] = 'Barcode already exists for product: ' . htmlspecialchars($existing['name']);
            header("Location: edit_product.php?id=" . $product_id);
            exit;
        }
        $barcodeStmt->close();
    }
    
    // Handle image upload
    $image_filename = NULL; // Store only filename, not path
    $image_updated = false;
    
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/products/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (!in_array($file_ext, $allowed_ext)) {
            $conn->rollback();
            $_SESSION['error'] = 'Invalid file extension. Allowed: jpg, jpeg, png, gif, webp';
            header("Location: edit_product.php?id=" . $product_id);
            exit;
        }
        
        // Validate MIME type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime_type = finfo_file($finfo, $_FILES['image']['tmp_name']);
        finfo_close($finfo);
        
        $allowed_mimes = [
            'image/jpeg' => ['jpg', 'jpeg'],
            'image/png' => ['png'],
            'image/gif' => ['gif'],
            'image/webp' => ['webp']
        ];
        
        $valid_mime = false;
        foreach ($allowed_mimes as $mime => $exts) {
            if ($mime_type === $mime && in_array($file_ext, $exts)) {
                $valid_mime = true;
                break;
            }
        }
        
        if (!$valid_mime) {
            $conn->rollback();
            $_SESSION['error'] = 'Invalid file type or extension mismatch';
            header("Location: edit_product.php?id=" . $product_id);
            exit;
        }
        
        // Validate file size (5MB max)
        if ($_FILES['image']['size'] > 5 * 1024 * 1024) {
            $conn->rollback();
            $_SESSION['error'] = 'File too large. Max 5MB allowed.';
            header("Location: edit_product.php?id=" . $product_id);
            exit;
        }
        
        // Sanitize filename - store only filename, not full path
        $original_name = pathinfo($_FILES['image']['name'], PATHINFO_FILENAME);
        $sanitized_name = preg_replace('/[^a-zA-Z0-9_-]/', '', $original_name);
        $filename = $sanitized_name . '_' . uniqid() . '_' . time() . '.' . $file_ext;
        $target_path = $upload_dir . $filename;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            $image_filename = $filename; // Store only filename
            $image_updated = true;
            
            // Delete old image if exists
            if (!empty($existingProduct['image'])) {
                $old_image_path = $upload_dir . $existingProduct['image'];
                if (file_exists($old_image_path)) {
                    @unlink($old_image_path);
                }
            }
        } else {
            $conn->rollback();
            $_SESSION['error'] = 'Failed to upload image';
            header("Location: edit_product.php?id=" . $product_id);
            exit;
        }
    }
    
    // Handle image removal
    if ($remove_image && !empty($existingProduct['image'])) {
        $upload_dir = 'uploads/products/';
        $old_image_path = $upload_dir . $existingProduct['image'];
        if (file_exists($old_image_path)) {
            @unlink($old_image_path);
        }
        $image_filename = NULL;
        $image_updated = true;
    }
    
    // Validate category exists
    $catStmt = $conn->prepare("SELECT id FROM categories WHERE id = ?");
    $catStmt->bind_param("i", $category_id);
    $catStmt->execute();
    $catResult = $catStmt->get_result();
    if ($catResult->num_rows === 0) {
        $conn->rollback();
        $_SESSION['error'] = 'Invalid category selected';
        header("Location: edit_product.php?id=" . $product_id);
        exit;
    }
    $catStmt->close();
    
    // Build SQL query based on whether image is being updated
    if ($image_updated) {
        // Image is being updated (either new image or removed)
        $sql = "UPDATE products SET 
                name = ?, 
                barcode = ?, 
                price = ?, 
                quantity = ?, 
                unit = ?, 
                min_stock = ?, 
                category_id = ?, 
                image = ? 
                WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdissisi", $name, $barcode, $price, $quantity, $unit, $min_stock, $category_id, $image_filename, $product_id);
    } else {
        // Keep existing image
        $sql = "UPDATE products SET 
                name = ?, 
                barcode = ?, 
                price = ?, 
                quantity = ?, 
                unit = ?, 
                min_stock = ?, 
                category_id = ? 
                WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdissii", $name, $barcode, $price, $quantity, $unit, $min_stock, $category_id, $product_id);
    }
    
    if ($stmt->execute()) {
        $conn->commit();
        $_SESSION['message'] = 'Product updated successfully';
    } else {
        $conn->rollback();
        $_SESSION['error'] = 'Failed to update product: ' . $conn->error;
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    if (isset($conn) && method_exists($conn, 'rollback')) {
        $conn->rollback();
    }
    $_SESSION['error'] = 'Error: ' . $e->getMessage();
}

// Redirect back to edit page
header("Location: edit_product.php?id=" . $product_id);
exit;
?>