<?php
// db.php - Simple Fixed Version

$host = "sql105.infinityfree.com";
$user = "if0_40929186";
$pass = "nIEej2teqP";
$db   = "if0_40929186_pos_system";

// Only hide errors in production
if (!isset($_SERVER['HTTP_HOST']) || $_SERVER['HTTP_HOST'] != 'localhost') {
    error_reporting(0);
    ini_set('display_errors', 0);
}

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    // Log the actual error for debugging
    error_log("MySQL Connection Error: " . $conn->connect_error);
    
    // Show generic message to user
    if (isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] == 'localhost') {
        // Show detailed error only on localhost
        die("Database Connection Failed: " . $conn->connect_error);
    } else {
        // Generic message for production
        die("Database Connection Failed. Please try again later.");
    }
}



// Set UTF-8 encoding
$conn->set_charset("utf8mb4");

?>