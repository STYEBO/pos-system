<?php
session_start();

// Start debug logging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log function
function debug_log($message, $data = null) {
    $log_file = 'debug_update.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_message = "[$timestamp] $message";
    
    if ($data !== null) {
        $log_message .= " | Data: " . print_r($data, true);
    }
    
    $log_message .= PHP_EOL;
    file_put_contents($log_file, $log_message, FILE_APPEND);
    
    // Also output to response
    return $message . ($data ? " | " . json_encode($data) : "");
}

debug_log("=== UPDATE CATEGORY DEBUG START ===");
debug_log("REQUEST METHOD: " . $_SERVER['REQUEST_METHOD']);
debug_log("POST DATA: ", $_POST);
debug_log("SESSION DATA: ", $_SESSION);

// Check session
if (!isset($_SESSION['username'])) {
    debug_log("No session found, redirecting to login");
    header("Location: index.html");
    exit;
}

// Check if user is admin
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : 'cashier';
debug_log("User role: " . $user_role);

if ($user_role != 'admin') {
    debug_log("User is not admin, redirecting to dashboard");
    header("Location: dashboard.php");
    exit;
}

// Include database connection
$db_included = false;
if (file_exists('db.php')) {
    require_once 'db.php';
    $db_included = true;
    debug_log("Database file included successfully");
    
    // Test database connection
    if ($conn && $conn->ping()) {
        debug_log("Database connection successful");
    } else {
        debug_log("Database connection FAILED");
    }
} else {
    debug_log("Database file (db.php) NOT FOUND");
}

// Prepare response
$response = [
    'success' => false,
    'message' => '',
    'debug' => [],
    'post_data' => $_POST,
    'db_connected' => $db_included && isset($conn) && $conn->ping()
];

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    debug_log("Processing POST request");
    
    // Get data from POST
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $category_name = isset($_POST['category_name']) ? trim($_POST['category_name']) : '';
    
    $response['debug']['category_id'] = $category_id;
    $response['debug']['category_name'] = $category_name;
    
    // Validate inputs
    if ($category_id <= 0) {
        $response['message'] = 'Invalid category ID';
        debug_log("Invalid category ID: " . $category_id);
    } elseif (empty($category_name)) {
        $response['message'] = 'Category name cannot be empty';
        debug_log("Empty category name");
    } elseif (!$db_included || !isset($conn) || !$conn->ping()) {
        $response['message'] = 'Database connection failed';
        debug_log("Database connection issue");
    } else {
        debug_log("Input validation passed");
        
        try {
            // Check if category exists
            $response['debug']['step'] = 'Checking if category exists';
            $checkStmt = $conn->prepare("SELECT id, name FROM categories WHERE id = ?");
            
            if (!$checkStmt) {
                $response['message'] = 'Prepare statement failed: ' . $conn->error;
                $response['debug']['check_prepare_error'] = $conn->error;
                debug_log("Prepare statement failed: " . $conn->error);
            } else {
                $checkStmt->bind_param("i", $category_id);
                
                if (!$checkStmt->execute()) {
                    $response['message'] = 'Execute failed: ' . $checkStmt->error;
                    $response['debug']['check_execute_error'] = $checkStmt->error;
                    debug_log("Execute failed: " . $checkStmt->error);
                } else {
                    $checkResult = $checkStmt->get_result();
                    $response['debug']['check_result_rows'] = $checkResult->num_rows;
                    
                    if ($checkResult->num_rows === 0) {
                        $response['message'] = 'Category not found';
                        debug_log("Category not found with ID: " . $category_id);
                    } else {
                        $category = $checkResult->fetch_assoc();
                        $response['debug']['current_category'] = $category;
                        debug_log("Category found: ", $category);
                        
                        // Don't allow editing of 'All Items' category name
                        if ($category['name'] == 'All Items' && $category_name != 'All Items') {
                            $response['message'] = 'Cannot rename system category "All Items"';
                            debug_log("Attempt to rename system category");
                        } else {
                            // Check if new name already exists
                            $response['debug']['step'] = 'Checking for duplicate names';
                            $nameCheckStmt = $conn->prepare("SELECT id FROM categories WHERE name = ? AND id != ?");
                            
                            if (!$nameCheckStmt) {
                                $response['message'] = 'Name check prepare failed: ' . $conn->error;
                                $response['debug']['name_check_prepare_error'] = $conn->error;
                                debug_log("Name check prepare failed: " . $conn->error);
                            } else {
                                $nameCheckStmt->bind_param("si", $category_name, $category_id);
                                
                                if (!$nameCheckStmt->execute()) {
                                    $response['message'] = 'Name check execute failed: ' . $nameCheckStmt->error;
                                    $response['debug']['name_check_execute_error'] = $nameCheckStmt->error;
                                    debug_log("Name check execute failed: " . $nameCheckStmt->error);
                                } else {
                                    $nameResult = $nameCheckStmt->get_result();
                                    $response['debug']['duplicate_check_rows'] = $nameResult->num_rows;
                                    
                                    if ($nameResult->num_rows > 0) {
                                        $response['message'] = 'Category name already exists';
                                        debug_log("Duplicate category name found: " . $category_name);
                                    } else {
                                        // Update the category
                                        $response['debug']['step'] = 'Updating category';
                                        $updateStmt = $conn->prepare("UPDATE categories SET name = ?, updated_at = NOW() WHERE id = ?");
                                        
                                        if (!$updateStmt) {
                                            $response['message'] = 'Update prepare failed: ' . $conn->error;
                                            $response['debug']['update_prepare_error'] = $conn->error;
                                            debug_log("Update prepare failed: " . $conn->error);
                                        } else {
                                            $updateStmt->bind_param("si", $category_name, $category_id);
                                            
                                            if (!$updateStmt->execute()) {
                                                $response['message'] = 'Update execute failed: ' . $updateStmt->error;
                                                $response['debug']['update_execute_error'] = $updateStmt->error;
                                                debug_log("Update execute failed: " . $updateStmt->error);
                                            } else {
                                                $affected_rows = $updateStmt->affected_rows;
                                                $response['debug']['affected_rows'] = $affected_rows;
                                                
                                                if ($affected_rows > 0) {
                                                    $response['success'] = true;
                                                    $response['message'] = 'Category updated successfully';
                                                    $response['new_name'] = $category_name;
                                                    debug_log("Category update SUCCESS: " . $category_name);
                                                } else {
                                                    $response['message'] = 'No rows affected - category may not exist';
                                                    debug_log("No rows affected by update");
                                                }
                                            }
                                            $updateStmt->close();
                                        }
                                    }
                                }
                                $nameCheckStmt->close();
                            }
                        }
                    }
                }
                $checkStmt->close();
            }
        } catch (Exception $e) {
            $response['message'] = 'Exception: ' . $e->getMessage();
            $response['debug']['exception'] = $e->getMessage();
            debug_log("Exception caught: " . $e->getMessage());
        }
    }
} else {
    $response['message'] = 'Invalid request method';
    debug_log("Invalid request method: " . $_SERVER['REQUEST_METHOD']);
}

// Add final debug info
$response['debug']['timestamp'] = date('Y-m-d H:i:s');
$response['debug']['memory_usage'] = memory_get_usage(true);
debug_log("Response prepared: ", $response);
debug_log("=== UPDATE CATEGORY DEBUG END ===");

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit;
?>