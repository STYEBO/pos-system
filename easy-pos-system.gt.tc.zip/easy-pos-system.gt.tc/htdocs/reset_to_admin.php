<?php
// reset_to_admin.php - Reset admin password to "admin"
$host = "sql105.infinityfree.com";
$user = "if0_40929186";
$pass = "nIEej2teqP";
$db   = "if0_40929186_pos_system";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "<h2>🔄 Resetting Admin Password</h2>";

// Set admin password to "admin" (lowercase)
$admin_username = "admin";
$admin_password = "admin";  // Your desired password
$hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

// Check if admin exists
$check = $conn->query("SELECT id FROM users WHERE username = '$admin_username'");

if ($check->num_rows > 0) {
    // Update existing admin
    $sql = "UPDATE users SET password = '$hashed_password' WHERE username = '$admin_username'";
    
    if ($conn->query($sql) === TRUE) {
        echo "<div style='background:green;color:white;padding:20px;border-radius:10px;'>";
        echo "<h3>✅ PASSWORD RESET SUCCESSFUL!</h3>";
        echo "<p>Admin password has been changed to: <strong>admin</strong></p>";
        echo "</div>";
    } else {
        echo "<p style='color:red'>Error updating: " . $conn->error . "</p>";
    }
} else {
    // Create new admin if doesn't exist
    $sql = "INSERT INTO users (username, password, role) VALUES ('$admin_username', '$hashed_password', 'admin')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<div style='background:green;color:white;padding:20px;border-radius:10px;'>";
        echo "<h3>✅ ADMIN ACCOUNT CREATED!</h3>";
        echo "<p>Admin account created with password: <strong>admin</strong></p>";
        echo "</div>";
    } else {
        echo "<p style='color:red'>Error creating: " . $conn->error . "</p>";
    }
}

// Verify the password works
echo "<hr>";
echo "<h3>🔍 Verification Test:</h3>";

$test_hash = password_hash("admin", PASSWORD_DEFAULT);
$verify = $conn->query("SELECT password FROM users WHERE username = 'admin'");
if ($verify->num_rows > 0) {
    $row = $verify->fetch_assoc();
    $db_hash = $row['password'];
    
    if (password_verify("admin", $db_hash)) {
        echo "<p style='color:green;font-weight:bold;'>✅ Password verification SUCCESS!</p>";
        echo "<p>The password 'admin' matches the database hash.</p>";
    } else {
        echo "<p style='color:red;'>❌ Password verification FAILED!</p>";
        echo "<p>Trying to fix again...</p>";
        
        // Force update
        $conn->query("UPDATE users SET password = '$test_hash' WHERE username = 'admin'");
        echo "<p>Password forcefully updated.</p>";
    }
}

$conn->close();

echo "<hr>";
echo "<h3>📋 LOGIN DETAILS:</h3>";
echo "<div style='background:#f8f9fa;padding:15px;border:2px solid #007bff;border-radius:10px;'>";
echo "<p><strong>Login URL:</strong> <a href='index.html' target='_blank'>index.html</a></p>";
echo "<p><strong>Username:</strong> <span style='color:blue;font-size:20px;'>admin</span></p>";
echo "<p><strong>Password:</strong> <span style='color:red;font-size:20px;'>admin</span> (lowercase)</p>";
echo "</div>";

echo "<hr>";
echo "<p><a href='index.html' style='background:#007bff;color:white;padding:15px 30px;text-decoration:none;border-radius:5px;font-size:18px;'>
    ➤ CLICK HERE TO LOGIN NOW
</a></p>";

// Auto-delete after 5 minutes
$file = __FILE__;
if (file_exists($file)) {
    $file_time = filemtime($file);
    if (time() - $file_time > 300) { // 5 minutes
        @unlink($file);
        echo "<p style='color:orange'>⚠️ This file auto-deleted for security.</p>";
    }
}
?>