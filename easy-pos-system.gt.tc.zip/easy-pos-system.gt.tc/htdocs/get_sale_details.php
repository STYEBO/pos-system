<?php
// get_sale_details.php
session_start();
require_once 'db.php';

$sale_id = $_GET['id'] ?? 0;

// Fetch sale details
$sale_query = "SELECT * FROM sales WHERE id = ?";
$sale_stmt = $conn->prepare($sale_query);
$sale_stmt->bind_param("i", $sale_id);
$sale_stmt->execute();
$sale_result = $sale_stmt->get_result();

if ($sale_result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Sale not found']);
    exit;
}

$sale = $sale_result->fetch_assoc();

// Fetch sale items
$items_query = "SELECT si.*, p.name as product_name FROM sale_items si 
                JOIN products p ON si.product_id = p.id 
                WHERE si.sale_id = ?";
$items_stmt = $conn->prepare($items_query);
$items_stmt->bind_param("i", $sale_id);
$items_stmt->execute();
$items_result = $items_stmt->get_result();
$items = $items_result->fetch_all(MYSQLI_ASSOC);

echo json_encode([
    'success' => true,
    'sale' => $sale,
    'items' => $items
]);

$conn->close();
?>