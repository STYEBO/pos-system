<?php
include "db.php";

$username = "admin";
$password = password_hash("admin123", PASSWORD_DEFAULT); // Stronger default password
$role     = "admin";

// Check if admin already exists
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "<div style='padding: 20px; background: #f8d7da; color: #721c24; border-radius: 5px;'>";
    echo "Admin account already exists.";
    echo "</div>";
} else {
    $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $password, $role);
    if ($stmt->execute()) {
        echo "<div style='padding: 20px; background: #d4edda; color: #155724; border-radius: 5px;'>";
        echo "Admin created successfully!<br>";
        echo "Username: admin<br>";
        echo "Password: admin123<br>";
        echo "<strong>IMPORTANT: Change this password immediately!</strong>";
        echo "</div>";
    } else {
        echo "<div style='padding: 20px; background: #f8d7da; color: #721c24; border-radius: 5px;'>";
        echo "Error: " . $conn->error;
        echo "</div>";
    }
}

$stmt->close();
$conn->close();
?>