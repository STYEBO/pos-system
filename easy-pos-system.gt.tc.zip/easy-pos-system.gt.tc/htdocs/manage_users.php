<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.html");
    exit;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - POS System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
         * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #f5f5f5;
             /* Add padding for fixed header */
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            background: #001f3f;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .table th {
            background: #f8f9fa;
            border-top: none;
            font-weight: 600;
        }
        
        .badge-admin {
            background: #dc3545;
        }
        
        .badge-cashier {
            background: #28a745;
        }
        
        .modal-content {
            border-radius: 10px;
            border: none;
        }
        
        .btn-action {
            padding: 5px 10px;
            margin: 0 3px;
        }
        
        @media (max-width: 768px) {
            body {
                padding-top: 120px; /* More padding for mobile */
            }
            
            .table-responsive {
                font-size: 14px;
            }
            
            .btn-action {
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <?php require_once 'header.php'; ?>
    <div class="container mt-4">
        <div class="card shadow">
            <div class="card-header">
                <h3 class="mb-0"><i class="fas fa-users"></i> Manage Users</h3>
                <small class="text-light">Add, edit or delete system users</small>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addUserModal">
                            <i class="fas fa-plus-circle"></i> Add New User
                        </button>
                    </div>
                    <div class="col-md-6 text-end">
                        <div class="d-flex align-items-center justify-content-end">
                            <span class="badge bg-primary p-2 me-2">
                                <i class="fas fa-user-shield"></i> Admin Users
                            </span>
                            <span class="badge bg-success p-2">
                                <i class="fas fa-user"></i> Cashier Users
                            </span>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Created Date</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="usersTable">
                            <tr>
                                <td colspan="5" class="text-center py-4">
                                    <div class="spinner-border text-primary" role="status">
                                        <span class="visually-hidden">Loading users...</span>
                                    </div>
                                    <p class="mt-2 text-muted">Loading users data...</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-user-plus"></i> Add New User</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Username</label>
                        <input type="text" id="newUsername" class="form-control" placeholder="Enter username" required>
                        <small class="text-muted">Unique username for login</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Password</label>
                        <input type="password" id="newPassword" class="form-control" placeholder="Enter password" required>
                        <small class="text-muted">Minimum 6 characters</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Role</label>
                        <select id="newRole" class="form-select">
                            <option value="cashier">Cashier - Can process sales only</option>
                            <option value="admin">Admin - Full system access</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-primary" onclick="addUser()">
                        <i class="fas fa-save"></i> Add User
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- SweetAlert2 for better alerts -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        // Load users on page load
        document.addEventListener('DOMContentLoaded', loadUsers);
        
        function loadUsers() {
            fetch('get_users.php')
                .then(response => response.json())
                .then(data => {
                    const tbody = document.getElementById('usersTable');
                    tbody.innerHTML = '';
                    
                    if(data.length === 0) {
                        tbody.innerHTML = `
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                    <h5 class="text-muted">No users found</h5>
                                    <p class="text-muted">Click "Add New User" to create your first user</p>
                                </td>
                            </tr>`;
                        return;
                    }
                    
                    data.forEach(user => {
                        const row = document.createElement('tr');
                        const roleBadge = user.role === 'admin' ? 
                            '<span class="badge bg-danger"><i class="fas fa-user-shield"></i> Admin</span>' : 
                            '<span class="badge bg-success"><i class="fas fa-user"></i> Cashier</span>';
                        
                        const actions = user.username !== 'admin' ? 
                            `<div class="btn-group">
                                <button class="btn btn-sm btn-warning" onclick="editUser(${user.id})" title="Edit Role">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})" title="Delete User">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>` : 
                            '<span class="text-muted small"><i class="fas fa-shield-alt"></i> Protected account</span>';
                        
                        row.innerHTML = `
                            <td><span class="badge bg-secondary">#${user.id}</span></td>
                            <td><strong>${user.username}</strong></td>
                            <td>${roleBadge}</td>
                            <td>${user.created_at}</td>
                            <td class="text-center">${actions}</td>
                        `;
                        tbody.appendChild(row);
                    });
                })
                .catch(error => {
                    console.error('Error:', error);
                    const tbody = document.getElementById('usersTable');
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="5" class="text-center py-5 text-danger">
                                <i class="fas fa-exclamation-triangle fa-2x mb-3"></i>
                                <h5>Error loading users</h5>
                                <p>Please check your connection and try again</p>
                            </td>
                        </tr>`;
                });
        }
        
        function addUser() {
            const username = document.getElementById('newUsername').value.trim();
            const password = document.getElementById('newPassword').value.trim();
            const role = document.getElementById('newRole').value;
            
            if(!username || !password) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Missing Information',
                    text: 'Please fill in all required fields',
                    confirmButtonColor: '#3085d6',
                });
                return;
            }
            
            if(password.length < 6) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Weak Password',
                    text: 'Password must be at least 6 characters long',
                    confirmButtonColor: '#3085d6',
                });
                return;
            }
            
            fetch('add_user.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&role=${encodeURIComponent(role)}`
            })
            .then(response => response.text())
            .then(result => {
                if(result.includes('successfully')) {
                    Swal.fire({
                        icon: 'success',
                        title: 'User Added',
                        text: result,
                        confirmButtonColor: '#28a745',
                    }).then(() => {
                        loadUsers();
                        document.getElementById('newUsername').value = '';
                        document.getElementById('newPassword').value = '';
                        const modal = bootstrap.Modal.getInstance(document.getElementById('addUserModal'));
                        modal.hide();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: result,
                        confirmButtonColor: '#dc3545',
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Network Error',
                    text: 'Failed to add user. Please try again.',
                    confirmButtonColor: '#dc3545',
                });
            });
        }
        
        function deleteUser(id) {
            Swal.fire({
                title: 'Delete User?',
                text: "This action cannot be undone!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('delete_user.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: `id=${id}`
                    })
                    .then(response => response.text())
                    .then(result => {
                        Swal.fire({
                            icon: result.includes('successfully') ? 'success' : 'error',
                            title: result.includes('successfully') ? 'Deleted!' : 'Error',
                            text: result,
                            confirmButtonColor: result.includes('successfully') ? '#28a745' : '#dc3545',
                        }).then(() => {
                            if(result.includes('successfully')) {
                                loadUsers();
                            }
                        });
                    });
                }
            });
        }
        
        function editUser(id) {
            Swal.fire({
                title: 'Change User Role',
                input: 'select',
                inputOptions: {
                    'cashier': 'Cashier',
                    'admin': 'Admin'
                },
                inputPlaceholder: 'Select new role',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Update Role',
                inputValidator: (value) => {
                    if (!value) {
                        return 'You need to select a role!';
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('edit_user.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: `id=${id}&role=${result.value}`
                    })
                    .then(response => response.text())
                    .then(result => {
                        Swal.fire({
                            icon: result.includes('successfully') ? 'success' : 'error',
                            title: result.includes('successfully') ? 'Updated!' : 'Error',
                            text: result,
                            confirmButtonColor: result.includes('successfully') ? '#28a745' : '#dc3545',
                        }).then(() => {
                            if(result.includes('successfully')) {
                                loadUsers();
                            }
                        });
                    });
                }
            });
        }
    </script>
</body>
</html>