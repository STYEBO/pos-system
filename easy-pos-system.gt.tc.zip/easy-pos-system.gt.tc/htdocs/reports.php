<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

require_once 'db.php';

// Get system settings for currency
$system_settings = [];
$settings_query = "SELECT setting_key, setting_value FROM system_settings";
$settings_result = $conn->query($settings_query);
if ($settings_result) {
    while($row = $settings_result->fetch_assoc()) {
        $system_settings[$row['setting_key']] = $row['setting_value'];
    }
}

$currency_symbol = '$'; // default
if (isset($system_settings['currency'])) {
    switch($system_settings['currency']) {
        case 'USD': $currency_symbol = '$'; break;
        case 'EUR': $currency_symbol = '€'; break;
        case 'GBP': $currency_symbol = '£'; break;
        case 'INR': $currency_symbol = '₹'; break;
    }
}

// Get report data
$sales_data = [];
$total_sales = 0;
$total_revenue = 0;

// Today's sales
$today_sales = $conn->query("SELECT COUNT(*) as count, SUM(total) as revenue FROM sales WHERE DATE(created_at) = CURDATE()")->fetch_assoc();

// Yesterday's sales for comparison
$yesterday_sales = $conn->query("SELECT COUNT(*) as count, SUM(total) as revenue FROM sales WHERE DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)")->fetch_assoc();

// This month sales
$month_sales = $conn->query("SELECT COUNT(*) as count, SUM(total) as revenue FROM sales WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")->fetch_assoc();

// Last month sales for comparison
$last_month_sales = $conn->query("SELECT COUNT(*) as count, SUM(total) as revenue FROM sales WHERE MONTH(created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))")->fetch_assoc();

// Weekly sales data for chart
$weekly_data = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $day_name = date('D', strtotime($date));
    $result = $conn->query("SELECT COALESCE(SUM(total), 0) as total FROM sales WHERE DATE(created_at) = '$date'");
    $row = $result->fetch_assoc();
    $weekly_data[] = [
        'day' => $day_name,
        'sales' => floatval($row['total'] ?: 0)
    ];
}

// Recent sales
$recent_sales_query = $conn->query("SELECT s.*, COUNT(si.id) as items_count FROM sales s LEFT JOIN sale_items si ON s.id = si.sale_id GROUP BY s.id ORDER BY s.created_at DESC LIMIT 10");

// Top products
$top_products_query = $conn->query("SELECT p.name, SUM(si.quantity) as total_sold, SUM(si.total_price) as revenue FROM sale_items si JOIN products p ON si.product_id = p.id GROUP BY p.id ORDER BY total_sold DESC LIMIT 5");

// Best selling categories
$top_categories_query = $conn->query("SELECT c.name, SUM(si.quantity) as total_sold, SUM(si.total_price) as revenue FROM sale_items si JOIN products p ON si.product_id = p.id JOIN categories c ON p.category_id = c.id GROUP BY c.id ORDER BY total_sold DESC LIMIT 5");

// Calculate growth percentages
$today_growth = 0;
$month_growth = 0;

if ($yesterday_sales['revenue'] > 0) {
    $today_growth = (($today_sales['revenue'] - $yesterday_sales['revenue']) / $yesterday_sales['revenue']) * 100;
}

if ($last_month_sales['revenue'] > 0) {
    $month_growth = (($month_sales['revenue'] - $last_month_sales['revenue']) / $last_month_sales['revenue']) * 100;
}

include("header.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - QEloERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: #f5f5f5;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            background: #28a745;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            height: 100%;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 40px;
            margin-bottom: 15px;
        }
        
        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: #28a745;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            color: #6c757d;
            margin-bottom: 10px;
        }
        
        .growth-badge {
            font-size: 12px;
            padding: 3px 10px;
            border-radius: 15px;
        }
        
        .growth-up {
            background: #d4edda;
            color: #155724;
        }
        
        .growth-down {
            background: #f8d7da;
            color: #721c24;
        }
        
        .btn-export {
            background: #17a2b8;
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 5px;
            font-weight: 600;
        }
        
        .btn-export:hover {
            background: #138496;
        }
        
        .table th {
            background: #f8f9fa;
            font-weight: 600;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container-fluid mt-3">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3><i class="fas fa-chart-bar me-2"></i> Sales Reports Dashboard</h3>
            <div>
                <button class="btn btn-export" onclick="exportReport()">
                    <i class="fas fa-download me-1"></i> Export Report
                </button>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon text-primary">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-value"><?php echo $today_sales['count'] ?: 0; ?></div>
                    <div class="stat-label">Today's Sales</div>
                    <?php if ($yesterday_sales['count'] > 0): ?>
                    <div class="growth-badge <?php echo $today_sales['count'] > $yesterday_sales['count'] ? 'growth-up' : 'growth-down'; ?>">
                        <i class="fas fa-arrow-<?php echo $today_sales['count'] > $yesterday_sales['count'] ? 'up' : 'down'; ?> me-1"></i>
                        <?php 
                            $change = $yesterday_sales['count'] > 0 ? 
                                (($today_sales['count'] - $yesterday_sales['count']) / $yesterday_sales['count']) * 100 : 0;
                            echo number_format(abs($change), 1) . '%';
                        ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon text-success">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-value"><?php echo $currency_symbol . number_format($today_sales['revenue'] ?: 0, 2); ?></div>
                    <div class="stat-label">Today's Revenue</div>
                    <?php if ($yesterday_sales['revenue'] > 0): ?>
                    <div class="growth-badge <?php echo $today_sales['revenue'] > $yesterday_sales['revenue'] ? 'growth-up' : 'growth-down'; ?>">
                        <i class="fas fa-arrow-<?php echo $today_sales['revenue'] > $yesterday_sales['revenue'] ? 'up' : 'down'; ?> me-1"></i>
                        <?php echo number_format($today_growth, 1) . '%'; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon text-info">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="stat-value"><?php echo $month_sales['count'] ?: 0; ?></div>
                    <div class="stat-label">This Month Sales</div>
                    <?php if ($last_month_sales['count'] > 0): ?>
                    <div class="growth-badge <?php echo $month_sales['count'] > $last_month_sales['count'] ? 'growth-up' : 'growth-down'; ?>">
                        <i class="fas fa-arrow-<?php echo $month_sales['count'] > $last_month_sales['count'] ? 'up' : 'down'; ?> me-1"></i>
                        <?php 
                            $change = $last_month_sales['count'] > 0 ? 
                                (($month_sales['count'] - $last_month_sales['count']) / $last_month_sales['count']) * 100 : 0;
                            echo number_format(abs($change), 1) . '%';
                        ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon text-warning">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-value"><?php echo $currency_symbol . number_format($month_sales['revenue'] ?: 0, 2); ?></div>
                    <div class="stat-label">Monthly Revenue</div>
                    <?php if ($last_month_sales['revenue'] > 0): ?>
                    <div class="growth-badge <?php echo $month_sales['revenue'] > $last_month_sales['revenue'] ? 'growth-up' : 'growth-down'; ?>">
                        <i class="fas fa-arrow-<?php echo $month_sales['revenue'] > $last_month_sales['revenue'] ? 'up' : 'down'; ?> me-1"></i>
                        <?php echo number_format($month_growth, 1) . '%'; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Charts and Tables -->
        <div class="row">
            <!-- Sales Chart -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-chart-line me-2"></i> Weekly Sales Overview</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="salesChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Top Products -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-star me-2"></i> Top Products</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Sold</th>
                                        <th>Revenue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $top_products = $top_products_query;
                                    if ($top_products && $top_products->num_rows > 0):
                                        while($product = $top_products->fetch_assoc()): 
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                                        <td><span class="badge bg-primary"><?php echo $product['total_sold']; ?></span></td>
                                        <td><?php echo $currency_symbol . number_format($product['revenue'], 2); ?></td>
                                    </tr>
                                    <?php 
                                        endwhile;
                                    else: 
                                    ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-muted">No sales data yet</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Top Categories -->
                <div class="card mt-3">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-tags me-2"></i> Top Categories</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Sold</th>
                                        <th>Revenue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $top_categories = $top_categories_query;
                                    if ($top_categories && $top_categories->num_rows > 0):
                                        while($category = $top_categories->fetch_assoc()): 
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($category['name']); ?></td>
                                        <td><span class="badge bg-info"><?php echo $category['total_sold']; ?></span></td>
                                        <td><?php echo $currency_symbol . number_format($category['revenue'], 2); ?></td>
                                    </tr>
                                    <?php 
                                        endwhile;
                                    else: 
                                    ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-muted">No category data yet</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Sales -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-history me-2"></i> Recent Sales</h5>
                        <div>
                            <button class="btn btn-sm btn-outline-primary" onclick="loadMoreSales()">
                                <i class="fas fa-sync me-1"></i> Refresh
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Date & Time</th>
                                        <th>Cashier</th>
                                        <th>Customer</th>
                                        <th>Items</th>
                                        <th>Total</th>
                                        <th>Payment</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="recentSalesTable">
                                    <?php 
                                    $recent_sales = $recent_sales_query;
                                    if ($recent_sales && $recent_sales->num_rows > 0):
                                        while($sale = $recent_sales->fetch_assoc()): 
                                    ?>
                                    <tr>
                                        <td>#<?php echo $sale['id']; ?></td>
                                        <td><?php echo date('Y-m-d H:i', strtotime($sale['created_at'])); ?></td>
                                        <td><?php echo htmlspecialchars($sale['cashier']); ?></td>
                                        <td><?php echo htmlspecialchars($sale['customer_name'] ?: 'Walk-in'); ?></td>
                                        <td><span class="badge bg-secondary"><?php echo $sale['items_count']; ?></span></td>
                                        <td><strong><?php echo $currency_symbol . number_format($sale['total'], 2); ?></strong></td>
                                        <td>
                                            <span class="badge <?php 
                                                echo $sale['payment_method'] == 'cash' ? 'bg-success' : 
                                                     ($sale['payment_method'] == 'credit_card' ? 'bg-primary' : 
                                                     ($sale['payment_method'] == 'debit_card' ? 'bg-info' : 'bg-warning')); 
                                            ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $sale['payment_method'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-info" onclick="viewSale(<?php echo $sale['id']; ?>)" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-success" onclick="reprintReceipt(<?php echo $sale['id']; ?>)" title="Reprint Receipt">
                                                <i class="fas fa-print"></i>
                                            </button>
                                            <?php if ($_SESSION['role'] == 'admin'): ?>
                                            <button class="btn btn-sm btn-outline-danger" onclick="deleteSale(<?php echo $sale['id']; ?>)" title="Delete Sale">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php 
                                        endwhile;
                                    else: 
                                    ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted">No recent sales found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sale Details Modal -->
    <div class="modal fade" id="saleDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Sale Details - #<span id="saleId"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="saleDetailsContent">
                    <!-- Details will be loaded here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="reprintReceiptFromModal()">
                        <i class="fas fa-print me-1"></i> Reprint Receipt
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
   <script>
    // Sales Chart
    const ctx = document.getElementById('salesChart').getContext('2d');
    const salesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($weekly_data, 'day')); ?>,
            datasets: [{
                label: 'Daily Sales (<?php echo $currency_symbol; ?>)',
                data: <?php echo json_encode(array_column($weekly_data, 'sales')); ?>,
                borderColor: '#28a745',
                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#28a745',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Sales: <?php echo $currency_symbol; ?>' + context.raw.toFixed(2);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '<?php echo $currency_symbol; ?>' + value;
                        },
                        font: {
                            size: 11
                        }
                    },
                    grid: {
                        drawBorder: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 11
                        }
                    }
                }
            }
        }
    });

    let currentSaleId = null;

    function viewSale(saleId) {
        currentSaleId = saleId;
        document.getElementById('saleId').textContent = saleId;
        
        fetch('get_sale_details.php?id=' + saleId)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const sale = data.sale;
                    const items = data.items;
                    
                    let html = `
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Sale ID:</strong> #${sale.id}</p>
                                <p><strong>Date:</strong> ${new Date(sale.created_at).toLocaleString()}</p>
                                <p><strong>Cashier:</strong> ${sale.cashier}</p>
                                <p><strong>Customer:</strong> ${sale.customer_name || 'Walk-in'}</p>
                                <p><strong>Customer Phone:</strong> ${sale.customer_phone || 'N/A'}</p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Subtotal:</strong> $${parseFloat(sale.subtotal).toFixed(2)}</p>
                                <p><strong>Tax:</strong> $${parseFloat(sale.tax).toFixed(2)}</p>
                                <p><strong>Total:</strong> $${parseFloat(sale.total).toFixed(2)}</p>
                                <p><strong>Payment Method:</strong> ${sale.payment_method.toUpperCase()}</p>
                                <p><strong>Change Amount:</strong> $${parseFloat(sale.change_amount || 0).toFixed(2)}</p>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <h6>Items Sold (${items.length} items):</h6>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Qty</th>
                                        <th>Unit Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;
                    
                    items.forEach(item => {
                        html += `
                            <tr>
                                <td>${item.product_name}</td>
                                <td>${item.quantity}</td>
                                <td>$${parseFloat(item.unit_price).toFixed(2)}</td>
                                <td>$${parseFloat(item.total_price).toFixed(2)}</td>
                            </tr>
                        `;
                    });
                    
                    html += `
                                </tbody>
                            </table>
                        </div>
                        
                        ${sale.notes ? `<p><strong>Notes:</strong> ${sale.notes}</p>` : ''}
                    `;
                    
                    document.getElementById('saleDetailsContent').innerHTML = html;
                    new bootstrap.Modal(document.getElementById('saleDetailsModal')).show();
                } else {
                    alert('Failed to load sale details');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to load sale details');
            });
    }

    function reprintReceipt(saleId) {
        // نئی ونڈو کھولیں
        const receiptWindow = window.open(`print_receipt.php?id=${saleId}`, '_blank');
        
        // نئی ونڈو کو فوکس دیں
        if (receiptWindow) {
            receiptWindow.focus();
        }
    }

    function reprintReceiptFromModal() {
        if (currentSaleId) {
            reprintReceipt(currentSaleId);
            const modal = bootstrap.Modal.getInstance(document.getElementById('saleDetailsModal'));
            if (modal) {
                modal.hide();
            }
        }
    }

    function loadMoreSales() {
        fetch('get_recent_sales.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to refresh sales data');
            });
    }

    function deleteSale(saleId) {
        if (!confirm('Are you sure you want to delete this sale? This action cannot be undone.')) {
            return;
        }
        
        fetch('delete_sale.php?id=' + saleId, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Sale deleted successfully');
                location.reload();
            } else {
                alert('Failed to delete sale: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to delete sale');
        });
    }

    function exportReport() {
        const startDate = prompt('Enter start date (YYYY-MM-DD):', '<?php echo date('Y-m-d', strtotime('-7 days')); ?>');
        const endDate = prompt('Enter end date (YYYY-MM-DD):', '<?php echo date('Y-m-d'); ?>');
        
        if (startDate && endDate) {
            const exportWindow = window.open(`export_report.php?start=${startDate}&end=${endDate}`, '_blank');
        } else {
            alert('Please select both start and end dates');
        }
    }

    // Auto-refresh the chart every 5 minutes
    setInterval(() => {
        salesChart.update();
    }, 300000);
</script>
</body>
</html>