<?php
// export_report.php
session_start();
require_once 'db.php';

$start_date = $_GET['start'] ?? date('Y-m-d', strtotime('-7 days'));
$end_date = $_GET['end'] ?? date('Y-m-d');

// Fetch sales data
$sales_query = "SELECT s.*, COUNT(si.id) as items_count 
                FROM sales s 
                LEFT JOIN sale_items si ON s.id = si.sale_id 
                WHERE DATE(s.created_at) BETWEEN ? AND ?
                GROUP BY s.id 
                ORDER BY s.created_at DESC";
$sales_stmt = $conn->prepare($sales_query);
$sales_stmt->bind_param("ss", $start_date, $end_date);
$sales_stmt->execute();
$sales_result = $sales_stmt->get_result();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="sales_report_' . date('Y-m-d') . '.csv"');

// Create output stream
$output = fopen('php://output', 'w');

// Add CSV headers
fputcsv($output, ['Sale ID', 'Date', 'Time', 'Cashier', 'Customer', 'Customer Phone', 'Items', 'Subtotal', 'Tax', 'Total', 'Payment Method', 'Change Amount', 'Notes']);

// Add data rows
while ($sale = $sales_result->fetch_assoc()) {
    fputcsv($output, [
        $sale['id'],
        date('Y-m-d', strtotime($sale['created_at'])),
        date('H:i:s', strtotime($sale['created_at'])),
        $sale['cashier'],
        $sale['customer_name'] ?: 'Walk-in',
        $sale['customer_phone'] ?: '',
        $sale['items_count'],
        $sale['subtotal'],
        $sale['tax'],
        $sale['total'],
        $sale['payment_method'],
        $sale['change_amount'] ?: '0.00',
        $sale['notes'] ?: ''
    ]);
}

fclose($output);
$conn->close();
?>