<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

$query = "SELECT * FROM categories ORDER BY name";
$result = $conn->query($query);

$categories = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

echo json_encode($categories);
?>