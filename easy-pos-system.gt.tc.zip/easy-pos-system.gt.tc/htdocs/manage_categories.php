<?php
session_start();
require_once 'db.php';

/* =========================
   DELETE CATEGORY (AJAX)
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_category'])) {

    header('Content-Type: application/json');

    $category_id = (int)$_POST['category_id'];
    $response = ['success' => false, 'message' => ''];

    $checkStmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
    $checkStmt->bind_param("i", $category_id);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        $category = $result->fetch_assoc();

        if ($category['name'] === 'All Items') {
            $response['message'] = 'System category cannot be deleted';
        } else {
            $deleteStmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
            $deleteStmt->bind_param("i", $category_id);

            if ($deleteStmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Category deleted successfully';
            } else {
                $response['message'] = 'Delete failed';
            }
            $deleteStmt->close();
        }
    } else {
        $response['message'] = 'Category not found';
    }

    $checkStmt->close();
    echo json_encode($response);
    exit;
}

/* =========================
   AUTH CHECK
========================= */
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

$user_role = $_SESSION['role'] ?? 'cashier';
if ($user_role !== 'admin') {
    header("Location: dashboard.php");
    exit;
}

include ("header.php");

/* =========================
   FETCH CATEGORIES
========================= */
$categories = $conn->query("SELECT * FROM categories ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Categories</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

<!-- 🔥 YOUR ORIGINAL STYLE – UNCHANGED -->
<style>
/* (same CSS you provided – untouched) */
body {
    background: #f5f5f5;
    font-family: 'Segoe UI', Arial, sans-serif;
    margin: 0;
    padding: 0;
}
.container-fluid { padding:20px; margin-top:20px; }
h3 { color:#333; font-weight:700; }
.card {
    border-radius:10px;
    border:none;
    box-shadow:0 5px 20px rgba(0,0,0,0.1);
    overflow:hidden;
}
.card-body { padding:0; }
.table { margin-bottom:0; }
.table thead th {
    background:#007bff;
    color:#fff;
    border:none;
    padding:15px 20px;
    font-weight:600;
    font-size:14px;
}
.table tbody td {
    padding:15px 20px;
    vertical-align:middle;
    border-bottom:1px solid #e9ecef;
}
.table tbody tr:hover { background:#f8f9fa; }
.fade-out { animation: fadeOut 0.3s ease forwards; }
@keyframes fadeOut {
    from { opacity:1; transform:translateX(0); }
    to { opacity:0; transform:translateX(-100px); }
}
</style>
</head>

<body>

<div class="container-fluid">
    <div class="d-flex justify-content-between mb-4">
        <h3><i class="fas fa-tags me-2"></i>Manage Categories</h3>
        <a href="add_category.php" class="btn btn-primary">
            <i class="fas fa-plus-circle me-2"></i>Add New Category
        </a>
    </div>

    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($cat = $categories->fetch_assoc()): ?>
                        <tr id="category-row-<?= $cat['id']; ?>">
                            <td><?= $cat['id']; ?></td>
                            <td><?= htmlspecialchars($cat['name']); ?></td>
                            <td><?= date('M d, Y H:i', strtotime($cat['created_at'])); ?></td>
                            <td>
                                <?php if ($cat['name'] !== 'All Items'): ?>
                                    <a href="edit_category.php?id=<?= $cat['id']; ?>" class="btn btn-sm btn-warning me-2">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <button class="btn btn-sm btn-danger"
                                        onclick="deleteCategory(<?= $cat['id']; ?>, '<?= addslashes($cat['name']); ?>')">
                                        <i class="fas fa-trash-alt"></i> Delete
                                    </button>
                                <?php else: ?>
                                    <span class="badge bg-secondary">System Category</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- 🔥 YOUR ORIGINAL JS – UNCHANGED -->
<script>
function deleteCategory(id, name) {
    Swal.fire({
        title: 'Delete Category',
        text: 'This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        confirmButtonText: 'Delete'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'manage_categories.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    delete_category: true,
                    category_id: id
                },
                success: function(response) {
                    if (response.success) {
                        document.getElementById('category-row-' + id).remove();
                        Swal.fire('Deleted!', response.message, 'success');
                    } else {
                        Swal.fire('Error!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('Server Error', 'Please try again later', 'error');
                }
            });
        }
    });
}
</script>

</body>
</html>
