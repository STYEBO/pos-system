<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Get user role from database
$username = $_SESSION['username'];
$query = "SELECT role FROM users WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_data = $result->fetch_assoc();
    $user_role = $user_data['role'];
    $_SESSION['role'] = $user_role;
} else {
    $user_role = 'cashier';
    $_SESSION['role'] = $user_role;
}
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token'])) {
    // Verify CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $response = ['success' => false, 'message' => 'Invalid CSRF token'];
        echo json_encode($response);
        exit;
    }
    
    $response = ['success' => false, 'message' => ''];
    
    $name = trim($_POST['name'] ?? '');
    
    if (empty($name)) {
        $response['message'] = 'Category name is required';
        echo json_encode($response);
        exit;
    }
    
    // Validate input length
    if (strlen($name) > 100) {
        $response['message'] = 'Category name is too long (max 100 characters)';
        echo json_encode($response);
        exit;
    }
    
    // Validate input contains only allowed characters
    if (!preg_match('/^[a-zA-Z0-9\s\-_&]+$/', $name)) {
        $response['message'] = 'Category name contains invalid characters';
        echo json_encode($response);
        exit;
    }
    
    try {
        // Check if category already exists (case-insensitive)
        $checkStmt = $conn->prepare("SELECT id FROM categories WHERE LOWER(name) = LOWER(?)");
        $checkStmt->bind_param("s", $name);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows > 0) {
            $response['message'] = 'Category already exists';
            echo json_encode($response);
            exit;
        }
        
        // Insert new category
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Category added successfully';
            $response['id'] = $stmt->insert_id;
            $response['name'] = htmlspecialchars($name);
        } else {
            $response['message'] = 'Failed to add category';
        }
        
        $stmt->close();
        $checkStmt->close();
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}

// Get existing categories for display
$categories = [];
try {
    $categoryQuery = "SELECT id, name FROM categories ORDER BY name ASC";
    $categoryResult = $conn->query($categoryQuery);
    if ($categoryResult) {
        while ($row = $categoryResult->fetch_assoc()) {
            $categories[] = $row;
        }
    }
} catch (Exception $e) {
    // Silently fail - categories will be loaded via AJAX
}

// Don't close connection yet as we need it for header.php
include("header.php");
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category - QEloERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --header-bg: #001f3f;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
            --admin-color: #28a745;
            --cashier-color: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            background: white;
            margin-bottom: 20px;
        }
        
        .card-header {
            background: #001f3f;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .form-control:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 0.25rem rgba(40,167,69,.25);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            color: white;
            border: none;
        }
        
        .btn-success:hover {
            background: linear-gradient(135deg, #218838 0%, #1c7430 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40,167,69,0.3);
            color: white;
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d 0%, #545b62 100%);
            color: white;
            border: none;
        }
        
        .btn-secondary:hover {
            background: linear-gradient(135deg, #5a6268 0%, #484e53 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108,117,125,0.3);
            color: white;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(0,0,0,0.03);
        }
        
        /* Success Modal Styles */
        .success-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }
        
        .success-modal-content {
            background: white;
            border-radius: 10px;
            max-width: 400px;
            width: 90%;
            padding: 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            animation: modalAppear 0.5s ease-out;
        }
        
        @keyframes modalAppear {
            from {
                opacity: 0;
                transform: translateY(-50px) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        .success-icon {
            font-size: 80px;
            color: #28a745;
            margin-bottom: 20px;
        }
        
        .success-title {
            color: #28a745;
            margin-bottom: 15px;
        }
        
        .success-message {
            margin-bottom: 25px;
            color: #666;
        }
        
        .countdown {
            font-size: 14px;
            color: #999;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <!-- Success Modal -->
    <div id="successModal" class="success-modal">
        <div class="success-modal-content">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3 class="success-title">Success!</h3>
            <div class="success-message" id="successMessage">
                Category has been added successfully.
            </div>
            <p class="countdown">
                Redirecting to dashboard in <span id="countdown">5</span> seconds...
            </p>
            <button id="redirectNow" class="btn btn-success">
                <i class="fas fa-arrow-right me-2"></i> Go to Dashboard Now
            </button>
        </div>
    </div>
 </br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <!-- Add Category Card -->
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">
                            <i class="fas fa-tags me-2"></i> Add New Category
                        </h4>
                    </div>
                    <div class="card-body p-4">
                        <form id="addCategoryForm">
                            <!-- CSRF Token -->
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            
                            <div class="mb-4">
                                <label for="categoryName" class="form-label fw-bold">
                                    <i class="fas fa-tag me-2"></i>Category Name
                                </label>
                                <input type="text" 
                                       class="form-control form-control-lg" 
                                       id="categoryName" 
                                       name="name"
                                       placeholder="Enter category name"
                                       required
                                       maxlength="100"
                                       pattern="[a-zA-Z0-9\s\-_&]+"
                                       title="Only letters, numbers, spaces, hyphens, underscores, and ampersands are allowed">
                                <div class="form-text mt-2">
                                    Enter a unique category name (e.g., Electronics, Clothing, Food)
                                </div>
                                <div class="invalid-feedback" id="categoryNameFeedback">
                                    Please enter a valid category name.
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="button" class="btn btn-secondary me-md-2" onclick="window.location.href='dashboard.php'">
                                    <i class="fas fa-times me-1"></i> Cancel
                                </button>
                                <button type="submit" class="btn btn-success" id="submitBtn">
                                    <i class="fas fa-plus me-1"></i> Add Category
                                </button>
                            </div>
                        </form>
                        
                        <div id="message" class="mt-4"></div>
                    </div>
                </div>
                
                <!-- Existing Categories List -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i> Existing Categories
                        </h5>
                        <button class="btn btn-sm btn-outline-primary" onclick="loadCategories()">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                    <div class="card-body p-3">
                        <div class="table-responsive">
                            <table class="table table-hover table-sm">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Category Name</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="categoriesList">
                                    <?php if (empty($categories)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-muted py-3">
                                            <i class="fas fa-inbox me-2"></i>No categories found. Add your first category!
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($categories as $category): ?>
                                        <tr>
                                            <td><?php echo $category['id']; ?></td>
                                            <td><strong><?php echo htmlspecialchars($category['name']); ?></strong></td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-danger" 
                                                        onclick="deleteCategory(<?php echo $category['id']; ?>, '<?php echo htmlspecialchars(addslashes($category['name'])); ?>')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Handle form submission
        $('#addCategoryForm').on('submit', function(e) {
            e.preventDefault();
            
            const formData = $(this).serialize();
            const button = $('#submitBtn');
            const originalText = button.html();
            const categoryName = $('#categoryName').val().trim();
            
            // Client-side validation
            if (!categoryName) {
                showValidationError('Category name is required');
                return;
            }
            
            if (!/^[a-zA-Z0-9\s\-_&]+$/.test(categoryName)) {
                showValidationError('Only letters, numbers, spaces, hyphens, underscores, and ampersands are allowed');
                return;
            }
            
            button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i> Adding...');
            $('#message').removeClass('alert-success alert-danger').html('');
            
            $.ajax({
                url: 'add_category.php',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show success modal with message
                        showSuccessModal(response.message, response.name, response.id);
                        
                        // Reset form and reload categories list
                        $('#addCategoryForm')[0].reset();
                        loadCategories();
                    } else {
                        $('#message').addClass('alert alert-danger').html(`
                            <div class="d-flex align-items-center">
                                <i class="fas fa-exclamation-circle fa-2x me-3"></i>
                                <div>
                                    <h5 class="mb-1">Error!</h5>
                                    <p class="mb-0">${response.message}</p>
                                </div>
                            </div>
                        `);
                    }
                },
                error: function(xhr, status, error) {
                    $('#message').addClass('alert alert-danger').html(`
                        <div class="d-flex align-items-center">
                            <i class="fas fa-exclamation-triangle fa-2x me-3"></i>
                            <div>
                                <h5 class="mb-1">Network Error!</h5>
                                <p class="mb-0">Please check your connection and try again.</p>
                            </div>
                        </div>
                    `);
                    console.error('AJAX Error:', error);
                },
                complete: function() {
                    button.prop('disabled', false).html(originalText);
                }
            });
        });
        
        // Show success modal and start countdown
        function showSuccessModal(message, categoryName, categoryId) {
            const modal = $('#successModal');
            const successMessage = $('#successMessage');
            
            // Set success message
            successMessage.html(`
                <strong>${message}</strong><br><br>
                <strong>Category Name:</strong> ${escapeHtml(categoryName)}<br>
                <strong>Category ID:</strong> ${categoryId}
            `);
            
            // Show modal
            modal.css('display', 'flex');
            
            // Start countdown
            let countdown = 5;
            const countdownElement = $('#countdown');
            countdownElement.text(countdown);
            
            const countdownInterval = setInterval(function() {
                countdown--;
                countdownElement.text(countdown);
                
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    redirectToDashboard();
                }
            }, 1000);
            
            // Store interval ID to clear if user clicks manually
            modal.data('countdownInterval', countdownInterval);
        }
        
        // Redirect to dashboard
        function redirectToDashboard() {
            window.location.href = 'dashboard.php';
        }
        
        // Handle immediate redirect button
        $('#redirectNow').on('click', function() {
            const modal = $('#successModal');
            const countdownInterval = modal.data('countdownInterval');
            
            if (countdownInterval) {
                clearInterval(countdownInterval);
            }
            
            redirectToDashboard();
        });
        
        // Load existing categories via AJAX
        function loadCategories() {
            $.ajax({
                url: 'get_categories.php',
                method: 'GET',
                dataType: 'json',
                success: function(categories) {
                    const tbody = $('#categoriesList');
                    tbody.empty();
                    
                    if (!categories || categories.length === 0) {
                        tbody.html(`
                            <tr>
                                <td colspan="3" class="text-center text-muted py-3">
                                    <i class="fas fa-inbox me-2"></i>No categories found
                                </td>
                            </tr>
                        `);
                        return;
                    }
                    
                    categories.forEach(category => {
                        const safeName = escapeHtml(category.name);
                        tbody.append(`
                            <tr>
                                <td>${category.id}</td>
                                <td><strong>${safeName}</strong></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger" 
                                            onclick="deleteCategory(${category.id}, '${safeName.replace(/'/g, "\\'")}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `);
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Error loading categories:', error);
                    $('#categoriesList').html(`
                        <tr>
                            <td colspan="3" class="text-center text-danger py-3">
                                <i class="fas fa-exclamation-triangle me-2"></i>Failed to load categories
                            </td>
                        </tr>
                    `);
                }
            });
        }
        
        // Delete category function
        function deleteCategory(id, name) {
            if (confirm(`Are you sure you want to delete category "${name}"?`)) {
                $.ajax({
                    url: 'delete_category.php',
                    method: 'POST',
                    data: { 
                        id: id,
                        csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert(response.message);
                            loadCategories();
                        } else {
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Network error. Please try again.');
                    }
                });
            }
        }
        
        // Show validation error
        function showValidationError(message) {
            $('#categoryName').addClass('is-invalid');
            $('#categoryNameFeedback').text(message);
            $('#message').addClass('alert alert-danger').html(`
                <div class="d-flex align-items-center">
                    <i class="fas fa-exclamation-circle fa-2x me-3"></i>
                    <div>
                        <h5 class="mb-1">Validation Error</h5>
                        <p class="mb-0">${message}</p>
                    </div>
                </div>
            `);
            
            setTimeout(() => {
                $('#categoryName').removeClass('is-invalid');
            }, 3000);
        }
        
        // Escape HTML to prevent XSS
        function escapeHtml(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) { return map[m]; });
        }
    </script>
</body>
</html>