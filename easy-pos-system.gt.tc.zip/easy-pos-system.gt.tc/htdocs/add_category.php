<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Get user role from database
$username = $_SESSION['username'];
$query = "SELECT role FROM users WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_data = $result->fetch_assoc();
    $user_role = $user_data['role'];
    $_SESSION['role'] = $user_role;
} else {
    $user_role = 'cashier';
    $_SESSION['role'] = $user_role;
}
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token'])) {
    // Verify CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $response = ['success' => false, 'message' => 'Invalid CSRF token'];
        echo json_encode($response);
        exit;
    }
    
    $response = ['success' => false, 'message' => ''];
    
    $name = trim($_POST['name'] ?? '');
    
    if (empty($name)) {
        $response['message'] = 'Category name is required';
        echo json_encode($response);
        exit;
    }
    
    // Validate input length
    if (strlen($name) > 100) {
        $response['message'] = 'Category name is too long (max 100 characters)';
        echo json_encode($response);
        exit;
    }
    
    // Validate input contains only allowed characters
    if (!preg_match('/^[a-zA-Z0-9\s\-_&]+$/', $name)) {
        $response['message'] = 'Category name contains invalid characters';
        echo json_encode($response);
        exit;
    }
    
    try {
        // Check if category already exists (case-insensitive)
        $checkStmt = $conn->prepare("SELECT id FROM categories WHERE LOWER(name) = LOWER(?)");
        $checkStmt->bind_param("s", $name);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows > 0) {
            $response['message'] = 'Category already exists';
            echo json_encode($response);
            exit;
        }
        
        // Insert new category
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Category added successfully';
            $response['id'] = $stmt->insert_id;
            $response['name'] = htmlspecialchars($name);
        } else {
            $response['message'] = 'Failed to add category';
        }
        
        $stmt->close();
        $checkStmt->close();
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}

// Get existing categories for display
$categories = [];
try {
    $categoryQuery = "SELECT id, name FROM categories ORDER BY name ASC";
    $categoryResult = $conn->query($categoryQuery);
    if ($categoryResult) {
        while ($row = $categoryResult->fetch_assoc()) {
            $categories[] = $row;
        }
    }
} catch (Exception $e) {
    // Silently fail - categories will be loaded via AJAX
}

// Don't close connection yet as we need it for header.php
include("header.php");
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category - QEloERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --header-bg: #001f3f;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
            --admin-color: #28a745;
            --cashier-color: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            background: white;
            margin-bottom: 20px;
        }
        
        .card-header {
            background: #001f3f;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .form-control:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 0.25rem rgba(40,167,69,.25);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            color: white;
            border: none;
        }
        
        .btn-success:hover {
            background: linear-gradient(135deg, #218838 0%, #1c7430 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40,167,69,0.3);
            color: white;
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d 0%, #545b62 100%);
            color: white;
            border: none;
        }
        
        .btn-secondary:hover {
            background: linear-gradient(135deg, #5a6268 0%, #484e53 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108,117,125,0.3);
            color: white;
        }
        
        .table-hover tbody tr:hover {
            background-color: rgba(0,0,0,0.03);
        }
        
        /* Toast Notification Styles */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
        }
        
        .toast {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            overflow: hidden;
            max-width: 350px;
            animation: slideInRight 0.3s ease-out;
        }
        
        .toast-success {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            color: white;
            border-left: 4px solid #155724;
        }
        
        .toast-error {
            background: linear-gradient(135deg, #dc3545 0%, #bd2130 100%);
            color: white;
            border-left: 4px solid #721c24;
        }
        
        .toast-header {
            background: rgba(0,0,0,0.1);
            border-bottom: 1px solid rgba(255,255,255,0.1);
            color: white;
        }
        
        .toast-body {
            padding: 15px;
        }
        
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
        
        /* Success Badge */
        .success-badge {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 50px;
            box-shadow: 0 5px 15px rgba(40,167,69,0.3);
            z-index: 1000;
            display: none;
            align-items: center;
            animation: fadeInUp 0.5s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Pulse animation for new categories */
        .new-category {
            animation: pulse 2s ease-in-out;
        }
        
        @keyframes pulse {
            0% { background-color: transparent; }
            50% { background-color: rgba(40,167,69,0.1); }
            100% { background-color: transparent; }
        }
    </style>
</head>
<body>
    </br>
    <!-- Toast Container -->
    <div class="toast-container"></div>
    
    <!-- Success Badge -->
    <div class="success-badge" id="successBadge">
        <i class="fas fa-check-circle me-2"></i>
        <span id="badgeMessage">Category added successfully!</span>
    </div>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <!-- Add Category Card -->
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">
                            <i class="fas fa-tags me-2"></i> Add New Category
                        </h4>
                    </div>
                    <div class="card-body p-4">
                        <form id="addCategoryForm">
                            <!-- CSRF Token -->
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            
                            <div class="mb-4">
                                <label for="categoryName" class="form-label fw-bold">
                                    <i class="fas fa-tag me-2"></i>Category Name
                                </label>
                                <input type="text" 
                                       class="form-control form-control-lg" 
                                       id="categoryName" 
                                       name="name"
                                       placeholder="Enter category name"
                                       required
                                       maxlength="100"
                                       pattern="[a-zA-Z0-9\s\-_&]+"
                                       title="Only letters, numbers, spaces, hyphens, underscores, and ampersands are allowed">
                                <div class="form-text mt-2">
                                    Enter a unique category name (e.g., Electronics, Clothing, Food)
                                </div>
                                <div class="invalid-feedback" id="categoryNameFeedback">
                                    Please enter a valid category name.
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="button" class="btn btn-secondary me-md-2" onclick="window.location.href='dashboard.php'">
                                    <i class="fas fa-times me-1"></i> Cancel
                                </button>
                                <button type="submit" class="btn btn-success" id="submitBtn">
                                    <i class="fas fa-plus me-1"></i> Add Category
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Existing Categories List -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i> Existing Categories
                        </h5>
                        <div>
                            <span class="badge bg-info me-2" id="categoryCount">
                                <?php echo count($categories); ?> Categories
                            </span>
                            <button class="btn btn-sm btn-outline-primary" id="refreshBtn">
                                <i class="fas fa-sync-alt"></i> Refresh
                            </button>
                        </div>
                    </div>
                    <div class="card-body p-3">
                        <div class="table-responsive">
                            <table class="table table-hover table-sm">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Category Name</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="categoriesList">
                                    <?php if (empty($categories)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-muted py-3">
                                            <i class="fas fa-inbox me-2"></i>No categories found. Add your first category!
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($categories as $category): ?>
                                        <tr>
                                            <td><?php echo $category['id']; ?></td>
                                            <td><strong><?php echo htmlspecialchars($category['name']); ?></strong></td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-danger" 
                                                        onclick="deleteCategory(<?php echo $category['id']; ?>, '<?php echo htmlspecialchars(addslashes($category['name'])); ?>')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Show toast notification
        function showToast(message, type = 'success') {
            const toastId = 'toast-' + Date.now();
            const toast = $(`
                <div class="toast toast-${type}" id="${toastId}" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header">
                        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'} me-2"></i>
                        <strong class="me-auto">${type === 'success' ? 'Success' : 'Error'}</strong>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                    <div class="toast-body">
                        ${message}
                    </div>
                </div>
            `);
            
            $('.toast-container').append(toast);
            
            // Initialize and show the toast
            const bsToast = new bootstrap.Toast(toast[0], {
                autohide: true,
                delay: 3000
            });
            bsToast.show();
            
            // Remove from DOM after hiding
            toast.on('hidden.bs.toast', function() {
                $(this).remove();
            });
        }
        
        // Show success badge
        function showSuccessBadge(message) {
            const badge = $('#successBadge');
            $('#badgeMessage').text(message);
            badge.css('display', 'flex');
            
            // Hide after 3 seconds
            setTimeout(() => {
                badge.css('display', 'none');
            }, 3000);
        }
        
        // Handle form submission
        $('#addCategoryForm').on('submit', function(e) {
            e.preventDefault();
            
            const formData = $(this).serialize();
            const button = $('#submitBtn');
            const originalText = button.html();
            const categoryName = $('#categoryName').val().trim();
            
            // Client-side validation
            if (!categoryName) {
                showToast('Category name is required', 'error');
                $('#categoryName').addClass('is-invalid');
                return;
            }
            
            if (!/^[a-zA-Z0-9\s\-_&]+$/.test(categoryName)) {
                showToast('Only letters, numbers, spaces, hyphens, underscores, and ampersands are allowed', 'error');
                $('#categoryName').addClass('is-invalid');
                return;
            }
            
            button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i> Adding...');
            
            $.ajax({
                url: 'add_category.php',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show success toast
                        showToast(response.message);
                        
                        // Show success badge
                        showSuccessBadge(`Added: ${response.name}`);
                        
                        // Reset form
                        $('#addCategoryForm')[0].reset();
                        $('#categoryName').removeClass('is-invalid');
                        
                        // Load updated categories
                        loadCategories();
                        
                        // Highlight new category
                        highlightNewCategory(response.id);
                    } else {
                        showToast(response.message, 'error');
                        $('#categoryName').addClass('is-invalid');
                    }
                },
                error: function(xhr, status, error) {
                    showToast('Network error. Please try again.', 'error');
                    console.error('AJAX Error:', error);
                },
                complete: function() {
                    button.prop('disabled', false).html(originalText);
                }
            });
        });
        
        // Highlight newly added category
        function highlightNewCategory(categoryId) {
            // Add class to highlight the row
            setTimeout(() => {
                $(`#categoriesList tr`).each(function() {
                    const firstCell = $(this).find('td:first-child');
                    if (firstCell.text() == categoryId) {
                        $(this).addClass('new-category');
                        
                        // Remove highlight after animation
                        setTimeout(() => {
                            $(this).removeClass('new-category');
                        }, 2000);
                    }
                });
            }, 500); // Wait for categories to load
        }
        
        // Load existing categories via AJAX
        function loadCategories() {
            $.ajax({
                url: 'get_categories.php',
                method: 'GET',
                dataType: 'json',
                success: function(categories) {
                    const tbody = $('#categoriesList');
                    tbody.empty();
                    
                    if (!categories || categories.length === 0) {
                        tbody.html(`
                            <tr>
                                <td colspan="3" class="text-center text-muted py-3">
                                    <i class="fas fa-inbox me-2"></i>No categories found
                                </td>
                            </tr>
                        `);
                        updateCategoryCount(0);
                        return;
                    }
                    
                    categories.forEach(category => {
                        const safeName = escapeHtml(category.name);
                        tbody.append(`
                            <tr>
                                <td>${category.id}</td>
                                <td><strong>${safeName}</strong></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger" 
                                            onclick="deleteCategory(${category.id}, '${safeName.replace(/'/g, "\\'")}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `);
                    });
                    
                    updateCategoryCount(categories.length);
                    
                    // Show refresh success message
                    showToast(`Categories loaded: ${categories.length} items found`, 'success');
                },
                error: function(xhr, status, error) {
                    console.error('Error loading categories:', error);
                    showToast('Failed to load categories', 'error');
                }
            });
        }
        
        // Update category count badge
        function updateCategoryCount(count) {
            $('#categoryCount').text(`${count} Categories`);
        }
        
        // Delete category function
        function deleteCategory(id, name) {
            if (confirm(`Are you sure you want to delete category "${name}"?`)) {
                $.ajax({
                    url: 'delete_category.php',
                    method: 'POST',
                    data: { 
                        id: id,
                        csrf_token: '<?php echo $_SESSION['csrf_token']; ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            showToast(response.message);
                            showSuccessBadge(`Deleted: ${name}`);
                            loadCategories();
                        } else {
                            showToast('Error: ' + response.message, 'error');
                        }
                    },
                    error: function(xhr, status, error) {
                        showToast('Network error. Please try again.', 'error');
                    }
                });
            }
        }
        
        // Escape HTML to prevent XSS
        function escapeHtml(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) { return map[m]; });
        }
        
        // Auto-refresh categories every 30 seconds
        let autoRefreshInterval;
        
        function startAutoRefresh() {
            // Clear existing interval
            if (autoRefreshInterval) {
                clearInterval(autoRefreshInterval);
            }
            
            // Set interval for auto-refresh (every 30 seconds)
            autoRefreshInterval = setInterval(() => {
                loadCategories();
            }, 30000);
        }
        
        // Stop auto-refresh
        function stopAutoRefresh() {
            if (autoRefreshInterval) {
                clearInterval(autoRefreshInterval);
                autoRefreshInterval = null;
            }
        }
        
        // Handle page visibility changes
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                stopAutoRefresh();
            } else {
                startAutoRefresh();
            }
        });
        
        // Initialize when page loads
        $(document).ready(function() {
            // Start auto-refresh
            startAutoRefresh();
            
            // Setup refresh button
            $('#refreshBtn').click(function() {
                const icon = $(this).find('i');
                icon.addClass('fa-spin');
                loadCategories();
                
                // Remove spin class after 1 second
                setTimeout(() => {
                    icon.removeClass('fa-spin');
                }, 1000);
            });
            
            // Remove invalid class when user starts typing
            $('#categoryName').on('input', function() {
                $(this).removeClass('is-invalid');
            });
            
            // Initial load
            loadCategories();
        });
    </script>
</body>
</html>