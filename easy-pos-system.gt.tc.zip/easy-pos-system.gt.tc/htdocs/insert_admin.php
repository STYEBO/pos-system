<?php
// insert_admin.php
include "db.php";

// Admin credentials
$admin_username = "admin";
$admin_password = "admin123"; // Change this!
$admin_role = "admin";

// Hash the password
$hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

// Check if admin exists
$check_sql = "SELECT id FROM users WHERE username = '$admin_username'";
$result = $conn->query($check_sql);

if ($result->num_rows > 0) {
    echo "Admin account already exists!<br>";
    echo "Username: admin<br>";
    echo "To reset password, run: UPDATE users SET password = '" . password_hash('new_password', PASSWORD_DEFAULT) . "' WHERE username = 'admin';";
} else {
    // Insert admin
    $sql = "INSERT INTO users (username, password, role) 
            VALUES ('$admin_username', '$hashed_password', '$admin_role')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Admin account created successfully!<br><br>";
        echo "================================<br>";
        echo "ADMIN LOGIN DETAILS:<br>";
        echo "================================<br>";
        echo "Username: <strong>admin</strong><br>";
        echo "Password: <strong>$admin_password</strong><br>";
        echo "================================<br><br>";
        echo "⚠️ IMPORTANT: Change this password immediately after login!";
    } else {
        echo "Error creating admin: " . $conn->error;
    }
}

$conn->close();
?>