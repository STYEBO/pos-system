<?php
// debug_login.php - Test login directly
session_start();
include "db.php";

echo "<h2>Login Debug Tool</h2>";

// Test the exact credentials you're using
$test_username = "admin";
$test_password = "admin123";

echo "<p>Testing login for: <strong>$test_username</strong> / <strong>$test_password</strong></p>";

// Check if user exists
$stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
$stmt->bind_param("s", $test_username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "<p style='color:red'>❌ User '$test_username' NOT FOUND in database!</p>";
    
    // Show all users in database
    echo "<h3>All users in database:</h3>";
    $all_users = $conn->query("SELECT id, username, role FROM users");
    if ($all_users->num_rows > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Username</th><th>Role</th></tr>";
        while($row = $all_users->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['username'] . "</td>";
            echo "<td>" . $row['role'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color:red'>❌ No users in database at all!</p>";
    }
} else {
    $stmt->bind_result($user_id, $db_username, $db_password, $db_role);
    $stmt->fetch();
    
    echo "<p style='color:green'>✅ User found in database!</p>";
    echo "<p>Database Password Hash: " . substr($db_password, 0, 30) . "...</p>";
    
    // Test password verification
    if (password_verify($test_password, $db_password)) {
        echo "<p style='color:green'>✅ Password verification SUCCESSFUL!</p>";
        echo "<p>User would be logged in as: $db_role</p>";
        
        // Test setting session
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $db_username;
        $_SESSION['role'] = $db_role;
        
        echo "<p>Session set successfully:</p>";
        echo "<pre>";
        print_r($_SESSION);
        echo "</pre>";
        
        echo "<p><a href='dashboard.php'>Go to Dashboard</a></p>";
    } else {
        echo "<p style='color:red'>❌ Password verification FAILED!</p>";
        echo "<p>The stored password hash doesn't match 'admin123'</p>";
        
        // Reset the password
        $new_hash = password_hash($test_password, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
        $update->bind_param("ss", $new_hash, $test_username);
        if ($update->execute()) {
            echo "<p style='color:green'>✅ Password reset to 'admin123'</p>";
            echo "<p>New hash: " . substr($new_hash, 0, 30) . "...</p>";
        }
    }
}

$stmt->close();
$conn->close();
?>