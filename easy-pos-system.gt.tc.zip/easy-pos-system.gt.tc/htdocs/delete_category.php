<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id'] ?? 0);
    
    if ($id <= 0) {
        $response['message'] = 'Invalid category ID';
        echo json_encode($response);
        exit;
    }
    
    try {
        // Check if category exists
        $checkStmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
        $checkStmt->bind_param("i", $id);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        
        if ($checkResult->num_rows === 0) {
            $response['message'] = 'Category not found';
            echo json_encode($response);
            exit;
        }
        
        // Check if category has products
        $productCheck = $conn->prepare("SELECT COUNT(*) as product_count FROM products WHERE category_id = ?");
        $productCheck->bind_param("i", $id);
        $productCheck->execute();
        $productResult = $productCheck->get_result()->fetch_assoc();
        
        if ($productResult['product_count'] > 0) {
            $response['message'] = 'Cannot delete category with existing products. Please reassign or delete products first.';
            echo json_encode($response);
            exit;
        }
        
        // Delete category
        $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Category deleted successfully';
        } else {
            $response['message'] = 'Failed to delete category: ' . $conn->error;
        }
        
        $stmt->close();
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
    }
}

echo json_encode($response);
$conn->close();
?>