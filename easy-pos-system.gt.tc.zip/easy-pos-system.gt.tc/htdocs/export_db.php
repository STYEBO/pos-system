<?php
// export_db.php
// Author: ChatGPT
// Purpose: Export full MySQL database as a .sql file

// Database credentials
$host = "sql105.infinityfree.com";
$user = "if0_40929186";
$pass = "nIEej2teqP";
$db   = "if0_40929186_pos_system";

// Backup filename
$backupFile = $db . '_backup_' . date("Y-m-d_H-i-s") . '.sql';

// Set headers for download
header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . $backupFile . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Connect to database
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("-- ERROR: Connection failed: " . $conn->connect_error);
}

// Get all tables
$tables = [];
$result = $conn->query("SHOW TABLES");
while ($row = $result->fetch_array()) {
    $tables[] = $row[0];
}

// Start backup output
echo "-- Database Backup: $db\n";
echo "-- Generated: " . date("Y-m-d H:i:s") . "\n\n";

foreach ($tables as $table) {
    // Table structure
    $createResult = $conn->query("SHOW CREATE TABLE `$table`");
    $createRow = $createResult->fetch_assoc();
    echo "-- Table structure for `$table`\n";
    echo $createRow['Create Table'] . ";\n\n";

    // Table data
    $dataResult = $conn->query("SELECT * FROM `$table`");
    if ($dataResult->num_rows > 0) {
        echo "-- Dumping data for table `$table`\n";
        while ($row = $dataResult->fetch_assoc()) {
            $columns = array_map(fn($col) => "`$col`", array_keys($row));
            $values = array_map(fn($val) => isset($val) ? "'" . $conn->real_escape_string($val) . "'" : "NULL", array_values($row));
            echo "INSERT INTO `$table` (" . implode(", ", $columns) . ") VALUES (" . implode(", ", $values) . ");\n";
        }
        echo "\n";
    }
}

$conn->close();
exit();
?>
