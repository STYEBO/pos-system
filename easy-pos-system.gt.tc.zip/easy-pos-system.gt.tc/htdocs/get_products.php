<?php
// get_products.php
require_once 'db.php';

header('Content-Type: application/json');

try {
    // Fetch ALL products including out-of-stock items
    // The filtering will be done in JavaScript
    $sql = "SELECT p.*, 
                   COALESCE(p.unit, 'pcs') as unit,
                   c.name as category_name 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            ORDER BY p.name";
    
    $result = $conn->query($sql);
    
    $products = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
    }
    
    echo json_encode($products);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

$conn->close();
?>