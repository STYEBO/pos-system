<?php
// get_products.php
require_once 'db.php';

header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $sql = "SELECT p.*, 
                   COALESCE(p.unit, 'pcs') as unit,
                   c.name as category_name,
                   c.id as category_id
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            ORDER BY p.name";
    
    $result = $conn->query($sql);
    
    $products = [];
    $image_dir = 'product_images/';
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            // Clean image path
            if (!empty($row['image'])) {
                // Remove any directory path, keep only filename
                $row['image'] = basename($row['image']);
                
                // Remove query strings if any
                $row['image'] = explode('?', $row['image'])[0];
                
                // Trim whitespace
                $row['image'] = trim($row['image']);
                
                // Check if file actually exists
                $image_path = $image_dir . $row['image'];
                if (!file_exists($image_path)) {
                    error_log("Image file not found: " . $image_path);
                    // Keep the image name but frontend will show placeholder
                }
            } else {
                $row['image'] = null;
            }
            
            // Ensure all required fields exist
            $row['description'] = $row['description'] ?? '';
            $row['discount_percent'] = $row['discount_percent'] ?? 0;
            $row['is_new'] = $row['is_new'] ?? 0;
            
            // Convert numeric fields
            $row['price'] = floatval($row['price']);
            $row['quantity'] = floatval($row['quantity']);
            $row['min_stock'] = intval($row['min_stock']);
            
            $products[] = $row;
        }
    }
    
    // Return products
    echo json_encode($products);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}

$conn->close();
?>