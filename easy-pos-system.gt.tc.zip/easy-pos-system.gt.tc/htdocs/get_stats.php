
<?php
session_start();
require_once '../db.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// Get sales count
$sales_result = $conn->query("SELECT COUNT(*) as count FROM sales");
$sales_count = $sales_result->fetch_assoc()['count'];

// Get products count
$products_result = $conn->query("SELECT COUNT(*) as count FROM products");
$products_count = $products_result->fetch_assoc()['count'];

// Get customers count
$customers_result = $conn->query("SELECT COUNT(*) as count FROM customers");
$customers_count = $customers_result->fetch_assoc()['count'];

// Get database size (approximate)
$db_size_result = $conn->query("
    SELECT SUM(data_length + index_length) / 1024 AS size_kb 
    FROM information_schema.tables 
    WHERE table_schema = 'if0_40929186_pos_system'
");
$db_size = $db_size_result->fetch_assoc()['size_kb'] ?? 0;
$db_size = round($db_size, 2);

// Return JSON response
header('Content-Type: application/json');
echo json_encode([
    'sales_count' => (int)$sales_count,
    'products_count' => (int)$products_count,
    'customers_count' => (int)$customers_count,
    'db_size' => $db_size
]);
