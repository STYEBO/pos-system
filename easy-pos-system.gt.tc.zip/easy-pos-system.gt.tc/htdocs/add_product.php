<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit;
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle AJAX request separately
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
        exit;
    }
    
    $response = ['success' => false, 'message' => ''];
    
    $name = trim($_POST['name'] ?? '');
    $barcode = trim($_POST['barcode'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 0);
    $unit = trim($_POST['unit'] ?? 'pcs');
    $min_stock = intval($_POST['min_stock'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    
    // Validation
    if (empty($name)) {
        $response['message'] = 'Product name is required';
        echo json_encode($response);
        exit;
    }
    
    // Validate name length
    if (strlen($name) > 255) {
        $response['message'] = 'Product name is too long';
        echo json_encode($response);
        exit;
    }
    
    if ($price <= 0) {
        $response['message'] = 'Price must be greater than 0';
        echo json_encode($response);
        exit;
    }
    
    // Validate price range
    if ($price > 999999.99) {
        $response['message'] = 'Price is too high';
        echo json_encode($response);
        exit;
    }
    
    // Validate unit
    $allowed_units = ['pcs', 'kg', 'g', 'liter', 'ml', 'pack', 'box', 'bottle', 'dozen', 'carton'];
    if (!in_array($unit, $allowed_units)) {
        $response['message'] = 'Invalid unit selected';
        echo json_encode($response);
        exit;
    }
    
    if ($quantity < 0) {
        $response['message'] = 'Quantity cannot be negative';
        echo json_encode($response);
        exit;
    }
    
    if ($min_stock < 0) {
        $response['message'] = 'Minimum stock cannot be negative';
        echo json_encode($response);
        exit;
    }
    
    try {
        // Validate category exists
        $checkCat = $conn->prepare("SELECT id FROM categories WHERE id = ?");
        $checkCat->bind_param("i", $category_id);
        $checkCat->execute();
        $catResult = $checkCat->get_result();
        if ($catResult->num_rows === 0) {
            $response['message'] = 'Invalid category';
            echo json_encode($response);
            exit;
        }
        $checkCat->close();
        
        // Handle image upload
        $image_path = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/products/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if (in_array($file_ext, $allowed_ext)) {
                // Validate MIME type
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime_type = finfo_file($finfo, $_FILES['image']['tmp_name']);
                finfo_close($finfo);
                
                $allowed_mimes = [
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/gif' => 'gif',
                    'image/webp' => 'webp'
                ];
                
                if (!array_key_exists($mime_type, $allowed_mimes) || $allowed_mimes[$mime_type] !== $file_ext) {
                    $response['message'] = 'Invalid file type or extension mismatch';
                    echo json_encode($response);
                    exit;
                }
                
                // Validate file size (5MB max)
                if ($_FILES['image']['size'] > 5 * 1024 * 1024) {
                    $response['message'] = 'File too large. Max 5MB allowed.';
                    echo json_encode($response);
                    exit;
                }
                
                // Sanitize filename
                $original_name = pathinfo($_FILES['image']['name'], PATHINFO_FILENAME);
                $sanitized_name = preg_replace('/[^a-zA-Z0-9_-]/', '', $original_name);
                $filename = $sanitized_name . '_' . uniqid() . '_' . time() . '.' . $file_ext;
                $target_path = $upload_dir . $filename;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
                    $image_path = $target_path;
                }
            } else {
                $response['message'] = 'Invalid file extension. Allowed: jpg, jpeg, png, gif, webp';
                echo json_encode($response);
                exit;
            }
        }
        
        // Check if barcode already exists (if provided)
        if (!empty($barcode)) {
            $checkStmt = $conn->prepare("SELECT id FROM products WHERE barcode = ?");
            $checkStmt->bind_param("s", $barcode);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            
            if ($checkResult->num_rows > 0) {
                $response['message'] = 'Barcode already exists';
                echo json_encode($response);
                exit;
            }
            $checkStmt->close();
        } else {
            // Generate barcode if not provided
            $barcode = 'PRD' . time() . rand(100, 999);
        }
        
        // Insert new product
        $stmt = $conn->prepare("INSERT INTO products (name, barcode, price, quantity, unit, min_stock, image, category_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdissis", $name, $barcode, $price, $quantity, $unit, $min_stock, $image_path, $category_id);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Product added successfully';
            $response['id'] = $stmt->insert_id;
            $response['name'] = $name;
            $response['barcode'] = $barcode;
            $response['price'] = number_format($price, 2);
            $response['quantity'] = $quantity;
            $response['unit'] = $unit;
        } else {
            $response['message'] = 'Failed to add product: ' . $conn->error;
        }
        
        $stmt->close();
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}

// If not POST request, show the form
include ("header.php");

// Get user role from database
$username = $_SESSION['username'];
$query = "SELECT role FROM users WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user_data = $result->fetch_assoc();
    $user_role = $user_data['role'];
    $_SESSION['role'] = $user_role;
} else {
    $user_role = 'cashier';
    $_SESSION['role'] = $user_role;
}
$stmt->close();

// Get categories for dropdown
$categories = [];
$cat_result = $conn->query("SELECT id, name FROM categories ORDER BY name");
if ($cat_result->num_rows > 0) {
    while($row = $cat_result->fetch_assoc()) {
        $categories[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - QEloERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --header-bg: #001f3f;
            --sidebar-bg: #ffffff;
            --border-color: #dee2e6;
            --text-primary: #212529;
            --text-secondary: #6c757d;
            --accent-blue: #007bff;
            --accent-green: #28a745;
            --admin-color: #28a745;
            --cashier-color: #17a2b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            background: white;
            margin-bottom: 20px;
        }
        
        .card-header {
            background: #001f3f;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 0.25rem rgba(40,167,69,.25);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            border: none;
            color: white;
        }
        
        .btn-success:hover {
            background: linear-gradient(135deg, #218838 0%, #1c7430 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40,167,69,0.3);
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d 0%, #545b62 100%);
            border: none;
            color: white;
        }
        
        .btn-secondary:hover {
            background: linear-gradient(135deg, #5a6268 0%, #484e53 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108,117,125,0.3);
        }
        
        .image-preview {
            width: 200px;
            height: 200px;
            border: 2px dashed #ddd;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .image-preview:hover {
            border-color: #28a745;
            background: rgba(40, 167, 69, 0.05);
        }
        
        .image-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
        
        /* Success Modal Styles */
        .success-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }
        
        .success-modal.active {
            display: flex;
        }
        
        .success-modal-content {
            background: white;
            border-radius: 10px;
            max-width: 450px;
            width: 90%;
            padding: 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            animation: modalAppear 0.5s ease-out;
        }
        
        @keyframes modalAppear {
            from {
                opacity: 0;
                transform: translateY(-50px) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        .success-icon {
            font-size: 80px;
            color: #28a745;
            margin-bottom: 20px;
        }
        
        .success-title {
            color: #28a745;
            margin-bottom: 15px;
        }
        
        .success-message {
            margin-bottom: 20px;
            color: #666;
            text-align: left;
        }
        
        .product-details {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: left;
        }
        
        .product-details p {
            margin-bottom: 8px;
            font-size: 14px;
        }
        
        .countdown {
            font-size: 14px;
            color: #999;
            margin-top: 15px;
            margin-bottom: 20px;
        }
        
        .alert {
            border-radius: 8px;
            border: none;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
            color: white;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .card-body {
                padding: 20px !important;
            }
            
            .image-preview {
                width: 150px;
                height: 150px;
            }
        }
        
        .is-invalid {
            border-color: #dc3545 !important;
        }
        
        .invalid-feedback {
            display: block;
            color: #dc3545;
            font-size: 0.875em;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body>
    <!-- Success Modal -->
    <div id="successModal" class="success-modal">
        <div class="success-modal-content">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3 class="success-title">Success!</h3>
            <div class="success-message">
                Product has been added successfully.
            </div>
            <div class="product-details" id="productDetails">
                <!-- Product details will be inserted here -->
            </div>
            <p class="countdown">
                Redirecting to dashboard in <span id="countdown">5</span> seconds...
            </p>
            <button id="redirectNow" class="btn btn-success btn-lg">
                <i class="fas fa-arrow-right me-2"></i> Go to Dashboard Now
            </button>
        </div>
    </div>
    </br>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-xl-10">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">
                            <i class="fas fa-box me-2"></i> Add New Product
                        </h4>
                    </div>
                    <div class="card-body p-4">
                        <form id="addProductForm" enctype="multipart/form-data">
                            <!-- CSRF Token -->
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                            
                            <div class="row">
                                <!-- Left Column -->
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="productName" class="form-label fw-bold">
                                            <i class="fas fa-tag me-2"></i>Product Name *
                                        </label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="productName" 
                                               name="name"
                                               placeholder="Enter product name"
                                               required>
                                        <div class="invalid-feedback" id="nameError"></div>
                                    </div>
                                    
                                    <div class="row mb-4">
                                        <div class="col-md-6">
                                            <label for="barcode" class="form-label fw-bold">
                                                <i class="fas fa-barcode me-2"></i>Barcode
                                            </label>
                                            <input type="text" 
                                                   class="form-control" 
                                                   id="barcode" 
                                                   name="barcode"
                                                   placeholder="Leave blank for auto-generation">
                                            <div class="form-text mt-2">
                                                <small>Leave empty for auto-generation</small>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <label for="price" class="form-label fw-bold">
                                                <i class="fas fa-dollar-sign me-2"></i>Price *
                                            </label>
                                            <input type="number" 
                                                   class="form-control" 
                                                   id="price" 
                                                   name="price"
                                                   step="0.01"
                                                   min="0.01"
                                                   placeholder="0.00"
                                                   required>
                                            <div class="invalid-feedback" id="priceError"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-4">
                                        <div class="col-md-4">
                                            <label for="quantity" class="form-label fw-bold">
                                                <i class="fas fa-boxes me-2"></i>Quantity
                                            </label>
                                            <input type="number" 
                                                   class="form-control" 
                                                   id="quantity" 
                                                   name="quantity"
                                                   min="0"
                                                   value="0"
                                                   placeholder="0">
                                        </div>
                                        
                                        <div class="col-md-4">
                                            <label for="unit" class="form-label fw-bold">
                                                <i class="fas fa-weight me-2"></i>Unit *
                                            </label>
                                            <select class="form-select" id="unit" name="unit" required>
                                                <option value="pcs" selected>Pieces (pcs)</option>
                                                <option value="kg">Kilogram (kg)</option>
                                                <option value="g">Gram (g)</option>
                                                <option value="liter">Liter (L)</option>
                                                <option value="ml">Milliliter (ml)</option>
                                                <option value="pack">Pack</option>
                                                <option value="box">Box</option>
                                                <option value="bottle">Bottle</option>
                                                <option value="dozen">Dozen</option>
                                                <option value="carton">Carton</option>
                                            </select>
                                            <div class="invalid-feedback" id="unitError"></div>
                                        </div>
                                        
                                        <div class="col-md-4">
                                            <label for="min_stock" class="form-label fw-bold">
                                                <i class="fas fa-exclamation-triangle me-2"></i>Min Stock
                                            </label>
                                            <input type="number" 
                                                   class="form-control" 
                                                   id="min_stock" 
                                                   name="min_stock"
                                                   min="0"
                                                   value="5"
                                                   placeholder="Minimum stock level">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="category_id" class="form-label fw-bold">
                                            <i class="fas fa-tags me-2"></i>Category *
                                        </label>
                                        <select class="form-select" id="category_id" name="category_id" required>
                                            <option value="">Select Category</option>
                                            <?php foreach ($categories as $category): ?>
                                                <option value="<?php echo $category['id']; ?>">
                                                    <?php echo htmlspecialchars($category['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback" id="categoryError"></div>
                                        <div class="form-text mt-2">
                                            <a href="add_category.php" class="text-decoration-none">
                                                <i class="fas fa-plus-circle me-1"></i>Add new category
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Right Column -->
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">
                                            <i class="fas fa-image me-2"></i>Product Image
                                        </label>
                                        
                                        <div class="image-preview mx-auto" id="imagePreview" onclick="document.getElementById('image').click()">
                                            <div class="text-center text-muted">
                                                <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                                                <p>Click to upload image</p>
                                                <small>JPG, PNG, GIF, WebP (Max: 5MB)</small>
                                            </div>
                                        </div>
                                        
                                        <input type="file" 
                                               class="d-none" 
                                               id="image" 
                                               name="image"
                                               accept="image/*"
                                               onchange="previewImage(event)">
                                        <div class="invalid-feedback" id="imageError"></div>
                                    </div>
                                </div>
                            </div>
                            
                            <hr class="my-4">
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="button" class="btn btn-secondary me-md-2" onclick="window.location.href='dashboard.php'">
                                    <i class="fas fa-times me-1"></i> Cancel
                                </button>
                                <button type="submit" class="btn btn-success" id="submitBtn">
                                    <i class="fas fa-plus me-1"></i> Add Product
                                </button>
                            </div>
                        </form>
                        
                        <div id="message" class="mt-4"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Image preview function
        function previewImage(event) {
            const input = event.target;
            const preview = document.getElementById('imagePreview');
            
            if (input.files && input.files[0]) {
                const file = input.files[0];
                
                // Check file size (5MB max)
                if (file.size > 5 * 1024 * 1024) {
                    showValidationError('File size too large. Max 5MB allowed.', '#image');
                    input.value = '';
                    return;
                }
                
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                }
                
                reader.onerror = function() {
                    preview.innerHTML = `
                        <div class="text-center text-muted">
                            <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                            <p>Click to upload image</p>
                            <small>JPG, PNG, GIF, WebP (Max: 5MB)</small>
                        </div>
                    `;
                }
                
                reader.readAsDataURL(file);
            } else {
                preview.innerHTML = `
                    <div class="text-center text-muted">
                        <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                        <p>Click to upload image</p>
                        <small>JPG, PNG, GIF, WebP (Max: 5MB)</small>
                    </div>
                `;
            }
        }
        
        // Handle form submission
        $('#addProductForm').on('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const button = $('#submitBtn');
            const originalText = button.html();
            
            // Clear previous messages and errors
            $('#message').removeClass('alert-success alert-danger').html('');
            $('.is-invalid').removeClass('is-invalid');
            $('.invalid-feedback').text('');
            
            // Client-side validation
            const productName = $('#productName').val().trim();
            const price = $('#price').val();
            const category = $('#category_id').val();
            const unit = $('#unit').val();
            
            let hasError = false;
            
            if (!productName) {
                showValidationError('Product name is required', '#productName', 'nameError');
                hasError = true;
            }
            
            if (!price || parseFloat(price) <= 0) {
                showValidationError('Price must be greater than 0', '#price', 'priceError');
                hasError = true;
            }
            
            if (!category) {
                showValidationError('Please select a category', '#category_id', 'categoryError');
                hasError = true;
            }
            
            if (!unit) {
                showValidationError('Please select a unit', '#unit', 'unitError');
                hasError = true;
            }
            
            if (hasError) {
                return;
            }
            
            button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i> Adding...');
            
            $.ajax({
                url: 'add_product.php',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show success modal with product details
                        showSuccessModal(response);
                        
                        // Reset form
                        $('#addProductForm')[0].reset();
                        $('#imagePreview').html(`
                            <div class="text-center text-muted">
                                <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                                <p>Click to upload image</p>
                                <small>JPG, PNG, GIF, WebP (Max: 5MB)</small>
                            </div>
                        `);
                        
                        // Clear any previous error messages
                        $('#message').removeClass('alert-danger').html('');
                    } else {
                        // Show error message
                        $('#message').addClass('alert alert-danger').html(`
                            <div class="d-flex align-items-center">
                                <i class="fas fa-exclamation-circle fa-2x me-3"></i>
                                <div>
                                    <h5 class="mb-1">Error!</h5>
                                    <p class="mb-0">${response.message}</p>
                                </div>
                            </div>
                        `);
                        
                        // Scroll to error message
                        $('html, body').animate({
                            scrollTop: $('#message').offset().top - 100
                        }, 500);
                    }
                },
                error: function(xhr, status, error) {
                    // Try to parse response as text to see what's being returned
                    let errorMsg = 'Please check your connection and try again.';
                    
                    if (xhr.responseText) {
                        // Check if response contains HTML (PHP error)
                        if (xhr.responseText.includes('<!DOCTYPE') || xhr.responseText.includes('<html')) {
                            errorMsg = 'Server returned HTML instead of JSON. Check for PHP errors.';
                            console.error('HTML Response:', xhr.responseText.substring(0, 500));
                        } else {
                            try {
                                const response = JSON.parse(xhr.responseText);
                                errorMsg = response.message || errorMsg;
                            } catch (e) {
                                errorMsg = 'Invalid server response. ' + xhr.responseText.substring(0, 100);
                            }
                        }
                    }
                    
                    $('#message').addClass('alert alert-danger').html(`
                        <div class="d-flex align-items-center">
                            <i class="fas fa-exclamation-triangle fa-2x me-3"></i>
                            <div>
                                <h5 class="mb-1">Server Error!</h5>
                                <p class="mb-0">${errorMsg}</p>
                                <small>Status: ${status}, Error: ${error}</small>
                            </div>
                        </div>
                    `);
                    console.error('AJAX Error:', status, error, xhr.responseText);
                },
                complete: function() {
                    button.prop('disabled', false).html(originalText);
                }
            });
        });
        
        // Show success modal and start countdown
        function showSuccessModal(response) {
            const modal = $('#successModal');
            const productDetails = $('#productDetails');
            
            // Set product details
            productDetails.html(`
                <p><strong>Product Name:</strong> ${escapeHtml(response.name)}</p>
                <p><strong>Product ID:</strong> ${response.id}</p>
                <p><strong>Barcode:</strong> ${response.barcode}</p>
                <p><strong>Price:</strong> ₹${response.price}</p>
                <p><strong>Quantity:</strong> ${response.quantity} ${response.unit}</p>
                <p><strong>Unit:</strong> ${response.unit}</p>
            `);
            
            // Show modal
            modal.addClass('active');
            
            // Start countdown
            let countdown = 5;
            const countdownElement = $('#countdown');
            countdownElement.text(countdown);
            
            const countdownInterval = setInterval(function() {
                countdown--;
                countdownElement.text(countdown);
                
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    redirectToDashboard();
                }
            }, 1000);
            
            // Store interval ID to clear if user clicks manually
            modal.data('countdownInterval', countdownInterval);
        }
        
        // Redirect to dashboard
        function redirectToDashboard() {
            window.location.href = 'dashboard.php';
        }
        
        // Handle immediate redirect button
        $('#redirectNow').on('click', function() {
            const modal = $('#successModal');
            const countdownInterval = modal.data('countdownInterval');
            
            if (countdownInterval) {
                clearInterval(countdownInterval);
            }
            
            redirectToDashboard();
        });
        
        // Show validation error
        function showValidationError(message, elementId, errorId) {
            $(elementId).addClass('is-invalid');
            if (errorId) {
                $('#' + errorId).text(message);
            }
            
            // Scroll to error
            $('html, body').animate({
                scrollTop: $(elementId).offset().top - 100
            }, 500);
        }
        
        // Escape HTML to prevent XSS
        function escapeHtml(text) {
            if (!text) return '';
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.toString().replace(/[&<>"']/g, function(m) { return map[m]; });
        }
        
        // Clear validation errors on input
        $('input, select').on('input change', function() {
            $(this).removeClass('is-invalid');
            const errorId = $(this).attr('id') + 'Error';
            $('#' + errorId).text('');
        });
    </script>
</body>
</html>