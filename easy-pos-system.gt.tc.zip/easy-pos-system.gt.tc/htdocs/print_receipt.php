<?php
session_start();
require_once 'db.php';

$sale_id = $_GET['id'] ?? 0;

if (!$sale_id) {
    die("Invalid receipt ID");
}

/* ================= FETCH SETTINGS ================= */
$settings = [];
$res = $conn->query("SELECT setting_key, setting_value FROM system_settings");
while ($row = $res->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$store_name   = $settings['store_name'] ?? 'My Store';
$store_phone  = $settings['store_phone'] ?? '';
$store_addr   = $settings['store_address'] ?? '';
$store_email  = $settings['store_email'] ?? '';
$footer_text  = $settings['receipt_footer'] ?? 'Thank you for shopping with us';
$currency     = $settings['currency'] ?? 'USD';

/* ================= FETCH SALE ================= */
// Check sales table columns
$columns_result = $conn->query("SHOW COLUMNS FROM sales");
$sales_columns = [];
while($row = $columns_result->fetch_assoc()) {
    $sales_columns[] = $row['Field'];
}

// Set default column names
$subtotal_col = 'subtotal';
$tax_col = 'tax';
$total_col = 'total';

// Adjust column names if they exist with different names
if (in_array('subtotal_amount', $sales_columns) && !in_array('subtotal', $sales_columns)) {
    $subtotal_col = 'subtotal_amount';
}

if (in_array('tax_amount', $sales_columns) && !in_array('tax', $sales_columns)) {
    $tax_col = 'tax_amount';
}

if (in_array('total_amount', $sales_columns) && !in_array('total', $sales_columns)) {
    $total_col = 'total_amount';
}

// Build and execute query
$query = "SELECT *, 
          $subtotal_col as subtotal_display, 
          $tax_col as tax_display, 
          $total_col as total_display 
          FROM sales WHERE id=?";

$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Query preparation failed: " . $conn->error);
}

$stmt->bind_param("i", $sale_id);
if (!$stmt->execute()) {
    die("Query execution failed: " . $stmt->error);
}

$sale = $stmt->get_result()->fetch_assoc();

if (!$sale) {
    die("Sale not found");
}

// Get correct values
$subtotal = $sale['subtotal_display'] ?? ($sale[$subtotal_col] ?? 0);
$tax = $sale['tax_display'] ?? ($sale[$tax_col] ?? 0);
$total = $sale['total_display'] ?? ($sale[$total_col] ?? 0);

// Calculate tax rate
if ($subtotal > 0) {
    $tax_rate = ($tax / $subtotal) * 100;
} else {
    $tax_rate = 0;
}

// Use stored tax rate if available
if (isset($sale['tax_rate'])) {
    $tax_rate = floatval($sale['tax_rate']);
}

/* ================= FETCH ITEMS ================= */
$stmt = $conn->prepare("
    SELECT si.*, p.name 
    FROM sale_items si 
    JOIN products p ON p.id = si.product_id 
    WHERE si.sale_id=?
");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get currency symbol
function getCurrencySymbol($currency) {
    switch(strtoupper($currency)) {
        case 'USD': return '$';
        case 'EUR': return '€';
        case 'GBP': return '£';
        case 'INR': return '₹';
        case 'PKR': return 'Rs ';
        default: return '$';
    }
}

$currency_symbol = getCurrencySymbol($currency);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt #<?= $sale_id ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Reset all margins and paddings */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        /* Body styling - VERY IMPORTANT for printing */
        body {
            font-family: 'Courier New', monospace, 'Arial Narrow', sans-serif;
            width: 48mm; /* EXACTLY matching your printer paper width */
            margin: 0 !important;
            padding: 2mm !important; /* Small padding */
            background: white;
            font-size: 10px; /* Smaller font for 48mm paper */
            line-height: 1;
            min-height: 100vh;
        }
        
        /* PRINT STYLES - MOST IMPORTANT */
        @media print {
            @page {
                margin: 0 !important;
                padding: 0 !important;
                size: 48mm auto; /* EXACT paper size: 48mm width */
            }
            
            body {
                width: 48mm !important;
                max-width: 48mm !important;
                margin: 0 auto !important;
                padding: 1mm !important;
                font-size: 9px !important;
                line-height: 1 !important;
            }
            
            .no-print {
                display: none !important;
            }
            
            /* Force break words to fit in narrow paper */
            * {
                word-wrap: break-word;
                overflow-wrap: break-word;
            }
        }
        
        /* Receipt container - FIXED width */
        .receipt-container {
            width: 46mm; /* Slightly less than paper width for padding */
            max-width: 46mm;
            margin: 0 auto;
        }
        
        /* Header */
        .header {
            text-align: center;
            padding-bottom: 3px;
            margin-bottom: 3px;
            border-bottom: 1px dashed #000;
        }
        
        .store-name {
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 2px;
            text-transform: uppercase;
        }
        
        .store-info {
            font-size: 8px;
            margin: 1px 0;
        }
        
        /* Meta info */
        .meta {
            font-size: 8px;
            margin-bottom: 4px;
            padding-bottom: 4px;
            border-bottom: 1px dashed #000;
        }
        
        .meta-row {
            display: flex;
            justify-content: space-between;
            margin: 1px 0;
        }
        
        /* Table - MUST be compact */
        .items-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 8px;
            margin: 4px 0;
        }
        
        .items-table th {
            text-align: left;
            border-bottom: 1px solid #000;
            padding: 2px 1px;
            font-weight: bold;
        }
        
        .items-table td {
            padding: 2px 1px;
            border-bottom: 1px dashed #ccc;
            vertical-align: top;
        }
        
        /* Text alignment */
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .text-left {
            text-align: left;
        }
        
        /* Item name column - truncated if too long */
        .item-name {
            max-width: 20mm;
            white-space: normal;
            word-break: break-word;
        }
        
        /* Totals section */
        .totals {
            font-size: 9px;
            margin-top: 5px;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            margin: 2px 0;
        }
        
        .grand-total {
            border-top: 2px solid #000;
            font-weight: bold;
            margin-top: 4px;
            padding-top: 4px;
            font-size: 11px;
        }
        
        /* Footer */
        .footer {
            text-align: center;
            margin-top: 8px;
            padding-top: 4px;
            border-top: 1px dashed #000;
            font-size: 7px;
        }
        
        /* Print controls (only on screen) */
        .print-controls {
            position: fixed;
            top: 10px;
            right: 10px;
            background: white;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        
        .print-controls button {
            padding: 6px 10px;
            margin: 2px;
            border: 1px solid #007bff;
            background: #007bff;
            color: white;
            border-radius: 3px;
            cursor: pointer;
            font-size: 11px;
            font-weight: bold;
        }
        
        .print-controls button:hover {
            background: #0056b3;
        }
        
        /* Utility classes */
        .divider {
            border-top: 1px dashed #000;
            margin: 4px 0;
        }
        
        /* Force table columns to be compact */
        .col-qty {
            width: 10mm;
        }
        
        .col-price {
            width: 12mm;
        }
        
        .col-total {
            width: 12mm;
        }
    </style>
</head>
<body>

<div class="print-controls no-print">
    <button onclick="window.print()">🖨 Print</button>
    <button onclick="window.close()">✖ Close</button>
    <button onclick="testPrint()">Test Print</button>
</div>

<div class="receipt-container">
    <!-- Header -->
    <div class="header">
        <div class="store-name"><?= substr(htmlspecialchars($store_name), 0, 20) ?></div>
        <?php if($store_addr): ?>
            <div class="store-info"><?= substr(htmlspecialchars($store_addr), 0, 30) ?></div>
        <?php endif; ?>
        <?php if($store_phone): ?>
            <div class="store-info">📞 <?= substr(htmlspecialchars($store_phone), 0, 15) ?></div>
        <?php endif; ?>
    </div>
    
    <!-- Meta Information -->
    <div class="meta">
        <div class="meta-row">
            <span>Date:</span>
            <span><?= date('Y-m-d', strtotime($sale['created_at'])) ?></span>
        </div>
        <div class="meta-row">
            <span>Time:</span>
            <span><?= date('H:i:s', strtotime($sale['created_at'])) ?></span>
        </div>
        <div class="meta-row">
            <span>Cashier:</span>
            <span><?= substr(htmlspecialchars($sale['cashier']), 0, 10) ?></span>
        </div>
        <div class="meta-row">
            <span>Receipt #:</span>
            <span><?= $sale_id ?></span>
        </div>
    </div>
    
    <!-- Items Table - COMPACT VERSION -->
    <table class="items-table">
        <thead>
            <tr>
                <th class="text-left">Item</th>
                <th class="text-right col-qty">Qty</th>
                <th class="text-right col-price">Price</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $item_count = 0;
            foreach($items as $item): 
                if($item_count >= 10) break; // Limit items for small paper
                $item_count++;
            ?>
            <tr>
                <td class="text-left item-name">
                    <?= substr(htmlspecialchars($item['name']), 0, 15) ?>
                </td>
                <td class="text-right col-qty">
                    <?= number_format($item['quantity'], 2) ?>
                </td>
                <td class="text-right col-price">
                    <?= $currency_symbol ?><?= number_format($item['total_price'], 2) ?>
                </td>
            </tr>
            <?php endforeach; ?>
            
            <?php if(count($items) > 10): ?>
            <tr>
                <td colspan="3" class="text-center" style="font-size: 7px;">
                    ... and <?= count($items) - 10 ?> more items
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div class="divider"></div>
    
    <!-- Totals - COMPACT -->
    <div class="totals">
        <div class="total-row">
            <span>Subtotal:</span>
            <span><?= $currency_symbol ?><?= number_format($subtotal, 2) ?></span>
        </div>
        <?php if($tax > 0): ?>
        <div class="total-row">
            <span>Tax (<?= number_format($tax_rate, 1) ?>%):</span>
            <span><?= $currency_symbol ?><?= number_format($tax, 2) ?></span>
        </div>
        <?php endif; ?>
        <div class="total-row grand-total">
            <span>TOTAL:</span>
            <span><?= $currency_symbol ?><?= number_format($total, 2) ?></span>
        </div>
        
        <?php if(!empty($sale['payment_method'])): ?>
        <div class="total-row">
            <span>Payment:</span>
            <span><?= strtoupper(substr($sale['payment_method'], 0, 4)) ?></span>
        </div>
        <?php endif; ?>
        
        <?php if(isset($sale['change_amount']) && $sale['change_amount'] > 0): ?>
        <div class="total-row">
            <span>Change:</span>
            <span><?= $currency_symbol ?><?= number_format($sale['change_amount'], 2) ?></span>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <?= substr(htmlspecialchars($footer_text), 0, 30) ?>
    </div>
</div>

<script>
// Auto print after page loads
window.onload = function() {
    // Small delay to ensure all content is rendered
    setTimeout(function() {
        window.print();
    }, 800);
};

// Test print function
function testPrint() {
    alert('Printer Paper Size: 48mm x 210mm\nCurrent width: 48mm\nIf printing is off-center, adjust printer settings.');
    
    // Show actual dimensions
    const container = document.querySelector('.receipt-container');
    if (container) {
        const width = container.offsetWidth;
        const height = container.offsetHeight;
        alert('Receipt dimensions:\nWidth: ' + width + 'px (' + (width/3.78).toFixed(1) + 'mm)\nHeight: ' + height + 'px (' + (height/3.78).toFixed(1) + 'mm)');
    }
}

// Close window after print
window.addEventListener('afterprint', function() {
    setTimeout(function() {
        window.close();
    }, 1500);
});

// Force page setup for printing
window.onbeforeprint = function() {
    // Ensure body has correct dimensions before printing
    document.body.style.width = '48mm';
    document.body.style.maxWidth = '48mm';
    document.body.style.margin = '0 auto';
};
</script>

</body>
</html>
<?php $conn->close(); ?>