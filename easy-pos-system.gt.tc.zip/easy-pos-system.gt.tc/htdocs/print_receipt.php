<?php
session_start();
require_once 'db.php';

$sale_id = $_GET['id'] ?? 0;

/* ================= FETCH SETTINGS ================= */
$settings = [];
$res = $conn->query("SELECT setting_key, setting_value FROM system_settings");
while ($row = $res->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$store_name   = $settings['store_name'] ?? 'My Store';
$store_phone  = $settings['store_phone'] ?? '';
$store_addr   = $settings['store_address'] ?? '';
$store_email   = $settings['store_email'] ?? '';
$footer_text  = $settings['receipt_footer'] ?? 'Thank you for shopping with us';

/* ================= FETCH SALE ================= */
// پہلے sales ٹیبل کے کالم نام چیک کریں
$columns_result = $conn->query("SHOW COLUMNS FROM sales");
$sales_columns = [];
while($row = $columns_result->fetch_assoc()) {
    $sales_columns[] = $row['Field'];
}

error_log("Sales columns in print_receipt: " . print_r($sales_columns, true));

// ڈیفالٹ کالم نام مقرر کریں
$subtotal_col = 'subtotal';
$tax_col = 'tax';
$total_col = 'total';

// کالم نام چیک کریں اور درست کریں
if (in_array('subtotal_amount', $sales_columns) && !in_array('subtotal', $sales_columns)) {
    $subtotal_col = 'subtotal_amount';
    error_log("Using subtotal_amount column for subtotal");
}

if (in_array('tax_amount', $sales_columns) && !in_array('tax', $sales_columns)) {
    $tax_col = 'tax_amount';
    error_log("Using tax_amount column for tax");
}

if (in_array('total_amount', $sales_columns) && !in_array('total', $sales_columns)) {
    $total_col = 'total_amount';
    error_log("Using total_amount column for total");
}

// سلیکٹ کوئری بنائیں
$query = "SELECT *, 
          $subtotal_col as subtotal_display, 
          $tax_col as tax_display, 
          $total_col as total_display 
          FROM sales WHERE id=?";

error_log("Query: " . $query);

$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Query preparation failed: " . $conn->error);
}

$stmt->bind_param("i", $sale_id);
if (!$stmt->execute()) {
    die("Query execution failed: " . $stmt->error);
}

$sale = $stmt->get_result()->fetch_assoc();

if (!$sale) {
    die("Sale not found");
}

error_log("Sale data: " . print_r($sale, true));

// صحیح قیمتیں مقرر کریں
$subtotal = $sale['subtotal_display'] ?? ($sale[$subtotal_col] ?? 0);
$tax = $sale['tax_display'] ?? ($sale[$tax_col] ?? 0);
$total = $sale['total_display'] ?? ($sale[$total_col] ?? 0);

error_log("Calculated values - Subtotal: $subtotal, Tax: $tax, Total: $total");

// ٹیکس ریٹ کا حساب لگائیں
if ($subtotal > 0) {
    $tax_rate = ($tax / $subtotal) * 100;
} else {
    $tax_rate = 0;
}

// اگر ٹیکس ریٹ کالم موجود ہے تو اسے استعمال کریں
if (isset($sale['tax_rate'])) {
    $tax_rate = floatval($sale['tax_rate']);
}

error_log("Tax rate: $tax_rate%");

/* ================= FETCH ITEMS ================= */
$stmt = $conn->prepare("
    SELECT si.*, p.name 
    FROM sale_items si 
    JOIN products p ON p.id = si.product_id 
    WHERE si.sale_id=?
");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Receipt #<?= $sale_id ?></title>

<style>
/* ================= COMMON ================= */
body{
    font-family: "Courier New", monospace;
    width: 80mm;
    margin: 0 auto;              /* ✅ CENTER */
    padding: 12px;
    background: #fff;
    font-size: 13px;
    line-height: 1.3;
}

/* ================= PRINT ================= */
@media print{
    @page{ margin:0; }
    body{
        margin: 0 auto !important; /* ✅ CENTER PRINT */
        padding: 8px;
        font-size: 12px;
    }
    .no-print{ display:none !important; }
}

/* ================= HEADER ================= */
.header{
    text-align:center;
    border-bottom:1px dashed #000;
    padding-bottom:6px;
    margin-bottom:6px;
}
.header h2{
    margin:4px 0;
    font-size:18px;
}

/* ================= META ================= */
.meta{
    font-size:11px;
    border-bottom:1px dashed #000;
    margin-bottom:6px;
    padding-bottom:6px;
}
.meta div{
    display:flex;
    justify-content:space-between;
}

/* ================= TABLE ================= */
table{
    width:100%;
    border-collapse:collapse;
    font-size:11px;
}
th{
    text-align:left;
    border-bottom:1px solid #000;
}
td{ padding:2px 0; }
.right{ text-align:right; }

/* ================= TOTALS ================= */
.totals{
    font-size:11px;
    margin-top:6px;
}
.totals div{
    display:flex;
    justify-content:space-between;
}
.grand{
    border-top:2px solid #000;
    font-weight:bold;
    margin-top:4px;
    padding-top:4px;
}

/* ================= FOOTER ================= */
.footer{
    text-align:center;
    border-top:1px dashed #000;
    margin-top:10px;
    padding-top:6px;
    font-size:10px;
}

/* ================= BUTTONS ================= */
.no-print{
    position:fixed;
    top:20px;
    right:20px;
}
button{
    padding:8px 14px;
    margin:4px;
    font-weight:bold;
    cursor:pointer;
}
</style>
</head>

<body>

<!-- ===== CONTROLS ===== -->
<div class="no-print">
    <button onclick="window.print()">🖨 Print</button>
    <button onclick="window.close()">✖ Close</button>
</div>

<!-- ===== RECEIPT ===== -->
<div class="header">
    <h2><?= htmlspecialchars($store_name) ?></h2>
    <?php if($store_addr): ?><div><?= htmlspecialchars($store_addr) ?></div><?php endif; ?>
    <?php if($store_phone): ?><div><?= htmlspecialchars($store_phone) ?></div><?php endif; ?>
	<?php if($store_email): ?><div><?= htmlspecialchars($store_email) ?></div><?php endif; ?>
</div>

<div class="meta">
    <div><span>Date</span><span><?= date('Y-m-d', strtotime($sale['created_at'])) ?></span></div>
    <div><span>Time</span><span><?= date('H:i:s', strtotime($sale['created_at'])) ?></span></div>
    <div><span>Cashier</span><span><?= htmlspecialchars($sale['cashier']) ?></span></div>
    <div><span>Receipt #</span><span><?= $sale['id'] ?></span></div>
</div>

<table>
<thead>
<tr>
    <th>Item</th>
    <th class="right">Qty</th>
    <th class="right">Price</th>
    <th class="right">Total</th>
</tr>
</thead>
<tbody>
<?php foreach($items as $i): ?>
<tr>
    <td><?= htmlspecialchars($i['name']) ?></td>
    <td class="right"><?= number_format($i['quantity'], 3) ?></td>
    <td class="right">$<?= number_format($i['unit_price'],2) ?></td>
    <td class="right">$<?= number_format($i['total_price'],2) ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<div class="totals">
    <div><span>Subtotal</span><span>$<?= number_format($subtotal,2) ?></span></div>
    <div><span>Tax (<?= number_format($tax_rate,1) ?>%)</span><span>$<?= number_format($tax,2) ?></span></div>
    <div class="grand"><span>TOTAL</span><span>$<?= number_format($total,2) ?></span></div>
</div>

<div class="footer">
    <?= htmlspecialchars($footer_text) ?><br>
    Please keep this receipt
</div>

<script>
// Auto print
window.onload = function(){
    setTimeout(function(){
        window.print();
    }, 400);
};
</script>

</body>
</html>
<?php $conn->close(); ?>